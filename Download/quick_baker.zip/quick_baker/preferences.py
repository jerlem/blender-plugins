import bpy
from bpy.types import AddonPreferences, PropertyGroup
from bpy.props import *
import os


class QBAKER_AP_bake(PropertyGroup):
    batch_name: StringProperty(
        name="Batch Name",
        description="Name the maps with additional info.\n\n$name - Name of the BakeGroup (Bakegroup_$size_$type).\n$size    - Size of the map ($name_1K_$type).\n$type   - Type of the map ($name_$size_Color)",
        default="$name_$size_$type",
    )


class QBAKER_AP_cage(PropertyGroup):
    color: FloatVectorProperty(
        name="Cage Color",
        description="Color for cage objects",
        subtype="COLOR",
        size=4,
        min=0.0,
        max=1.0,
        default=(0.7, 0.6, 0.5, 0.5),
    )

    wireframe: BoolProperty(
        name="Wireframe",
        description="Display the object's wireframe over solid shading",
        default=True,
    )


class QBAKER_AP_qbaker(PropertyGroup):
    bake: PointerProperty(type=QBAKER_AP_bake)
    cage: PointerProperty(type=QBAKER_AP_cage)


class QBAKER_AP_preferences(AddonPreferences):
    bl_idname = __package__

    qbaker: PointerProperty(type=QBAKER_AP_qbaker)

    def draw(self, context):
        layout = self.layout
        layout.use_property_decorate = False
        layout.use_property_split = True

        col = layout.column()
        col.prop(self.qbaker.bake, "batch_name")

        col = layout.column(heading="Cage")
        col.use_property_split = True
        col.prop(self.qbaker.cage, "color")
        col.prop(self.qbaker.cage, "wireframe")


classes = (
    QBAKER_AP_bake,
    QBAKER_AP_cage,
    QBAKER_AP_qbaker,
    QBAKER_AP_preferences,
)


register, unregister = bpy.utils.register_classes_factory(classes)
