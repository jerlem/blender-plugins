<p align=center><img src="./icons/QBAKER_150.png"/></p>

<p align=center style="font-size: 24px">Quick Baker</p>

## Introduction

Quick Baker is a PBR texture-baking addon that uses the native Blender baking operator for baking PBR texture, and mask maps

The addon extends the Blender baking process for multiple objects with multiple maps. It can bake objects and high to low-poly objects with multiple maps. It makes high to low-poly baking very simple and easy with one click cage setup

## Changelog

**Added**

- `Bake Groups` list move operator.
- `Objects` list move operator.
- `Groups` list move operator.
- `High Poly` list move operator.
- `Material Bake` list move operator.
- `Toon Shadow` map to bake the shadow map used for the toon shader.

**Fixed**

- Unused material slot bug. (https://discord.com/channels/959138815602229389/1247297372883517471)
- Material load bug.
- Installation error for `MacOS` and `Linux`.