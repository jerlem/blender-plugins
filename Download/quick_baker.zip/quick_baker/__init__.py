bl_info = {
    "name": "Quick Baker",
    "author": "Karan, Bananenbrot",
    "description": "PBR Texture Baker.",
    "blender": (3, 3, 0),
    "version": (2, 4, 0),
    "category": "Baking",
    "location": "3D Viewport | Shader Editor > Sidebar(N-Panel) > Q-Baker",
    "support": "COMMUNITY",
    "warning": "",
    "doc_url": "https://b3dhub.github.io/quick-baker-docs",
    "tracker_url": "https://discord.gg/sdnHHZpWbT",
}


import bpy
from . import source
from . import preferences
from . import changelog
from contextlib import suppress


def register():
    source.register()
    preferences.register()
    changelog.register()


def unregister():
    source.unregister()
    preferences.unregister()
    with suppress(RuntimeError):
        changelog.unregister()
