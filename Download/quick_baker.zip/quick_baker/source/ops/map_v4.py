import bpy
from bpy.types import Operator
from bpy.props import *
from ...qbpy.blender import preferences
import uuid


MAP_TYPES = {
    "PBR": [("", "PBR", "", "SHADING_RENDERED", 0), "PBR"],
    "BASE_COLOR": [("BASE_COLOR", "Base Color", "Base Color / Albedo / Diffuse Map"), "Base Color"],
    "EMISSION": [("EMISSION", "Emission", "Emission Map"), "Emission"],
    "GLOSSINESS": [("GLOSSINESS", "Glossiness", "Glossiness / Smoothness Map"), "Glossiness"],
    "METALLIC": [("METALLIC", "Metallic", "Metallic Map"), "Metallic"],
    "NORMAL": [("NORMAL", "Normal", "Normal Map"), "Normal"],
    "OCCLUSION": [("OCCLUSION", "Occlusion", "Ambient Occlusion Map"), "Occlusion"],
    "ROUGHNESS": [("ROUGHNESS", "Roughness", "Roughness Map"), "Roughness"],
    "SPECULAR": [("SPECULAR", "Specular", "Specular Map"), "Specular"],
    "CHANNEL_PACK": [("CHANNEL_PACK", "Channel Pack", "Channel Pack Map"), "Channel Pack"],
    "MESH": [("", "Mesh", "", "MESH_DATA", 0), "Mesh"],
    "ALPHA": [("ALPHA", "Alpha", "Alpha / Opacity / Transparency Map"), "Alpha"],
    "BEVEL_NORMAL": [("BEVEL_NORMAL", "Bevel Normal", "Bevel Normal Map"), "Bevel Normal"],
    "CAVITY": [("CAVITY", "Cavity", "Cavity / Concavity Map"), "Cavity"],
    "CURVATURE": [("CURVATURE", "Curvature", "Curvature Map"), "Curvature"],
    "DISPLACEMENT": [
        (
            "DISPLACEMENT",
            "Displacement",
            "Displacement / Bump Map\nBake displacement data from Multires modifier or Displacement node",
        ),
        "Displacement",
    ],
    "EDGE": [("EDGE", "Edge", "Edge / Convexity Map"), "Edge"],
    "GRADIENT": [("GRADIENT", "Gradient", "Gradient Map"), "Gradient"],
    "HEIGHT": [
        (
            "HEIGHT",
            "Heightmap",
            "Height Map\nBake height data along Z axis.\nUsed for large meshes e.g. Terrain",
        ),
        "Heightmap",
    ],
    "MATERIAL_ID": [("MATERIAL_ID", "Material ID", "Material ID Map"), "Material ID"],
    "THICKNESS": [("THICKNESS", "Thickness", "Thickness / Translucency Map"), "Thickness"],
    "TOON_SHADOW": [("TOON_SHADOW", "Toon Shadow", "Toon Shadow Map"), "Toon Shadow"],
    "VDM": [("VDM", "Vector Displacement (VDM)", "Vector Displacement Map"), "Vector Displacement (VDM)"],
    "WIREFRAME": [("WIREFRAME", "Wireframe", "Wireframe / UV Layout Map"), "Wireframe"],
    "XYZ": [("XYZ", "XYZ", "XYZ Map"), "XYZ"],
    "BSDF": [("", "Principled BSDF", "", "NODE", 0), "Principled BSDF"],
    "IOR": [("IOR", "IOR", "IOR Map"), "IOR"],
    "SUBSURFACE_WEIGHT": [("SUBSURFACE_WEIGHT", "Subsurface Weight", "Subsurface Weight Map"), "Subsurface Weight"],
    "SUBSURFACE_SCALE": [("SUBSURFACE_SCALE", "Subsurface Scale", "Subsurface Scale Map"), "Subsurface Scale"],
    "SUBSURFACE_IOR": [("SUBSURFACE_IOR", "Subsurface IOR", "Subsurface IOR Map"), "Subsurface IOR"],
    "SUBSURFACE_ANISOTROPY": [("SUBSURFACE_ANISOTROPY", "Subsurface Anisotropy", "Subsurface Anisotropy Map"), "Subsurface Anisotropy"],
    "SPECULAR_TINT": [("SPECULAR_TINT", "Specular Tint", "Specular Tint Map"), "Specular Tint"],
    "ANISOTROPIC": [("ANISOTROPIC", "Anisotropic", "Anisotropic Map"), "Anisotropic"],
    "ANISOTROPIC_ROT": [("ANISOTROPIC_ROT", "Anisotropic Rotation", "Anisotropic Rotation Map"), "Anisotropic Rotation"],
    "TANGENT": [("TANGENT", "Tangent", "Tangent Map"), "Tangent"],
    "TRANSMISSION_WEIGHT": [("TRANSMISSION_WEIGHT", "Transmission Weight", "Transmission Weight Map"), "Transmission Weight"],
    "COAT_WEIGHT": [("COAT_WEIGHT", "Coat Weight", "Coat Weight Map"), "Coat Weight"],
    "COAT_ROUGHNESS": [("COAT_ROUGHNESS", "Coat Roughness", "Coat Roughness Map"), "Coat Roughness"],
    "COAT_IOR": [("COAT_IOR", "Coat IOR", "Coat IOR Map"), "Coat IOR"],
    "COAT_TINT": [("COAT_TINT", "Coat Tint", "Coat Tint Map"), "Coat Tint"],
    "COAT_NORMAL": [("COAT_NORMAL", "Coat Normal", "Coat Normal Map"), "Coat Normal"],
    "SHEEN_WEIGHT": [("SHEEN_WEIGHT", "Sheen Weight", "Sheen Weight Map"), "Sheen Weight"],
    "SHEEN_ROUGHNESS": [("SHEEN_ROUGHNESS", "Sheen Roughness", "Sheen Roughness Map"), "Sheen Roughness"],
    "SHEEN_TINT": [("SHEEN_TINT", "Sheen Tint", "Sheen Tint Map"), "Sheen Tint"],
    "EMISSION_STRENGTH": [("EMISSION_STRENGTH", "Emission Strength", "Emission Strength Map"), "Emission Strength"],
    "CYCLE": [("", "Cycles", "", "SHADING_TEXTURE", 0), "Cycles"],
    "AO": [("AO", "Ambient Occlusion", "Cycles Ambient Occlusion Map"), "Ambient Occlusion"],
    "COMBINED": [("COMBINED", "Combined", "Combined Map"), "Combined"],
    "DIFFUSE": [("DIFFUSE", "Diffuse", "Diffuse Map"), "Diffuse"],
    "ENVIRONMENT": [("ENVIRONMENT", "Environment", "Environment Map"), "Environment"],
    "GLOSSY": [("GLOSSY", "Glossy", "Glossy Map"), "Glossy"],
    "POSITION": [("POSITION", "Position", "Position Map"), "Position"],
    "SHADOW": [("SHADOW", "Shadow", "Shadow Map"), "Shadow"],
    "TRANSMISSION": [("TRANSMISSION", "Transmission", "Transmission Map"), "Transmission"],
    "UV": [("UV", "UV", "UV Map"), "UV"],
}


class QBAKER_OT_map_add(Operator):
    """Add a map to be baked"""

    bl_label = "Add Map"
    bl_idname = "qbaker.map_add"
    bl_options = {"REGISTER", "INTERNAL"}

    @classmethod
    def poll(cls, context):
        baker = context.scene.qbaker
        return baker.bake_groups

    def items_type(self, context):
        return [
            *list(value[0] for value in MAP_TYPES.values()),
        ]

    type: EnumProperty(name="Map Type", description="Type of map to bake", items=items_type)

    def execute(self, context):
        baker = context.scene.qbaker

        if baker.use_map_global:
            bake_group = baker
        else:
            bake_group = baker.bake_groups[baker.bake_group_index]

        map = bake_group.maps.add()
        bake_group.map_index = len(bake_group.maps) - 1
        map.name = uuid.uuid1().hex
        map.label = MAP_TYPES[self.type][1]
        map.type = self.type
        return {"FINISHED"}


class QBAKER_OT_map_load(Operator):
    bl_label = "Load Maps"
    bl_idname = "qbaker.map_load"
    bl_options = {"REGISTER", "INTERNAL"}

    @classmethod
    def description(cls, context, event):
        return """Load maps based on Principled BSDF input sockets and values.\n\nShift  •  Load maps based on Principled BSDF input sockets"""

    @classmethod
    def poll(cls, context):
        baker = context.scene.qbaker
        bake_group = baker.bake_groups[baker.bake_group_index]
        return bake_group.groups if bake_group.use_high_to_low else bake_group.objects

    def check_inputs_sockets_values(self, node_tree, maps):
        map_type = None
        for node in node_tree.nodes:
            if node.type == "BSDF_PRINCIPLED":
                for input in node.inputs:
                    if input.name == "Base Color":
                        if input.is_linked or input.default_value[:] != (
                            0.800000011920929,
                            0.800000011920929,
                            0.800000011920929,
                            1.0,
                        ):
                            map_type = "BASE_COLOR"
                    elif input.name == "Metallic":
                        if input.is_linked or input.default_value != 0.0:
                            map_type = "METALLIC"
                    elif input.name == "Roughness":
                        if input.is_linked or input.default_value != 0.5:
                            map_type = "ROUGHNESS"
                    elif input.name == "IOR":
                        if input.is_linked or input.default_value != 1.4500000476837158:
                            map_type = "IOR"
                    elif input.name == "Alpha":
                        if input.is_linked or input.default_value != 1.0:
                            map_type = "ALPHA"
                    elif input.name == "Normal" and input.is_linked:
                        map_type = "NORMAL"
                    elif input.name == "Subsurface Weight":
                        if input.is_linked or input.default_value != 0.0:
                            map_type = "SUBSURFACE_WEIGHT"
                    elif input.name == "Subsurface Scale":
                        if input.is_linked or input.default_value != 0.05000000074505806:
                            map_type = "SUBSURFACE_SCALE"
                    elif node.subsurface_method == "RANDOM_WALK_SKIN" and input.name == "Subsurface IOR":
                        if input.is_linked or input.default_value != 1.399999976158142:
                            map_type = "SUBSURFACE_IOR"
                    elif node.subsurface_method != "BURLEY" and input.name == "Subsurface Anisotropy":
                        if input.is_linked or input.default_value != 0.0:
                            map_type = "SUBSURFACE_ANISOTROPY"
                    elif input.name == "Specular IOR Level":
                        if input.is_linked or input.default_value != 0.5:
                            map_type = "SPECULAR"
                    elif input.name == "Specular Tint":
                        if input.is_linked or input.default_value[:] != (
                            1.0,
                            1.0,
                            1.0,
                            1.0,
                        ):
                            map_type = "SPECULAR_TINT"
                    elif input.name == "Anisotropic":
                        if input.is_linked or input.default_value != 0.0:
                            map_type = "ANISOTROPIC"
                    elif input.name == "Anisotropic Rotation":
                        if input.is_linked or input.default_value != 0.0:
                            map_type = "ANISOTROPIC_ROT"
                    elif input.name == "Tangent" and input.is_linked:
                        map_type = "TANGENT"
                    elif input.name == "Transmission Weight":
                        if input.is_linked or input.default_value != 0.0:
                            map_type = "TRANSMISSION_WEIGHT"
                    elif input.name == "Coat Weight":
                        if input.is_linked or input.default_value != 0.0:
                            map_type = "COAT_WEIGHT"
                    elif input.name == "Coat Roughness":
                        if input.is_linked or input.default_value != 0.029999999329447746:
                            map_type = "COAT_ROUGHNESS"
                    elif input.name == "Coat IOR":
                        if input.is_linked or input.default_value != 1.5:
                            map_type = "COAT_IOR"
                    elif input.name == "Coat Tint":
                        if input.is_linked or input.default_value[:] != (
                            1.0,
                            1.0,
                            1.0,
                            1.0,
                        ):
                            map_type = "COAT_TINT"
                    elif input.name == "Coat Normal" and input.is_linked:
                        map_type = "COAT_NORMAL"
                    elif input.name == "Sheen Weight":
                        if input.is_linked or input.default_value != 0.0:
                            map_type = "SHEEN_WEIGHT"
                    elif input.name == "Sheen Roughness":
                        if input.is_linked or input.default_value != 0.5:
                            map_type = "SHEEN_ROUGHNESS"
                    elif input.name == "Sheen Tint":
                        if input.is_linked or input.default_value[:] != (
                            1.0,
                            1.0,
                            1.0,
                            1.0,
                        ):
                            map_type = "SHEEN_TINT"
                    elif input.name == "Emission Color":
                        if input.is_linked or input.default_value[:] != (
                            1.0,
                            1.0,
                            1.0,
                            1.0,
                        ):
                            map_type = "EMISSION"
                    elif input.name == "Emission Strength":
                        if input.is_linked or input.default_value != 0.0:
                            map_type = "EMISSION_STRENGTH"

                    if map_type and all(map.type != map_type for map in maps):
                        bpy.ops.qbaker.map_add(type=map_type)

            elif node.type == "GROUP":
                self.check_inputs_sockets_values(node_tree=node.node_tree, maps=maps)

            elif node.type == "OUTPUT_MATERIAL":
                if node.inputs["Displacement"].is_linked:
                    map_type = "DISPLACEMENT"

                    if map_type and all(map.type != map_type for map in maps):
                        bpy.ops.qbaker.map_add(type=map_type)

    def check_inputs_sockets(self, node_tree, maps):
        map_type = None
        for node in node_tree.nodes:
            if node.type == "BSDF_PRINCIPLED":
                for input in node.inputs:
                    if input.name == "Base Color" and input.is_linked:
                        map_type = "BASE_COLOR"
                    elif input.name == "Metallic" and input.is_linked:
                        map_type = "METALLIC"
                    elif input.name == "Roughness" and input.is_linked:
                        map_type = "ROUGHNESS"
                    elif input.name == "IOR" and input.is_linked:
                        map_type = "IOR"
                    elif input.name == "Alpha" and input.is_linked:
                        map_type = "ALPHA"
                    elif input.name == "Normal" and input.is_linked:
                        map_type = "NORMAL"
                    elif input.name == "Subsurface Weight" and input.is_linked:
                        map_type = "SUBSURFACE_WEIGHT"
                    elif input.name == "Subsurface Scale" and input.is_linked:
                        map_type = "SUBSURFACE_SCALE"
                    elif node.subsurface_method == "RANDOM_WALK_SKIN" and input.name == "Subsurface IOR" and input.is_linked:
                        map_type = "SUBSURFACE_IOR"
                    elif node.subsurface_method != "BURLEY" and input.name == "Subsurface Anisotropy" and input.is_linked:
                        map_type = "SUBSURFACE_ANISOTROPY"
                    elif input.name == "Specular IOR Level" and input.is_linked:
                        map_type = "SPECULAR"
                    elif input.name == "Specular Tint" and input.is_linked:
                        map_type = "SPECULAR_TINT"
                    elif input.name == "Anisotropic" and input.is_linked:
                        map_type = "ANISOTROPIC"
                    elif input.name == "Anisotropic Rotation" and input.is_linked:
                        map_type = "ANISOTROPIC_ROT"
                    elif input.name == "Tangent" and input.is_linked:
                        map_type = "TANGENT"
                    elif input.name == "Transmission Weight" and input.is_linked:
                        map_type = "TRANSMISSION_WEIGHT"
                    elif input.name == "Coat Weight" and input.is_linked:
                        map_type = "COAT_WEIGHT"
                    elif input.name == "Coat Roughness" and input.is_linked:
                        map_type = "COAT_ROUGHNESS"
                    elif input.name == "Coat IOR" and input.is_linked:
                        map_type = "COAT_IOR"
                    elif input.name == "Coat Tint" and input.is_linked:
                        map_type = "COAT_TINT"
                    elif input.name == "Coat Normal" and input.is_linked:
                        map_type = "COAT_NORMAL"
                    elif input.name == "Sheen Weight" and input.is_linked:
                        map_type = "SHEEN_WEIGHT"
                    elif input.name == "Sheen Roughness" and input.is_linked:
                        map_type = "SHEEN_ROUGHNESS"
                    elif input.name == "Sheen Tint" and input.is_linked:
                        map_type = "SHEEN_TINT"
                    elif input.name == "Emission Color" and input.is_linked:
                        map_type = "EMISSION"
                    elif input.name == "Emission Strength" and input.is_linked:
                        map_type = "EMISSION_STRENGTH"

                    if map_type and all(map.type != map_type for map in maps):
                        bpy.ops.qbaker.map_add(type=map_type)

            elif node.type == "GROUP":
                self.check_inputs_sockets(node_tree=node.node_tree, maps=maps)

            elif node.type == "OUTPUT_MATERIAL":
                if node.inputs["Displacement"].is_linked:
                    map_type = "DISPLACEMENT"

                    if map_type and all(map.type != map_type for map in maps):
                        bpy.ops.qbaker.map_add(type=map_type)

    def invoke(self, context, event):
        baker = context.scene.qbaker
        bake_group = baker.bake_groups[baker.bake_group_index]
        maps = baker.maps if baker.use_map_global else bake_group.maps

        if bake_group.use_high_to_low:
            objects = []
            for group in bake_group.groups:
                objects.extend(item.object for item in group.low_poly)
        else:
            objects = [item.object for item in bake_group.objects]

        for object in objects:
            if object.material_slots:
                for slot in object.material_slots:
                    if slot.material and slot.material.use_nodes:
                        node_tree = slot.material.node_tree

                        if event.shift:
                            self.check_inputs_sockets(node_tree, maps)
                        else:
                            self.check_inputs_sockets_values(node_tree, maps)

        return {"FINISHED"}


class QBAKER_OT_map_remove(Operator):
    bl_label = "Remove"
    bl_idname = "qbaker.map_remove"
    bl_options = {"REGISTER", "INTERNAL"}

    @classmethod
    def description(cls, context, event):
        return """Remove Map.\n\nShift  •  Remove all the maps"""

    index: IntProperty()

    @classmethod
    def poll(cls, context):
        baker = context.scene.qbaker

        if baker.use_map_global:
            bake_group = baker
        else:
            bake_group = baker.bake_groups[baker.bake_group_index]

        return bake_group.maps

    def invoke(self, context, event):
        self.baker = context.scene.qbaker

        if self.baker.use_map_global:
            self.bake_group = self.baker
        else:
            self.bake_group = self.baker.bake_groups[self.baker.bake_group_index]

        if event.shift:
            self.bake_group.maps.clear()
            self.bake_group.map_index = 0
        else:
            self.bake_group.maps.remove(self.index)
            self.bake_group.map_index = min(max(0, self.bake_group.map_index - 1), len(self.bake_group.maps) - 1)

        for item in self.baker.bake_groups[self.baker.bake_group_index].objects:
            if item.object.material_slots:
                for slot in item.object.material_slots:
                    if slot.material and slot.material.use_nodes:
                        node_tree = slot.material.node_tree
                        for node in node_tree.nodes:
                            if node.name.split("_")[0] == "QB":
                                node_tree.nodes.remove(node)
        return {"FINISHED"}


classes = (
    QBAKER_OT_map_add,
    QBAKER_OT_map_load,
    QBAKER_OT_map_remove,
)

register, unregister = bpy.utils.register_classes_factory(classes)
