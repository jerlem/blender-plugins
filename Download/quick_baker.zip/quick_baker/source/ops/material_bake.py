import bpy
from bpy.types import Operator
from bpy.props import StringProperty, IntProperty, EnumProperty
from bl_operators.presets import AddPresetBase
from ...qbpy.blender import preferences
import os


class QBAKER_OT_material_add(Operator):
    """Add a material"""

    bl_label = "Add Material"
    bl_idname = "qbaker.material_add"
    bl_options = {"REGISTER", "INTERNAL"}
    bl_property = "material"

    @classmethod
    def poll(cls, context):
        return bpy.data.materials

    def material_enum(self, context):
        items = [
            (material.name, material.name, "", bpy.types.UILayout.icon(material), index)
            for index, material in enumerate(bpy.data.materials)
            if material.name != "Dots Stroke" and "_BAKED" not in material.name
        ]

        return items

    material: EnumProperty(items=material_enum)

    def invoke(self, context, event):
        context.window_manager.invoke_search_popup(self)
        return {"RUNNING_MODAL"}

    def execute(self, context):
        qbaker = preferences().qbaker
        material_baker = context.scene.qbaker.material_baker
        material_baker.bake.batch_name = qbaker.bake.batch_name

        if self.material in [item.material.name for item in material_baker.materials]:
            self.report({"WARNING"}, f"{self.material}: already exists")
            return {"CANCELLED"}

        item = material_baker.materials.add()
        material_baker.material_index = len(material_baker.materials) - 1
        item.material = bpy.data.materials.get(self.material)
        item.bake.batch_name = qbaker.bake.batch_name

        context.area.tag_redraw()
        return {"FINISHED"}


class QBAKER_OT_material_load(Operator):
    """Load object materials"""

    bl_label = "Load Materials"
    bl_idname = "qbaker.material_load"
    bl_options = {"REGISTER", "INTERNAL"}

    @classmethod
    def poll(cls, context):
        return bpy.data.materials

    def execute(self, context):
        qbaker = preferences().qbaker
        material_baker = context.scene.qbaker.material_baker
        material_baker.bake.batch_name = qbaker.bake.batch_name

        for material in bpy.data.materials:
            if material.name in {"Dots Stroke"} or "_BAKED" in material.name:
                continue

            if material in [item.material for item in material_baker.materials]:
                continue

            item = material_baker.materials.add()
            material_baker.material_index = len(material_baker.materials) - 1
            item.material = material
            item.bake.batch_name = qbaker.bake.batch_name

        context.area.tag_redraw()
        return {"FINISHED"}


class QBAKER_OT_material_remove(Operator):
    bl_label = "Remove Materials"
    bl_idname = "qbaker.material_remove"
    bl_options = {"REGISTER", "INTERNAL"}

    @classmethod
    def description(cls, context, event):
        return """Remove the material.\n\nShift  •  Remove all the materials"""

    index: IntProperty()

    def invoke(self, context, event):
        self.material_baker = context.scene.qbaker.material_baker

        if not event.shift:
            return self.execute(context)

        self.material_baker.materials.clear()
        self.material_baker.material_index = 0
        context.area.tag_redraw()
        return {"FINISHED"}

    def execute(self, context):
        self.material_baker.materials.remove(self.index)
        self.material_baker.material_index = min(
            max(0, self.material_baker.material_index - 1),
            len(self.material_baker.materials) - 1,
        )
        context.area.tag_redraw()
        return {"FINISHED"}


class QBAKER_OT_material_move(Operator):
    bl_label = "Move Material"
    bl_idname = "qbaker.material_move"
    bl_options = {"REGISTER", "INTERNAL"}

    direction: EnumProperty(
        name="Direction",
        items=(
            ("UP", "Up", ""),
            ("DOWN", "Down", ""),
        ),
    )

    @classmethod
    def poll(cls, context):
        material_baker = context.scene.qbaker.material_baker
        return material_baker.materials

    @classmethod
    def description(cls, context, event):
        return "Move the active material up/down in the list"

    def execute(self, context):
        material_baker = context.scene.qbaker.material_baker

        if self.direction == "UP":
            if material_baker.material_index == len(material_baker.materials) - 1:
                material_baker.materials.move(material_baker.material_index, 0)
                material_baker.material_index = 0
            else:
                material_baker.materials.move(material_baker.material_index, material_baker.material_index + 1)
                material_baker.material_index += 1

        elif self.direction == "DOWN":
            if material_baker.material_index == 0:
                material_baker.materials.move(0, len(material_baker.materials) - 1)
                material_baker.material_index = len(material_baker.materials) - 1
            else:
                material_baker.materials.move(material_baker.material_index, material_baker.material_index - 1)
                material_baker.material_index -= 1

        return {"FINISHED"}


class QBAKER_OT_global_material_map_preset_add(AddPresetBase, Operator):
    """Add a Global Material Map Preset"""

    bl_label = "Add Global Material Map Preset"
    bl_idname = "qbaker.global_material_map_preset_add"
    preset_menu = "QBAKER_MT_global_material_map_preset"
    preset_subdir = "Q-Baker/maps/material_global"
    preset_defines = [
        "material_baker = bpy.context.scene.qbaker.material_baker",
    ]
    preset_values = [
        "material_baker.maps",
    ]


class QBAKER_OT_local_material_map_preset_add(AddPresetBase, Operator):
    """Add a Local Material Map Preset"""

    bl_label = "Add Local Material Map Preset"
    bl_idname = "qbaker.local_material_map_preset_add"
    preset_menu = "QBAKER_MT_local_material_map_preset"
    preset_subdir = "Q-Baker/maps/material_local"
    preset_defines = [
        "material_baker = bpy.context.scene.qbaker.material_baker",
        "active_material = material_baker.materials[material_baker.material_index]",
    ]
    preset_values = [
        "active_material.maps",
    ]


class QBAKER_OT_global_material_bake_preset_add(AddPresetBase, Operator):
    """Add a Global Material Bake Preset"""

    bl_label = "Add Global Material Bake Preset"
    bl_idname = "qbaker.global_material_bake_preset_add"
    preset_menu = "QBAKER_MT_global_material_bake_preset"
    preset_subdir = "Q-Baker/bake/material_global"
    preset_defines = [
        "material_baker = bpy.context.scene.qbaker.material_baker",
    ]
    preset_values = [
        "material_baker.bake",
    ]


class QBAKER_OT_local_material_bake_preset_add(AddPresetBase, Operator):
    """Add a Local Material Bake Preset"""

    bl_label = "Add Local Material Bake Preset"
    bl_idname = "qbaker.local_material_bake_preset_add"
    preset_menu = "QBAKER_MT_local_material_bake_preset"
    preset_subdir = "Q-Baker/bake/material_local"
    preset_defines = [
        "material_baker = bpy.context.scene.qbaker.material_baker",
        "active_material = material_baker.materials[material_baker.material_index]",
    ]
    preset_values = [
        "active_material.bake",
    ]


class QBAKER_OT_material_bake_folder_add(Operator):
    """Add an output folder"""

    bl_label = "Add Folder"
    bl_idname = "qbaker.material_bake_folder_add"
    bl_options = {"REGISTER", "INTERNAL"}

    directory: StringProperty(subtype="DIR_PATH")

    def invoke(self, context, event):
        context.window_manager.fileselect_add(self)
        return {"RUNNING_MODAL"}

    def execute(self, context):
        material_baker = context.scene.qbaker.material_baker

        if material_baker.use_bake_global:
            bake = material_baker.bake
        else:
            item = material_baker.materials[material_baker.material_index]
            bake = item.bake

        folder = bake.folders.add()
        bake.folder_index = len(bake.folders) - 1
        if os.path.basename(os.path.dirname(self.directory)):
            folder.name = os.path.basename(os.path.dirname(self.directory))
        else:
            folder.name = os.path.dirname(self.directory)
        folder.path = self.directory
        context.area.tag_redraw()
        return {"FINISHED"}


class QBAKER_OT_material_bake_folder_remove(Operator):
    bl_label = "Remove Folder"
    bl_idname = "qbaker.material_bake_folder_remove"
    bl_options = {"REGISTER", "INTERNAL"}

    @classmethod
    def description(cls, context, event):
        return """Remove the active output folder.\n\nShift  •  Remove all the output folders"""

    index: IntProperty()

    def invoke(self, context, event):
        material_baker = context.scene.qbaker.material_baker

        if material_baker.use_bake_global:
            self.bake = material_baker.bake
        else:
            item = material_baker.materials[material_baker.material_index]
            self.bake = item.bake

        if not event.shift:
            return self.execute(context)

        self.bake.folders.clear()
        self.bake.folder_index = 0
        return {"FINISHED"}

    def execute(self, context):
        self.bake.folders.remove(self.index)
        self.bake.folder_index = min(max(0, self.bake.folder_index - 1), len(self.bake.folders) - 1)
        return {"FINISHED"}


class QBAKER_OT_material_bake_folder_load(Operator):
    """Load output folders"""

    bl_label = "Load Folders"
    bl_idname = "qbaker.material_bake_folder_load"
    bl_options = {"REGISTER", "INTERNAL"}

    directory: bpy.props.StringProperty(subtype="DIR_PATH")

    def invoke(self, context, event):
        context.window_manager.fileselect_add(self)
        return {"RUNNING_MODAL"}

    def execute(self, context):
        material_baker = context.scene.qbaker.material_baker

        if material_baker.use_bake_global:
            self.bake = material_baker.bake
        else:
            item = material_baker.materials[material_baker.material_index]
            self.bake = item.bake

        if not self.directory:
            self.report({"WARNING"}, "Select an output assets folder")
            return {"CANCELLED"}

        self.bake.folders.clear()
        self.bake.folder_index = 0

        self.root_folder = self.bake.folders.add()
        self.bake.folder_index = len(self.bake.folders) - 1

        if os.path.basename(os.path.dirname(self.directory)):
            self.root_folder.name = os.path.basename(os.path.dirname(self.directory))
        else:
            self.root_folder.name = os.path.dirname(self.directory)

        self.root_folder.path = self.directory

        for dir in os.scandir(self.directory):
            if dir.is_dir():
                folder = self.bake.folders.add()
                folder.name = os.path.basename(dir.path)
                folder.path = bpy.path.abspath(os.path.join(dir.path, ""))
                folder.use_subfolder = True

        context.area.tag_redraw()
        return {"FINISHED"}


classes = (
    QBAKER_OT_material_add,
    QBAKER_OT_material_load,
    QBAKER_OT_material_remove,
    QBAKER_OT_material_move,
    QBAKER_OT_global_material_map_preset_add,
    QBAKER_OT_local_material_map_preset_add,
    QBAKER_OT_global_material_bake_preset_add,
    QBAKER_OT_local_material_bake_preset_add,
    QBAKER_OT_material_bake_folder_add,
    QBAKER_OT_material_bake_folder_remove,
    QBAKER_OT_material_bake_folder_load,
)


register, unregister = bpy.utils.register_classes_factory(classes)
