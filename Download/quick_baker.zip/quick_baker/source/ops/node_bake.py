import bpy
from bpy.types import Operator
from ...qbpy.image import Image
from ...qbpy.nodes.shader import ShaderNode

if bpy.app.version >= (4, 0, 0):
    from ..utils.bake_v4 import Bake
else:
    from ..utils.bake_v3 import Bake
import time


class QBAKER_OT_node_bake(Operator, Bake):
    bl_label = "Bake"
    bl_idname = "qbaker.node_bake"
    bl_options = {"REGISTER", "INTERNAL"}

    @classmethod
    def description(cls, context, event):
        return """Bake selected nodes.\n\nShift  •  Replace selected node with Baked Result"""

    @classmethod
    def poll(cls, context):
        return (
            context.area.type == "NODE_EDITOR"
            and context.material
            and context.active_node
            and context.active_node.type
            not in {
                "BSDF_PRINCIPLED",
                "TEX_IMAGE",
                "REROUTE",
                "FRAME",
                "OUTPUT_MATERIAL",
                "SCRIPT",
                "GROUP_INPUT",
                "GROUP_OUTPUT",
                "OUTPUT_AOV",
                "OUTPUT_LIGHT",
            }
            and context.active_object
            and context.selected_nodes
        )

    def invoke(self, context, event):
        self.node_baker = context.scene.qbaker.node_baker
        self.prepare_render_settings(context, samples=self.node_baker.samples)
        self.is_shift = bool(event.shift)
        self.selected_nodes = context.selected_nodes
        self.active_node = context.active_node
        self.start_time = time.time()

        if self.active_node.outputs and self.node_baker.socket not in self.active_node.outputs:
            self.node_baker.socket = self.active_node.outputs[0].name

        # check for UDIMs
        self.udims = set()
        self.udims.update(self.uv_coords_to_udims(self.create_unique_uv_coords(context.object)))
        self.udims = list(self.udims)

        self.node_socket = self.node_baker.socket
        self.bake_node = self.bake_nodes(context)
        self.timer = context.window_manager.event_timer_add(0.1, window=context.window)
        context.window_manager.modal_handler_add(self)
        return {"RUNNING_MODAL"}

    def bake_nodes(self, context):
        yield 1

        for node in self.selected_nodes:
            node_tree = node.id_data
            if node.type in {
                "BSDF_PRINCIPLED",
                "TEX_IMAGE",
                "REROUTE",
                "FRAME",
                "OUTPUT_MATERIAL",
                "SCRIPT",
                "GROUP_INPUT",
                "GROUP_OUTPUT",
                "OUTPUT_AOV",
                "OUTPUT_LIGHT",
            }:
                self.report({"WARNING"}, f"Can't bake: {node.name}")
                continue

            if node == self.active_node and self.node_baker.use_sockets:
                node_position = 28 * len(self.active_node.outputs)
                for output in self.active_node.outputs:
                    if output.type == "SHADER":
                        self.report({"WARNING"}, f"Can't bake: {output.name}")
                        continue

                    material_output_node = ShaderNode.material_output(
                        group=node_tree,
                        name="QBAKER_MATERIAL_OUTPUT",
                        label="Baking...",
                        target="CYCLES",
                        position=(node.location.x, node.location.y + node_position),
                    )
                    material_output_node.width = node.width
                    material_output_node.hide = True
                    non_color = output.type != "RGBA"
                    node_tree.links.new(output=output, input=material_output_node.inputs["Surface"])

                    if len(self.udims) > 1:
                        image = self.udim_image(
                            context,
                            self.udims,
                            name=f"{node.name} {output.name}",
                            width=self.node_baker.size_custom if self.node_baker.size == "CUSTOM" else int(self.node_baker.size),
                            height=self.node_baker.size_custom if self.node_baker.size == "CUSTOM" else int(self.node_baker.size),
                            non_color=non_color,
                        )
                    else:
                        image = Image.new_image(
                            name=f"{node.name} {output.name}",
                            width=self.node_baker.size_custom if self.node_baker.size == "CUSTOM" else int(self.node_baker.size),
                            height=self.node_baker.size_custom if self.node_baker.size == "CUSTOM" else int(self.node_baker.size),
                            non_color=non_color,
                        )

                    if node == self.active_node and output.type == "RGBA":
                        image.colorspace_settings.name = "sRGB"
                    elif node != self.active_node and node.outputs[0].type == "RGBA":
                        image.colorspace_settings.name = "sRGB"
                    else:
                        image.colorspace_settings.name = "Non-Color"

                    image_node = ShaderNode.image_texture(
                        group=node_tree,
                        name=f"{node.name} {output.name}",
                        position=(node.location.x, node.location.y + node_position),
                    )
                    image_node.width = node.width
                    image_node.hide = True
                    image_node.image = image
                    node_tree.nodes.active = image_node

                    for uv in context.object.data.uv_layers:
                        if uv.name == self.node_baker.uv_map:
                            uv.active = True

                    override = context.copy()
                    override["selected_objects"] = [context.object]

                    with context.temp_override(**override):
                        while bpy.ops.object.bake(
                            "INVOKE_DEFAULT",
                            type="EMIT",
                            margin_type=self.node_baker.margin_type,
                            margin=self.node_baker.margin,
                            use_clear=True,
                        ) != {"RUNNING_MODAL"}:
                            yield 1

                    while not image.is_dirty:
                        yield 1

                    if self.node_baker.path:
                        if len(self.udims) > 1:
                            Image.save_image_as(
                                image,
                                path=self.node_baker.path,
                                name=f"{image.name}.<UDIM>",
                            )
                        else:
                            Image.save_image_as(image, path=self.node_baker.path)

                    node_tree.nodes.remove(material_output_node)
                    node_position -= 36
            else:
                material_output_node = ShaderNode.material_output(
                    group=node_tree,
                    name="QBAKER_MATERIAL_OUTPUT",
                    label="Baking...",
                    target="CYCLES",
                    position=(node.location.x, node.location.y + 30),
                )
                material_output_node.width = node.width
                material_output_node.hide = True

                if node == self.active_node:
                    output = node.outputs[self.node_socket]
                else:
                    output = node.outputs[0]

                non_color = output.type != "RGBA"
                node_tree.links.new(output=output, input=material_output_node.inputs["Surface"])

                if len(self.udims) > 1:
                    image = self.udim_image(
                        context,
                        self.udims,
                        name=f"{node.name} {output.name}",
                        width=self.node_baker.size_custom if self.node_baker.size == "CUSTOM" else int(self.node_baker.size),
                        height=self.node_baker.size_custom if self.node_baker.size == "CUSTOM" else int(self.node_baker.size),
                        non_color=non_color,
                    )
                else:
                    image = Image.new_image(
                        name=f"{node.name} {output.name}",
                        width=self.node_baker.size_custom if self.node_baker.size == "CUSTOM" else int(self.node_baker.size),
                        height=self.node_baker.size_custom if self.node_baker.size == "CUSTOM" else int(self.node_baker.size),
                        non_color=non_color,
                    )

                if node == self.active_node and output.type == "RGBA":
                    image.colorspace_settings.name = "sRGB"
                elif node != self.active_node and node.outputs[0].type == "RGBA":
                    image.colorspace_settings.name = "sRGB"
                else:
                    image.colorspace_settings.name = "Non-Color"

                image_node = ShaderNode.image_texture(
                    group=node_tree,
                    name=f"{node.name} {output.name}",
                    position=(node.location.x, node.location.y + 30),
                )
                image_node.width = node.width
                image_node.hide = True
                image_node.image = image
                node_tree.nodes.active = image_node

                for uv in context.object.data.uv_layers:
                    if uv.name == self.node_baker.uv_map:
                        uv.active = True

                override = context.copy()
                override["selected_objects"] = [context.object]

                with context.temp_override(**override):
                    while bpy.ops.object.bake(
                        "INVOKE_DEFAULT",
                        type="EMIT",
                        margin_type=self.node_baker.margin_type,
                        margin=self.node_baker.margin,
                        use_clear=True,
                    ) != {"RUNNING_MODAL"}:
                        yield 1

                while not image.is_dirty:
                    yield 1

                if self.node_baker.path:
                    if len(self.udims) > 1:
                        Image.save_image_as(
                            image,
                            path=self.node_baker.path,
                            name=f"{image.name}.<UDIM>",
                        )
                    else:
                        Image.save_image_as(image, path=self.node_baker.path)

                if self.is_shift:
                    if node == self.active_node and node.outputs[self.node_socket].is_linked:
                        node_tree.links.new(
                            output=image_node.outputs["Color"],
                            input=node.outputs[self.node_socket].links[0].to_socket,
                        )
                    elif node != self.active_node and node.outputs[0].is_linked:
                        node_tree.links.new(
                            output=image_node.outputs["Color"],
                            input=node.outputs[0].links[0].to_socket,
                        )

                node_tree.nodes.remove(material_output_node)

        node_tree.nodes.active = self.active_node
        self.restore_render_settings(context)
        yield 0

    def modal(self, context, event):
        if event.type == "TIMER":
            result = next(self.bake_node)

            if result == 0:
                self.finish(context)
                return {"FINISHED"}

        if event.type in {"RIGHTMOUSE", "ESC"}:
            self.cancel(context)
            return {"CANCELLED"}

        return {"PASS_THROUGH"}

    def finish(self, context):
        print(f"Bake Time: {round((time.time() - self.start_time), 2)} sec")
        if self.timer:
            context.window_manager.event_timer_remove(self.timer)

    def cancel(self, context):
        self.finish(context)


classes = (QBAKER_OT_node_bake,)


register, unregister = bpy.utils.register_classes_factory(classes)
