import bpy
from bpy.types import Operator
from bpy.props import *
from ...qbpy.blender import preferences
import uuid


MAP_TYPES = {
    "PBR": [("", "PBR", "", "SHADING_RENDERED", 0), "PBR"],
    "BASE_COLOR": [
        ("BASE_COLOR", "Base Color", "Base Color / Albedo / Diffuse Map"),
        "Base Color",
    ],
    "EMISSION": [("EMISSION", "Emission", "Emission Map"), "Emission"],
    "GLOSSINESS": [
        ("GLOSSINESS", "Glossiness", "Glossiness / Smoothness Map"),
        "Glossiness",
    ],
    "METALLIC": [("METALLIC", "Metallic", "Metallic Map"), "Metallic"],
    "NORMAL": [("NORMAL", "Normal", "Normal Map"), "Normal"],
    "OCCLUSION": [("OCCLUSION", "Occlusion", "Ambient Occlusion Map"), "Occlusion"],
    "ROUGHNESS": [("ROUGHNESS", "Roughness", "Roughness Map"), "Roughness"],
    "SPECULAR": [("SPECULAR", "Specular", "Specular Map"), "Specular"],
    "CHANNEL_PACK": [
        ("CHANNEL_PACK", "Channel Pack", "Channel Pack Map"),
        "Channel Pack",
    ],
    "MESH": [("", "Mesh", "", "MESH_DATA", 0), "Mesh"],
    "ALPHA": [("ALPHA", "Alpha", "Alpha / Opacity / Transparency Map"), "Alpha"],
    "BEVEL_NORMAL": [
        ("BEVEL_NORMAL", "Bevel Normal", "Bevel Normal Map"),
        "Bevel Normal",
    ],
    "CAVITY": [("CAVITY", "Cavity", "Cavity / Concavity Map"), "Cavity"],
    "CURVATURE": [("CURVATURE", "Curvature", "Curvature Map"), "Curvature"],
    "DISPLACEMENT": [
        (
            "DISPLACEMENT",
            "Displacement",
            "Displacement / Bump Map\nBake displacement data from Multires modifier or Displacement node",
        ),
        "Displacement",
    ],
    "EDGE": [("EDGE", "Edge", "Edge / Convexity Map"), "Edge"],
    "GRADIENT": [("GRADIENT", "Gradient", "Gradient Map"), "Gradient"],
    "HEIGHT": [
        (
            "HEIGHT",
            "Heightmap",
            "Height Map\nBake height data along Z axis.\nUsed for large meshes e.g. Terrain",
        ),
        "Heightmap",
    ],
    "MATERIAL_ID": [("MATERIAL_ID", "Material ID", "Material ID Map"), "Material ID"],
    "THICKNESS": [
        ("THICKNESS", "Thickness", "Thickness / Translucency Map"),
        "Thickness",
    ],
    "TOON_SHADOW": [("TOON_SHADOW", "Toon Shadow", "Toon Shadow Map"), "Toon Shadow"],
    "VDM": [
        ("VDM", "Vector Displacement (VDM)", "Vector Displacement Map"),
        "Vector Displacement (VDM)",
    ],
    "WIREFRAME": [("WIREFRAME", "Wireframe", "Wireframe / UV Layout Map"), "Wireframe"],
    "XYZ": [("XYZ", "XYZ", "XYZ Map"), "XYZ"],
    "BSDF": [("", "Principled BSDF", "", "NODE", 0), "Principled BSDF"],
    "SUBSURFACE": [("SUBSURFACE", "Subsurface", "Subsurface Map"), "Subsurface"],
    "SUBSURFACE_COLOR": [
        ("SUBSURFACE_COLOR", "Subsurface Color", "Subsurface Color Map"),
        "Subsurface Color",
    ],
    "SUBSURFACE_IOR": [
        ("SUBSURFACE_IOR", "Subsurface IOR", "Subsurface IOR Map"),
        "Subsurface IOR",
    ],
    "SUBSURFACE_ANISOTROPY": [
        ("SUBSURFACE_ANISOTROPY", "Subsurface Anisotropy", "Subsurface Anisotropy Map"),
        "Subsurface Anisotropy",
    ],
    "SPECULAR_TINT": [
        ("SPECULAR_TINT", "Specular Tint", "Specular Tint Map"),
        "Specular Tint",
    ],
    "ANISOTROPIC": [("ANISOTROPIC", "Anisotropic", "Anisotropic Map"), "Anisotropic"],
    "ANISOTROPIC_ROT": [
        ("ANISOTROPIC_ROT", "Anisotropic Rotation", "Anisotropic Rotation Map"),
        "Anisotropic Rotation",
    ],
    "SHEEN": [("SHEEN", "Sheen", "Sheen Map"), "Sheen"],
    "SHEEN_TINT": [("SHEEN_TINT", "Sheen Tint", "Sheen Tint Map"), "Sheen Tint"],
    "CLEARCOAT": [("CLEARCOAT", "Clearcoat", "Clearcoat Map"), "Clearcoat"],
    "CLEARCOAT_ROUGHNESS": [
        ("CLEARCOAT_ROUGHNESS", "Clearcoat Roughness", "Clearcoat Roughness Map"),
        "Clearcoat Roughness",
    ],
    "IOR": [("IOR", "IOR", "IOR Map"), "IOR"],
    "TRANSMISSION_ROUGHNESS": [
        (
            "TRANSMISSION_ROUGHNESS",
            "Transmission Roughness",
            "Transmission Roughness Map",
        ),
        "Transmission Roughness",
    ],
    "EMISSION_STRENGTH": [
        ("EMISSION_STRENGTH", "Emission Strength", "Emission Strength Map"),
        "Emission Strength",
    ],
    "CLEARCOAT_NORMAL": [
        ("CLEARCOAT_NORMAL", "Clearcoat Normal", "Clearcoat Normal Map"),
        "Clearcoat Normal",
    ],
    "TANGENT": [("TANGENT", "Tangent", "Tangent Map"), "Tangent"],
    "CYCLE": [("", "Cycles", "", "SHADING_TEXTURE", 0), "Cycles"],
    "AO": [
        ("AO", "Ambient Occlusion", "Cycles Ambient Occlusion Map"),
        "Ambient Occlusion",
    ],
    "COMBINED": [("COMBINED", "Combined", "Combined Map"), "Combined"],
    "DIFFUSE": [("DIFFUSE", "Diffuse", "Diffuse Map"), "Diffuse"],
    "ENVIRONMENT": [("ENVIRONMENT", "Environment", "Environment Map"), "Environment"],
    "GLOSSY": [("GLOSSY", "Glossy", "Glossy Map"), "Glossy"],
    "POSITION": [("POSITION", "Position", "Position Map"), "Position"],
    "SHADOW": [("SHADOW", "Shadow", "Shadow Map"), "Shadow"],
    "TRANSMISSION": [
        ("TRANSMISSION", "Transmission", "Transmission Map"),
        "Transmission",
    ],
    "UV": [("UV", "UV", "UV Map"), "UV"],
}


class QBAKER_OT_map_add(Operator):
    """Add a map to be baked"""

    bl_label = "Add Map"
    bl_idname = "qbaker.map_add"
    bl_options = {"REGISTER", "INTERNAL"}

    @classmethod
    def poll(cls, context):
        baker = context.scene.qbaker
        return baker.bake_groups

    def items_type(self, context):
        return [
            *list(value[0] for value in MAP_TYPES.values()),
        ]

    type: EnumProperty(name="Map Type", description="Type of map to bake", items=items_type)

    def execute(self, context):
        baker = context.scene.qbaker

        if baker.use_map_global:
            bake_group = baker
        else:
            bake_group = baker.bake_groups[baker.bake_group_index]

        map = bake_group.maps.add()
        bake_group.map_index = len(bake_group.maps) - 1
        map.name = uuid.uuid1().hex
        map.label = MAP_TYPES[self.type][1]
        map.type = self.type
        return {"FINISHED"}


class QBAKER_OT_map_load(Operator):
    bl_label = "Load Maps"
    bl_idname = "qbaker.map_load"
    bl_options = {"REGISTER", "INTERNAL"}

    @classmethod
    def description(cls, context, event):
        return """Load maps based on Principled BSDF input sockets and values.\n\nShift  •  Load maps based on Principled BSDF input sockets"""

    @classmethod
    def poll(cls, context):
        baker = context.scene.qbaker
        bake_group = baker.bake_groups[baker.bake_group_index]
        return bake_group.groups if bake_group.use_high_to_low else bake_group.objects

    def check_inputs_sockets_values(self, node_tree, maps):
        map_type = None
        for node in node_tree.nodes:
            if node.type == "BSDF_PRINCIPLED":
                for input in node.inputs:
                    if input.name == "Base Color":
                        if input.is_linked or input.default_value[:] != (
                            0.800000011920929,
                            0.800000011920929,
                            0.800000011920929,
                            1.0,
                        ):
                            map_type = "BASE_COLOR"
                    elif input.name == "Subsurface":
                        if input.is_linked or input.default_value != 0.0:
                            map_type = "SUBSURFACE"
                    elif input.name == "Subsurface Color":
                        if input.is_linked or input.default_value[:] != (
                            0.800000011920929,
                            0.800000011920929,
                            0.800000011920929,
                            1.0,
                        ):
                            map_type = "SUBSURFACE_COLOR"
                    elif input.name == "Subsurface IOR":
                        if input.is_linked or input.default_value != 1.399999976158142:
                            map_type = "SUBSURFACE_IOR"
                    elif input.name == "Subsurface Anisotropy":
                        if input.is_linked or input.default_value != 0.0:
                            map_type = "SUBSURFACE_ANISOTROPY"
                    elif input.name == "Metallic":
                        if input.is_linked or input.default_value != 0.0:
                            map_type = "METALLIC"
                    elif input.name == "Specular":
                        if input.is_linked or input.default_value != 0.5:
                            map_type = "SPECULAR"
                    elif input.name == "Specular Tint":
                        if input.is_linked or input.default_value != 0.0:
                            map_type = "SPECULAR_TINT"
                    elif input.name == "Roughness":
                        if input.is_linked or input.default_value != 0.5:
                            map_type = "ROUGHNESS"
                    elif input.name == "Anisotropic":
                        if input.is_linked or input.default_value != 0.0:
                            map_type = "ANISOTROPIC"
                    elif input.name == "Anisotropic Rotation":
                        if input.is_linked or input.default_value != 0.0:
                            map_type = "ANISOTROPIC_ROT"
                    elif input.name == "Sheen":
                        if input.is_linked or input.default_value != 0.0:
                            map_type = "SHEEN"
                    elif input.name == "Sheen Tint":
                        if input.is_linked or input.default_value != 0.5:
                            map_type = "SHEEN_TINT"
                    elif input.name == "Clearcoat":
                        if input.is_linked or input.default_value != 0.0:
                            map_type = "CLEARCOAT"
                    elif input.name == "Clearcoat Roughness":
                        if input.is_linked or input.default_value != 0.029999999329447746:
                            map_type = "CLEARCOAT_ROUGHNESS"
                    elif input.name == "IOR":
                        if input.is_linked or input.default_value != 1.4500000476837158:
                            map_type = "IOR"
                    elif input.name == "Transmission":
                        if input.is_linked or input.default_value != 0.0:
                            map_type = "TRANSMISSION"
                    elif input.name == "Transmission Roughness":
                        if input.is_linked or input.default_value != 0.0:
                            map_type = "TRANSMISSION_ROUGHNESS"
                    elif input.name == "Emission":
                        if input.is_linked or input.default_value[:] != (
                            0.0,
                            0.0,
                            0.0,
                            1.0,
                        ):
                            map_type = "EMISSION"
                    elif input.name == "Emission Strength":
                        if input.is_linked or input.default_value != 1.0:
                            map_type = "EMISSION_STRENGTH"
                    elif input.name == "Alpha":
                        if input.is_linked or input.default_value != 1.0:
                            map_type = "ALPHA"
                    elif input.name == "Normal" and input.is_linked:
                        map_type = "NORMAL"
                    elif input.name == "Clearcoat Normal" and input.is_linked:
                        map_type = "CLEARCOAT_NORMAL"
                    elif input.name == "Tangent" and input.is_linked:
                        map_type = "TANGENT"

                    if map_type and all(map.type != map_type for map in maps):
                        bpy.ops.qbaker.map_add(type=map_type)

            elif node.type == "GROUP":
                self.check_inputs_sockets_values(node_tree=node.node_tree, maps=maps)

            elif node.type == "OUTPUT_MATERIAL":
                if node.inputs["Displacement"].is_linked:
                    map_type = "DISPLACEMENT"

                    if map_type and all(map.type != map_type for map in maps):
                        bpy.ops.qbaker.map_add(type=map_type)

    def check_inputs_sockets(self, node_tree, maps):
        map_type = None
        for node in node_tree.nodes:
            if node.type == "BSDF_PRINCIPLED":
                for input in node.inputs:
                    if input.name == "Base Color" and input.is_linked:
                        map_type = "BASE_COLOR"
                    elif input.name == "Subsurface" and input.is_linked:
                        map_type = "SUBSURFACE"
                    elif input.name == "Subsurface Color" and input.is_linked:
                        map_type = "SUBSURFACE_COLOR"
                    elif input.name == "Subsurface IOR" and input.is_linked:
                        map_type = "SUBSURFACE_IOR"
                    elif input.name == "Subsurface Anisotropy" and input.is_linked:
                        map_type = "SUBSURFACE_ANISOTROPY"
                    elif input.name == "Metallic" and input.is_linked:
                        map_type = "METALLIC"
                    elif input.name == "Specular" and input.is_linked:
                        map_type = "SPECULAR"
                    elif input.name == "Specular Tint" and input.is_linked:
                        map_type = "SPECULAR_TINT"
                    elif input.name == "Roughness" and input.is_linked:
                        map_type = "ROUGHNESS"
                    elif input.name == "Anisotropic" and input.is_linked:
                        map_type = "ANISOTROPIC"
                    elif input.name == "Anisotropic Rotation" and input.is_linked:
                        map_type = "ANISOTROPIC_ROT"
                    elif input.name == "Sheen" and input.is_linked:
                        map_type = "SHEEN"
                    elif input.name == "Sheen Tint" and input.is_linked:
                        map_type = "SHEEN_TINT"
                    elif input.name == "Clearcoat" and input.is_linked:
                        map_type = "CLEARCOAT"
                    elif input.name == "Clearcoat Roughness" and input.is_linked:
                        map_type = "CLEARCOAT_ROUGHNESS"
                    elif input.name == "IOR" and input.is_linked:
                        map_type = "IOR"
                    elif input.name == "Transmission" and input.is_linked:
                        map_type = "TRANSMISSION"
                    elif input.name == "Transmission Roughness" and input.is_linked:
                        map_type = "TRANSMISSION_ROUGHNESS"
                    elif input.name == "Emission" and input.is_linked:
                        map_type = "EMISSION"
                    elif input.name == "Emission Strength" and input.is_linked:
                        map_type = "EMISSION_STRENGTH"
                    elif input.name == "Alpha" and input.is_linked:
                        map_type = "ALPHA"
                    elif input.name == "Normal" and input.is_linked:
                        map_type = "NORMAL"
                    elif input.name == "Clearcoat Normal" and input.is_linked:
                        map_type = "CLEARCOAT_NORMAL"
                    elif input.name == "Tangent" and input.is_linked:
                        map_type = "TANGENT"

                    if map_type and all(map.type != map_type for map in maps):
                        bpy.ops.qbaker.map_add(type=map_type)

            elif node.type == "GROUP":
                self.check_inputs_sockets(node_tree=node.node_tree, maps=maps)

            elif node.type == "OUTPUT_MATERIAL":
                if node.inputs["Displacement"].is_linked:
                    map_type = "DISPLACEMENT"

                    if map_type and all(map.type != map_type for map in maps):
                        bpy.ops.qbaker.map_add(type=map_type)

    def invoke(self, context, event):
        baker = context.scene.qbaker
        bake_group = baker.bake_groups[baker.bake_group_index]
        maps = baker.maps if baker.use_map_global else bake_group.maps

        if bake_group.use_high_to_low:
            objects = []
            for group in bake_group.groups:
                objects.extend(item.object for item in group.low_poly)
        else:
            objects = [item.object for item in bake_group.objects]

        for object in objects:
            if object.material_slots:
                for slot in object.material_slots:
                    if slot.material and slot.material.use_nodes:
                        node_tree = slot.material.node_tree

                        if event.shift:
                            self.check_inputs_sockets(node_tree, maps)
                        else:
                            self.check_inputs_sockets_values(node_tree, maps)

        return {"FINISHED"}


class QBAKER_OT_map_remove(Operator):
    bl_label = "Remove"
    bl_idname = "qbaker.map_remove"
    bl_options = {"REGISTER", "INTERNAL"}

    @classmethod
    def description(cls, context, event):
        return """Remove Map.\n\nShift  •  Remove all the maps"""

    index: IntProperty()

    @classmethod
    def poll(cls, context):
        baker = context.scene.qbaker

        if baker.use_map_global:
            bake_group = baker
        else:
            bake_group = baker.bake_groups[baker.bake_group_index]

        return bake_group.maps

    def invoke(self, context, event):
        self.baker = context.scene.qbaker

        if self.baker.use_map_global:
            self.bake_group = self.baker
        else:
            self.bake_group = self.baker.bake_groups[self.baker.bake_group_index]

        if event.shift:
            self.bake_group.maps.clear()
            self.bake_group.map_index = 0
        else:
            self.bake_group.maps.remove(self.index)
            self.bake_group.map_index = min(max(0, self.bake_group.map_index - 1), len(self.bake_group.maps) - 1)

        for item in self.baker.bake_groups[self.baker.bake_group_index].objects:
            if item.object.material_slots:
                for slot in item.object.material_slots:
                    if slot.material and slot.material.use_nodes:
                        node_tree = slot.material.node_tree
                        for node in node_tree.nodes:
                            if node.name.split("_")[0] == "QB":
                                node_tree.nodes.remove(node)
        return {"FINISHED"}


classes = (
    QBAKER_OT_map_add,
    QBAKER_OT_map_load,
    QBAKER_OT_map_remove,
)


register, unregister = bpy.utils.register_classes_factory(classes)
