import bpy
from . import bake_group
from . import group
from . import bake
from . import material_bake
from . import node_bake
from . import vertex_color

if bpy.app.version >= (4, 0, 0):
    from . import map_v4 as map
    from . import bake_v4 as bake_op
    from . import material_map_v4 as material_map
    from . import material_bake_v4 as material_bake_op
else:
    from . import map_v3 as map
    from . import bake_v3 as bake_op
    from . import material_map_v3 as material_map
    from . import material_bake_v3 as material_bake_op


def register():
    bake_group.register()
    group.register()
    bake.register()
    material_bake.register()
    node_bake.register()
    vertex_color.register()

    map.register()
    bake_op.register()
    material_map.register()
    material_bake_op.register()


def unregister():
    bake_group.unregister()
    group.unregister()
    bake.unregister()
    material_bake.unregister()
    node_bake.unregister()
    vertex_color.unregister()

    map.unregister()
    bake_op.unregister()
    material_map.unregister()
    material_bake_op.unregister()
