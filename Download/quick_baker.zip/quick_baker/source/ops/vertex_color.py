import bpy
from bpy.types import Operator
from bpy.props import FloatVectorProperty


class QBAKER_OT_vertex_color(Operator):
    bl_label = "Apply"
    bl_idname = "qbaker.vertex_color"
    bl_description = "Set Vertex Color"
    bl_options = {"UNDO"}

    @classmethod
    def poll(cls, context):
        if hasattr(context.space_data, "shading"):
            return context.space_data.shading.type != "WIREFRAME"

    def execute(self, context):
        baker = context.scene.qbaker
        mesh = context.object.data
        vertex_color = mesh.vertex_colors.get(baker.vertex_color_name or "VertexColor")
        if not vertex_color:
            vertex_color = mesh.vertex_colors.new(name=baker.vertex_color_name or "VertexColor", do_init=True)

        bpy.ops.object.mode_set(mode="VERTEX_PAINT")
        mesh.use_paint_mask = True
        bpy.data.brushes["Draw"].color = baker.vertex_color
        bpy.ops.paint.vertex_color_set("INVOKE_DEFAULT")
        bpy.ops.object.mode_set(mode="EDIT")
        context.space_data.shading.color_type = "VERTEX"

        return {"FINISHED"}


class QBAKER_OT_vertex_color_preset(Operator):
    """Vertex color preset"""

    bl_label = ""
    bl_idname = "qbaker.vertex_color_preset"
    bl_options = {"REGISTER", "INTERNAL"}

    preset: FloatVectorProperty(
        name="",
        subtype="COLOR_GAMMA",
        size=3,
        min=0.0,
        max=1.0,
        default=(1, 1, 1),
    )

    @classmethod
    def poll(cls, context):
        if hasattr(context.space_data, "shading"):
            return context.space_data.shading.type != "WIREFRAME"

    def execute(self, context):
        baker = context.scene.qbaker
        baker.vertex_color = self.preset
        bpy.ops.qbaker.vertex_color()

        return {"FINISHED"}


classes = (
    QBAKER_OT_vertex_color,
    QBAKER_OT_vertex_color_preset,
)


register, unregister = bpy.utils.register_classes_factory(classes)
