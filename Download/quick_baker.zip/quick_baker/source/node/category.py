import bpy
import nodeitems_utils
from nodeitems_utils import NodeCategory, NodeItem, NodeItemCustom


class BakeNodeCategory(NodeCategory):
    @classmethod
    def poll(cls, context):
        return context.space_data.tree_type == "BakeNodeTree"


class NodeOperator(NodeItemCustom):
    def __init__(self, operator, text=None, icon="BLANK1", poll=None):
        self.operator = operator
        self.text = text
        self.icon = icon
        self.poll = poll

    @staticmethod
    def draw(self, layout, context):
        layout.operator(self.operator, text=self.text, icon=self.icon)


class NodeSeparator(NodeItemCustom):
    def __init__(self, poll=None):
        self.poll = poll

    @classmethod
    def poll(cls, context):
        return context.space_data.tree_type == "BakeNodeTree"

    @staticmethod
    def draw(self, layout, context):
        layout.separator()


node_categories = [
    BakeNodeCategory(
        "INPUT",
        "Input",
        items=[
            NodeItem("BakeNodeFloat"),
            NodeItem("BakeNodeInteger"),
            NodeItem("BakeNodeVector"),
        ],
    ),
    BakeNodeCategory(
        "TEXTURE",
        "Texture",
        items=[
            NodeItem("BakeNodeAlbedo"),
            NodeItem("BakeNodeAmbientOcclusion"),
            NodeItem("BakeNodeColorID"),
            NodeItem("BakeNodeCurvature"),
            NodeItem("BakeNodeDisplacement"),
            NodeItem("BakeNodeEmission"),
            NodeItem("BakeNodeMetallic"),
            NodeItem("BakeNodeNormal"),
            NodeItem("BakeNodeRoughness"),
            NodeItem("BakeNodeUV"),
        ],
    ),
    BakeNodeCategory(
        "UTILITIES",
        "Utilities",
        items=[
            NodeItem("BakeNodeBake"),
            NodeItem("BakeNodeBakeGroup"),
            NodeItem("BakeNodeGroupBake"),
            NodeItem("BakeNodeMap"),
            NodeSeparator(),
            NodeItem("BakeNodePrint"),
        ],
    ),
    BakeNodeCategory(
        "VECTOR",
        "Vector",
        items=[
            NodeItem("BakeNodeCombineRGB"),
        ],
    ),
    BakeNodeCategory(
        "GROUP",
        "Group",
        items=[
            NodeOperator("node.group_make"),
            NodeOperator("node.group_ungroup"),
            NodeSeparator(),
            NodeItem("NodeGroupInput"),
            NodeItem("NodeGroupOutput"),
        ],
    ),
    BakeNodeCategory(
        "LAYOUT",
        "Layout",
        items=[
            NodeItem("NodeFrame"),
            NodeItem("NodeReroute"),
        ],
    ),
]


def register():
    nodeitems_utils.register_node_categories("BAKE", node_categories)


def unregister():
    nodeitems_utils.unregister_node_categories("BAKE")
