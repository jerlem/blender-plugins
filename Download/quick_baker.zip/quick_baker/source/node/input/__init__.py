import bpy
from .float import BakeNodeFloat
from .integer import BakeNodeInteger
from .vector import BakeNodeVector


classes = (
    BakeNodeFloat,
    BakeNodeInteger,
    BakeNodeVector,
)


def register():
    for cls in classes:
        bpy.utils.register_class(cls)


def unregister():
    for cls in reversed(classes):
        bpy.utils.unregister_class(cls)
