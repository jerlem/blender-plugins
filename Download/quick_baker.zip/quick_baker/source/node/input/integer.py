import bpy
from bpy.props import *
from ..node import BakeNode


class BakeNodeInteger(BakeNode):
    """Integer Map Node"""

    bl_label = "Integer"

    integer: IntProperty(
        name="",
    )

    def init(self, context):
        self.output("NodeSocketInt", "Integer")

    def draw_buttons(self, context, layout):
        layout.prop(
            self,
            "integer",
        )
