import bpy
from bpy.props import *
from ..node import BakeNode


class BakeNodeVector(BakeNode):
    """Vector Map Node"""

    bl_label = "Vector"

    vector: FloatVectorProperty(
        name="",
    )

    def init(self, context):
        self.output("NodeSocketVector", "Vector")

    def draw_buttons(self, context, layout):
        col = layout.column(align=True)
        col.prop(self, "vector")
