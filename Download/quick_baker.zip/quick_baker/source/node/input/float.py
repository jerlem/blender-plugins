import bpy
from bpy.props import *
from ..node import BakeNode


class BakeNodeFloat(BakeNode):
    """Float Map Node"""

    bl_label = "Float"

    float: FloatProperty(
        name="Float",
    )

    def init(self, context):
        self.output(
            "NodeSocketFloat",
            "Float",
        )

    def draw_buttons(self, context, layout):
        layout.prop(
            self,
            "float",
        )

    def process(self, context, id, path):
        self.outputs[0].default_value = self.float
        self.update()
        # self.execute(context)
