import bpy
from bpy.types import Operator
from ...qbpy.node_tree import Tree


class BakeNodeTree(Tree):
    """Bake Nodes"""

    bl_label = "Bake Node Editor"
    bl_icon = "TEXTURE"


class QBAKER_OT_node_tree_new(Operator):
    """Creates a new bake nodes tree"""

    bl_label = "New Bake Node Tree"
    bl_idname = "bake.new"
    bl_options = {"REGISTER", "INTERNAL"}

    @classmethod
    def poll(cls, context):
        return context.space_data.type == "NODE_EDITOR" and context.space_data.tree_type == "BakeNodeTree"

    def execute(self, context):
        node_tree = bpy.data.node_groups.new("Bake Nodes", "BakeNodeTree")
        node_tree.use_fake_user = True
        context.space_data.node_tree = node_tree

        bake = node_tree.nodes.new("BakeNodeBake")
        group_bake = node_tree.nodes.new("BakeNodeGroupBake")

        bake.location = [-120, 0]
        group_bake.location = [120, 0]

        node_tree.links.new(bake.outputs[0], group_bake.inputs[0])

        bpy.ops.node.view_selected()

        return {"FINISHED"}


classes = (
    BakeNodeTree,
    QBAKER_OT_node_tree_new,
)


def register():
    for cls in classes:
        bpy.utils.register_class(cls)


def unregister():
    for cls in reversed(classes):
        bpy.utils.unregister_class(cls)
