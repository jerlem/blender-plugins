import bpy
from .bake import BakeNodeBake
from .bake_group import BakeNodeBakeGroup
from .group_bake import BakeNodeGroupBake
from .map import BakeNodeMap
from .print import BakeNodePrint


classes = (
    BakeNodeBake,
    BakeNodeBakeGroup,
    BakeNodeGroupBake,
    BakeNodeMap,
    BakeNodePrint,
)


def register():
    for cls in classes:
        bpy.utils.register_class(cls)


def unregister():
    for cls in reversed(classes):
        bpy.utils.unregister_class(cls)
