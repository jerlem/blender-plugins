import bpy
from ..node import BakeNode


class BakeNodePrint(BakeNode):
    """Print Node"""

    bl_label = "Print"

    def init(self, context):
        self.input("NodeSocketBool", "Bool")
        self.input("NodeSocketCollection", "Collection")
        self.input("NodeSocketColor", "Color")
        self.input("NodeSocketFloat", "Float")
        self.input("NodeSocketFloatAngle", "Float Angle")
        self.input("NodeSocketFloatDistance", "Float Distance")
        self.input("NodeSocketFloatFactor", "Float Factor")
        self.input("NodeSocketFloatPercentage", "Float Percentage")
        self.input("NodeSocketFloatTime", "Float Time")
        self.input("NodeSocketFloatTimeAbsolute", "Float Time Absolute")
        self.input("NodeSocketFloatUnsigned", "Float Unsigned")
        self.input("NodeSocketGeometry", "Geometry")
        self.input("NodeSocketImage", "Image")
        self.input("NodeSocketInt", "Int")
        self.input("NodeSocketIntFactor", "Int Factor")
        self.input("NodeSocketIntPercentage", "Int Percentage")
        self.input("NodeSocketIntUnsigned", "Int Unsigned")
        self.input("NodeSocketMaterial", "Material")
        self.input("NodeSocketObject", "Object")
        self.input("NodeSocketShader", "Shader")
        self.input("NodeSocketString", "String")
        self.input("NodeSocketTexture", "Texture")
        self.input("NodeSocketVector", "Vector")
        self.input("NodeSocketVectorAcceleration", "Vector Acceleration")
        self.input("NodeSocketVectorDirection", "Vector Direction")
        self.input("NodeSocketVectorEuler", "Vector Euler")
        self.input("NodeSocketVectorTranslation", "Vector Translation")
        self.input("NodeSocketVectorVelocity", "Vector Velocity")
        self.input("NodeSocketVectorXYZ", "Vector XYZ")
        self.input("NodeSocketVirtual", "Virtual")
