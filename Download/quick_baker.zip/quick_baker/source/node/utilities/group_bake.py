import bpy
from bpy.props import *
from ..node import BakeNode


class BakeNodeGroupBake(BakeNode):
    """Group Bake Node"""

    bl_label = "Group Bake"

    def init(self, context):
        self.input("NodeSocketVirtual", "Bake")

    def draw_buttons(self, context, layout):
        layout.scale_y = 1.4
        layout.operator("qbaker.node_bake")
