import bpy
from bpy.props import *
from ..node import BakeNode


class BakeNodeMap(BakeNode):
    """Map Node"""

    bl_label = "Map"

    def init(self, context):
        self.input("NodeSocketVirtual", "Texture")

        self.output("NodeSocketVirtual", "Map")
