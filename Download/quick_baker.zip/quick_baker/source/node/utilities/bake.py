import bpy
from bpy.props import *
from mathutils import Vector
from ..node import BakeNode


class BakeNodeBake(BakeNode):
    """Bake Node"""

    bl_label = "Bake"
    bl_width_default = 200

    filepath: StringProperty(
        name="Path",
        description="Filepath used for saving the baked textures",
        subtype="FILE_PATH",
    )

    size: EnumProperty(
        name="Size",
        description="Texture size",
        items=(
            ("512", "512", "512x512"),
            ("1024", "1024", "1024x1024"),
            ("2048", "2048", "2048x2048"),
            ("4096", "4096", "4096x4096"),
            ("8192", "8192", "8192x8192"),
        ),
        default="1024",
    )

    format: EnumProperty(
        name="Format",
        description="Texture format",
        items=(
            ("PNG", "PNG", "Output image in PNG format"),
            ("JPEG", "JPEG", "Output image in JPEG format"),
            ("EXR", "EXR", "Output image in OpenEXR format"),
            ("TGA", "TGA", "Output image in Targa format"),
            ("TIFF", "TIFF", "Output image in TIFF format"),
        ),
    )

    color_depth: EnumProperty(
        name="Color Depth",
        description="Bit depth per channel",
        items=(
            ("8", "8", ""),
            ("16", "16", ""),
        ),
    )

    compression: IntProperty(
        name="Compression",
        description="Amount of time to determine best compression: 0 = no compression with fast file output, 100 = maximum lossless compression with slow file output",
        subtype="PERCENTAGE",
        min=0,
        max=100,
        default=15,
    )

    extrusion: FloatProperty(
        name="Extrusion",
        description="Inflate the active object by the specified distance for baking. This helps matching to points nearer to the outside of the selected object meshes.",
        subtype="DISTANCE",
    )

    ray_distance: FloatProperty(
        name="Ray Distance",
        description="The maximum ray distance for matching points between the active and selected objects. If zero, there is no limit.",
        subtype="DISTANCE",
    )

    margin_size: IntProperty(
        name="Margin",
        description="Extends the baked result as a post process filter",
        subtype="PIXEL",
        default=8,
    )

    use_clear: BoolProperty(
        name="Clear Image",
        description="Clear the image before baking (internal only",
        default=True,
    )

    def init(self, context):
        self.input("NodeSocketVirtual", "Object")
        self.input("NodeSocketVirtual", "Map")
        self.output("NodeSocketVirtual", "Bake")

    def draw_buttons(self, context, layout):
        layout.use_property_decorate = False
        layout.use_property_split = True

        col = layout.column()
        col.prop(self, "filepath")
        col.prop(self, "size")
        col.prop(self, "format")

        row = col.row()
        row.prop(self, "color_depth", expand=True)

        col.separator()
        col.prop(self, "compression")
        col.prop(self, "extrusion")
        col.prop(self, "ray_distance")
        col.prop(self, "margin_size")
        col.prop(self, "use_clear")

        col = layout.column()
        col.scale_y = 1.4
        col.operator("qbaker.bake", text="Bake")
        layout.separator()
