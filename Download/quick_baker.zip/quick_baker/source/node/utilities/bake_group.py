import bpy
from bpy.props import *
from ..node import BakeNode


class BakeNodeBakeGroup(BakeNode):
    """Bake Group Node"""

    bl_label = "Bake Group"

    high_poly: PointerProperty(type=bpy.types.Object)
    low_poly: PointerProperty(type=bpy.types.Object)

    def init(self, context):
        self.output("NodeSocketVirtual", "Objects")

    def draw_buttons(self, context, layout):
        layout.prop(self, "high_poly")
        layout.prop(self, "low_poly")
