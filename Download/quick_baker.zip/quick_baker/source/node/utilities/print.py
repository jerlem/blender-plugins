import bpy
from bpy.props import *
from mathutils import Vector
from ..node import BakeNode


class BakeNodePrint(BakeNode):
    """Print Node"""

    bl_label = "Print"

    default_value: StringProperty(
        name="Result Value",
    )

    def init(self, context):
        self.input("NodeSocketString", "Print")

    def draw_buttons(self, context, layout):
        layout.prop(self, "default_value", text="")

    def process(self, context, id, path):
        self.default_value = f"{self.inputs[0].default_value}"
        self.update()
        self.execute(context)
