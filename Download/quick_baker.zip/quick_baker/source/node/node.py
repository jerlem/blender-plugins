import bpy
from bpy.types import Operator
from ...qbpy.node import Node


class BakeNode(Node):
    bl_label = "Bake Node"

    @classmethod
    def poll(cls, node_tree):
        return node_tree.bl_idname in {"BakeNodeTree"}


class QBAKER_OT_node_bake(Operator):
    "Bake Node"

    bl_label = "Bake"
    bl_idname = "qbaker.node_bake"
    bl_options = {"REGISTER", "UNDO"}

    def execute(self, context):
        return {"FINISHED"}


classes = (
    BakeNode,
    QBAKER_OT_node_bake,
)


def register():
    for cls in classes:
        bpy.utils.register_class(cls)


def unregister():
    for cls in reversed(classes):
        bpy.utils.unregister_class(cls)
