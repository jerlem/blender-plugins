import bpy
from bpy.props import *
from ..node import BakeNode


class BakeNodeNormal(BakeNode):
    """Normal Map Node"""

    bl_label = "Normal"
    bl_icon = "TEXTURE"

    size: EnumProperty(
        name="Size",
        description="Size of the map",
        items=(
            ("512", "512", "512x512"),
            ("1024", "1024", "1024x1024"),
            ("2048", "2048", "2048x2048"),
            ("4096", "4096", "4096x4096"),
            ("8192", "8192", "8192x8192"),
        ),
        default="2048",
    )

    suffix: StringProperty(
        name="Suffix",
        description="Suffix of the map",
        default="Normal",
    )

    space: EnumProperty(
        name="Space",
        description="Choose normal space for baking",
        items=(
            ("TANGENT", "Tangent", "Bake the normals in tangent space"),
            ("OBJECT", "Object", "Bake the normals in object space"),
        ),
    )

    type: EnumProperty(
        name="Type",
        description="Normal type",
        items=(
            ("OPENGL", "OpenGL", ""),
            ("DIRECTX", "DirectX", ""),
            ("CUSTOM", "Custom", ""),
        ),
    )

    normal_r: EnumProperty(
        name="R",
        description="Axis to bake in red channel",
        items=(
            ("+X", "+X", ""),
            ("+Y", "+Y", ""),
            ("+Z", "+Z", ""),
            ("-X", "-X", ""),
            ("-Y", "-Y", ""),
            ("-Z", "-Z", ""),
        ),
    )

    normal_g: EnumProperty(
        name="G",
        description="Axis to bake in green channel",
        items=(
            ("+X", "+X", ""),
            ("+Y", "+Y", ""),
            ("+Z", "+Z", ""),
            ("-X", "-X", ""),
            ("-Y", "-Y", ""),
            ("-Z", "-Z", ""),
        ),
    )

    normal_b: EnumProperty(
        name="B",
        description="Axis to bake in blue channel",
        items=(
            ("+X", "+X", ""),
            ("+Y", "+Y", ""),
            ("+Z", "+Z", ""),
            ("-X", "-X", ""),
            ("-Y", "-Y", ""),
            ("-Z", "-Z", ""),
        ),
    )

    def init(self, context):
        self.input("NodeSocketInt", "Sample", default=32)

        self.output("NodeSocketColor", "Color")

    def draw_buttons(self, context, layout):
        layout.use_property_split = True
        layout.use_property_decorate = False

        col = layout.column()
        col.prop(self, "size")
        col.prop(self, "suffix")

        col = layout.column()
        col.prop(self, "space")
        col.prop(self, "type")
        if self.type == "CUSTOM":
            col = col.column(align=True)
            col.prop(self, "normal_r")
            col.prop(self, "normal_g")
            col.prop(self, "normal_b")
