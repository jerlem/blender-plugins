import bpy
from bpy.props import *
from ..node import BakeNode


class BakeNodeAmbientOcclusion(BakeNode):
    """Ambient Occlusion Map Node"""

    bl_label = "Ambient Occlusion"
    bl_icon = "TEXTURE"

    size: EnumProperty(
        name="Size",
        description="Size of the map",
        items=(
            ("512", "512", "512x512"),
            ("1024", "1024", "1024x1024"),
            ("2048", "2048", "2048x2048"),
            ("4096", "4096", "4096x4096"),
            ("8192", "8192", "8192x8192"),
        ),
        default="2048",
    )

    suffix: StringProperty(
        name="Suffix",
        description="Suffix of the map",
        default="AO",
    )

    def init(self, context):
        self.input("NodeSocketInt", "Sample", default=32)

        self.output("NodeSocketFloat", "Float")

    def draw_buttons(self, context, layout):
        layout.use_property_split = True
        layout.use_property_decorate = False

        col = layout.column()
        col.prop(self, "size")
        col.prop(self, "suffix")
