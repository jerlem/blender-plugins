import bpy
from .albedo import BakeNodeAlbedo
from .ambient_occlusion import BakeNodeAmbientOcclusion
from .color_id import BakeNodeColorID
from .curvature import BakeNodeCurvature
from .displacement import BakeNodeDisplacement
from .emission import BakeNodeEmission
from .metallic import BakeNodeMetallic
from .normal import BakeNodeNormal
from .roughness import BakeNodeRoughness
from .uv import BakeNodeUV


classes = (
    BakeNodeAlbedo,
    BakeNodeAmbientOcclusion,
    BakeNodeColorID,
    BakeNodeCurvature,
    BakeNodeDisplacement,
    BakeNodeEmission,
    BakeNodeMetallic,
    BakeNodeNormal,
    BakeNodeRoughness,
    BakeNodeUV,
)


def register():
    for cls in classes:
        bpy.utils.register_class(cls)


def unregister():
    for cls in reversed(classes):
        bpy.utils.unregister_class(cls)
