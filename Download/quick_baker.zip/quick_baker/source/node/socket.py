import bpy
from bpy.props import *
from ...qbpy.socket import Socket


def update_node(self, context):
    try:
        self.node.execute_tree()
    except Exception as e:
        print(e)


class BakeNodeSocket(Socket):
    bl_label = "BakeNodeSocket"
    compatible_sockets = ["BakeNodeSocketResult"]


class BakeNodeSocketBool(BakeNodeSocket):
    bl_label = "BakeNodeSocketBool"
    color = (0.9, 0.7, 1.0, 1)
    default_value: BoolProperty(default=False, update=update_node)


class BakeNodeSocketInt(BakeNodeSocket):
    bl_label = "BakeNodeSocketInt"
    color = (0, 0.9, 0.1, 1)
    default_value: IntProperty(default=0, update=update_node)


class BakeNodeSocketFloat(BakeNodeSocket):
    bl_label = "BakeNodeSocketFloat"
    color = (0.5, 0.5, 0.5, 1)
    default_value: FloatProperty(default=0, update=update_node)


class BakeNodeSocketString(BakeNodeSocket):
    bl_label = "BakeNodeSocketString"
    color = (0.2, 0.7, 1.0, 1)
    default_value: StringProperty(default="", update=update_node)


class BakeNodeSocketVector(BakeNodeSocket):
    bl_label = "BakeNodeSocketVector"
    color = (0.5, 0.3, 1.0, 1)
    default_value: FloatVectorProperty(name="Vector", default=(0, 0, 0), subtype="NONE", update=update_node)


class BakeNodeSocketXYZ(BakeNodeSocket):
    bl_label = "BakeNodeSocketXYZ"
    default_value: FloatVectorProperty(name="Vector", default=(1.0, 1.0, 1.0), subtype="XYZ", update=update_node)


class BakeNodeSocketResult(BakeNodeSocket):
    bl_label = "BakeNodeSocketResult"
    color = (0.5, 0.5, 0.5, 1)
    compatible_sockets = [
        BakeNodeSocket,
        BakeNodeSocketBool,
        BakeNodeSocketInt,
        BakeNodeSocketFloat,
        BakeNodeSocketVector,
        BakeNodeSocketString,
        BakeNodeSocketXYZ,
    ]


classes = (
    BakeNodeSocket,
    BakeNodeSocketBool,
    BakeNodeSocketInt,
    BakeNodeSocketFloat,
    BakeNodeSocketVector,
    BakeNodeSocketString,
    BakeNodeSocketXYZ,
    BakeNodeSocketResult,
)


def register():
    for cls in classes:
        bpy.utils.register_class(cls)


def unregister():
    for cls in classes:
        bpy.utils.unregister_class(cls)
