import bpy
from bl_ui.space_node import NODE_MT_editor_menus
from . import category
from . import input
from . import node
from . import socket
from . import texture
from . import tree
from . import utilities
from . import vector


"""Replace the node editor header with an override to place our own custom 'Create node tree' operator."""
node_header_draw = bpy.types.NODE_HT_header.draw


def node_header_draw_override(self, context):
    layout = self.layout

    snode = context.space_data
    overlay = snode.overlay
    id_from = snode.id_from
    tool_settings = context.tool_settings

    qbaker = context.scene.qbaker
    bake_group = qbaker.bake_groups[qbaker.bake_group_index]

    if not snode.node_tree and snode.tree_type == "BakeNodeTree":
        layout.template_header()
        NODE_MT_editor_menus.draw_collapsible(context, layout)
        layout.separator_spacer()

        layout.template_ID(snode, "node_tree", new="bake.new")
        layout.separator_spacer()

        # Snap
        row = layout.row(align=True)
        row.prop(tool_settings, "use_snap_node", text="")
        row.prop(tool_settings, "snap_node_element", icon_only=True)
        if tool_settings.snap_node_element != "GRID":
            row.prop(tool_settings, "snap_target", text="")

        # Overlay toggle & popover
        row = layout.row(align=True)
        row.prop(overlay, "show_overlays", icon="OVERLAY", text="")
        sub = row.row(align=True)
        sub.active = overlay.show_overlays
        sub.popover(panel="NODE_PT_overlay", text="")
    elif snode.node_tree and snode.tree_type == "BakeNodeTree":
        layout.template_header()
        NODE_MT_editor_menus.draw_collapsible(context, layout)
        layout.separator_spacer()

        layout.template_ID(snode, "node_tree", new="bake.new")
        layout.separator_spacer()

        # Snap
        row = layout.row(align=True)
        row.prop(tool_settings, "use_snap_node", text="")
        row.prop(tool_settings, "snap_node_element", icon_only=True)
        if tool_settings.snap_node_element != "GRID":
            row.prop(tool_settings, "snap_target", text="")

        # Overlay toggle & popover
        row = layout.row(align=True)
        row.prop(overlay, "show_overlays", icon="OVERLAY", text="")
        sub = row.row(align=True)
        sub.active = overlay.show_overlays
        sub.popover(panel="NODE_PT_overlay", text="")
    else:
        node_header_draw(self, context)


def register():
    category.register()
    input.register()
    node.register()
    socket.register()
    texture.register()
    tree.register()
    utilities.register()
    vector.register()
    bpy.types.NODE_HT_header.draw = node_header_draw_override


def unregister():
    category.unregister()
    input.unregister()
    node.unregister()
    socket.unregister()
    texture.unregister()
    tree.unregister()
    utilities.unregister()
    vector.unregister()
    bpy.types.NODE_HT_header.draw = node_header_draw
