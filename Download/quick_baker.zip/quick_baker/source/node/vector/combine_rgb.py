import bpy
from bpy.props import *
from mathutils import Vector
from ..node import BakeNode


class BakeNodeCombineRGB(BakeNode):
    """Combine RGB Node"""

    bl_label = "Combine RGB"

    def init(self, context):
        self.input("NodeSocketFloat", "R")
        self.input("NodeSocketFloat", "G")
        self.input("NodeSocketFloat", "B")
        self.input("NodeSocketFloat", "A")

        self.output("NodeSocketColor", "Color")
