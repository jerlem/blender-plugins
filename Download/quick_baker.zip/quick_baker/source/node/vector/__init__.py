import bpy
from .combine_rgb import BakeNodeCombineRGB


classes = (BakeNodeCombineRGB,)


def register():
    for cls in classes:
        bpy.utils.register_class(cls)


def unregister():
    for cls in reversed(classes):
        bpy.utils.unregister_class(cls)
