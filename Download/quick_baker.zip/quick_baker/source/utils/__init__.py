import bpy
from . import icon
from . import manual

if bpy.app.version >= (4, 0, 0):
    from . import props_v4 as props
else:
    from . import props_v3 as props


def register():
    icon.register()
    props.register()
    manual.register()


def unregister():
    icon.unregister()
    props.unregister()
    manual.unregister()
