import bpy


def sockets(self, context):
    if context.active_node and context.active_node.outputs:
        return [(output.name, output.name, "") for output in context.active_node.outputs]
    else:
        return [
            ("NONE", "None", ""),
        ]


def uv_maps(self, context):
    if context.object and context.object.type == "MESH":
        return [(uv.name, uv.name, "") for uv in context.object.data.uv_layers]
    else:
        return [
            ("NONE", "None", ""),
        ]


def update_uv_map(self, context):
    if context.object is None or context.object.data is None or not hasattr(context.object.data, "uv_layers"):
        return
    context.object.data.uv_layers.active = context.object.data.uv_layers[self.uv_map]
