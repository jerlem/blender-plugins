import bpy
from ...qbpy.nodes.shader import ShaderNode


class QBAKER_map_preview:
    position = (1000000000, 0)

    def ao_preview(self, context):
        baker = context.scene.qbaker
        bake_group = baker.bake_groups[baker.bake_group_index]

        if self.use_preview:
            for map in baker.maps:
                map.cavity.use_preview = False
                map.curvature.use_preview = False
                map.edge.use_preview = False
                map.gradient.use_preview = False
                map.thickness.use_preview = False
                map.toon_shadow.use_preview = False
                map.xyz.use_preview = False

        for item in bake_group.objects:
            if baker.maps and item.object.material_slots:
                for slot in item.object.material_slots:
                    if slot.material and slot.material.use_nodes:
                        self.node_tree = slot.material.node_tree

                        if self.use_preview:
                            context.scene.cycles.preview_samples = self.samples

                        # nodes
                        ao_node = ShaderNode.ambient_occlusion(
                            group=self.node_tree,
                            name="QB_AMBIENT_OCCLUSION",
                            samples=128,
                            only_local=self.only_local,
                            distance=self.distance,
                            position=self.position,
                        )
                        invert_node = ShaderNode.invert(
                            group=self.node_tree,
                            name="QB_INVERT",
                            position=self.position,
                        )
                        invert_node.mute = not self.invert_ao
                        emission_node = ShaderNode.emission(
                            group=self.node_tree,
                            name="QB_EMISSION",
                            position=self.position,
                        )
                        material_output_node = ShaderNode.material_output(
                            group=self.node_tree,
                            name="QB_MATERIAL_OUTPUT",
                            target="CYCLES",
                            position=self.position,
                        )
                        self.node_tree.nodes.active = material_output_node

                        # links
                        self.node_tree.links.new(
                            output=ao_node.outputs["AO"],
                            input=invert_node.inputs["Color"],
                        )
                        self.node_tree.links.new(
                            output=invert_node.outputs["Color"],
                            input=emission_node.inputs["Color"],
                        )
                        self.node_tree.links.new(
                            output=emission_node.outputs["Emission"],
                            input=material_output_node.inputs["Surface"],
                        )

        if not self.use_preview:
            self.remove_nodes(context)

    def cavity_preview(self, context):
        baker = context.scene.qbaker
        bake_group = baker.bake_groups[baker.bake_group_index]

        if self.use_preview:
            for map in baker.maps:
                map.occlusion.use_preview = False
                map.curvature.use_preview = False
                map.edge.use_preview = False
                map.gradient.use_preview = False
                map.thickness.use_preview = False
                map.toon_shadow.use_preview = False
                map.xyz.use_preview = False

        for item in bake_group.objects:
            if baker.maps and item.object.material_slots:
                for slot in item.object.material_slots:
                    if slot.material and slot.material.use_nodes:
                        self.node_tree = slot.material.node_tree

                        # nodes
                        geometry_node = ShaderNode.geometry(
                            group=self.node_tree,
                            name="QB_GEOMETRY",
                            position=self.position,
                        )
                        c_ramp_node = ShaderNode.color_ramp(
                            group=self.node_tree,
                            name="QB_COLOR_RAMP",
                            position=self.position,
                        )
                        c_ramp_node.color_ramp.elements[0].position = 0.4
                        c_ramp_node.color_ramp.elements[1].position = 0.5
                        math_node = ShaderNode.math(
                            group=self.node_tree,
                            name="QB_MATH",
                            operation="POWER",
                            input_1=self.power,
                            position=self.position,
                        )
                        invert_node = ShaderNode.invert(
                            group=self.node_tree,
                            name="QB_INVERT",
                            position=self.position,
                        )
                        invert_node.mute = not self.invert_cavity
                        emission_node = ShaderNode.emission(
                            group=self.node_tree,
                            name="QB_EMISSION",
                            position=self.position,
                        )
                        material_output_node = ShaderNode.material_output(
                            group=self.node_tree,
                            name="QB_MATERIAL_OUTPUT",
                            target="CYCLES",
                            position=self.position,
                        )
                        self.node_tree.nodes.active = material_output_node

                        # links
                        self.node_tree.links.new(
                            output=geometry_node.outputs["Pointiness"],
                            input=c_ramp_node.inputs["Fac"],
                        )
                        self.node_tree.links.new(
                            output=c_ramp_node.outputs["Color"],
                            input=math_node.inputs[0],
                        )
                        self.node_tree.links.new(
                            output=math_node.outputs["Value"],
                            input=invert_node.inputs["Color"],
                        )
                        self.node_tree.links.new(
                            output=invert_node.outputs["Color"],
                            input=emission_node.inputs["Color"],
                        )
                        self.node_tree.links.new(
                            output=emission_node.outputs["Emission"],
                            input=material_output_node.inputs["Surface"],
                        )

        if not self.use_preview:
            self.remove_nodes(context)

    def curvature_preview(self, context):
        baker = context.scene.qbaker
        bake_group = baker.bake_groups[baker.bake_group_index]

        if self.use_preview:
            for map in baker.maps:
                map.occlusion.use_preview = False
                map.cavity.use_preview = False
                map.edge.use_preview = False
                map.gradient.use_preview = False
                map.thickness.use_preview = False
                map.toon_shadow.use_preview = False
                map.xyz.use_preview = False

        for item in bake_group.objects:
            if baker.maps and item.object.material_slots:
                for slot in item.object.material_slots:
                    if slot.material and slot.material.use_nodes:
                        self.node_tree = slot.material.node_tree

                        # nodes
                        geometry_node = ShaderNode.geometry(
                            group=self.node_tree,
                            name="QB_GEOMETRY",
                            position=self.position,
                        )
                        c_ramp_node = ShaderNode.color_ramp(
                            group=self.node_tree,
                            name="QB_COLOR_RAMP",
                            position=self.position,
                        )
                        c_ramp_node.color_ramp.elements[0].position = 0.45
                        c_ramp_node.color_ramp.elements[1].position = 0.55
                        math_node = ShaderNode.math(
                            group=self.node_tree,
                            name="QB_MATH",
                            operation="POWER",
                            input_1=self.power,
                            position=self.position,
                        )
                        invert_node = ShaderNode.invert(
                            group=self.node_tree,
                            name="QB_INVERT",
                            position=self.position,
                        )
                        invert_node.mute = not self.invert_curvature
                        emission_node = ShaderNode.emission(
                            group=self.node_tree,
                            name="QB_EMISSION",
                            position=self.position,
                        )
                        material_output_node = ShaderNode.material_output(
                            group=self.node_tree,
                            name="QB_MATERIAL_OUTPUT",
                            target="CYCLES",
                            position=self.position,
                        )
                        self.node_tree.nodes.active = material_output_node

                        # links
                        self.node_tree.links.new(
                            output=geometry_node.outputs["Pointiness"],
                            input=c_ramp_node.inputs["Fac"],
                        )
                        self.node_tree.links.new(
                            output=c_ramp_node.outputs["Color"],
                            input=math_node.inputs[0],
                        )
                        self.node_tree.links.new(
                            output=math_node.outputs["Value"],
                            input=invert_node.inputs["Color"],
                        )
                        self.node_tree.links.new(
                            output=invert_node.outputs["Color"],
                            input=emission_node.inputs["Color"],
                        )
                        self.node_tree.links.new(
                            output=emission_node.outputs["Emission"],
                            input=material_output_node.inputs["Surface"],
                        )

        if not self.use_preview:
            self.remove_nodes(context)

    def edge_preview(self, context):
        baker = context.scene.qbaker
        bake_group = baker.bake_groups[baker.bake_group_index]

        if self.use_preview:
            for map in baker.maps:
                map.occlusion.use_preview = False
                map.cavity.use_preview = False
                map.curvature.use_preview = False
                map.gradient.use_preview = False
                map.thickness.use_preview = False
                map.toon_shadow.use_preview = False
                map.xyz.use_preview = False

        for item in bake_group.objects:
            if baker.maps and item.object.material_slots:
                for slot in item.object.material_slots:
                    if slot.material and slot.material.use_nodes:
                        self.node_tree = slot.material.node_tree

                        if self.use_preview:
                            context.scene.cycles.preview_samples = self.samples

                        # nodes
                        bevel_node = ShaderNode.bevel(
                            group=self.node_tree,
                            name="QB_EDGE_BEVEL",
                            samples=128,
                            radius=self.radius,
                            position=self.position,
                        )
                        geometry_node = ShaderNode.geometry(
                            group=self.node_tree,
                            name="QB_GEOMETRY",
                            position=self.position,
                        )
                        vector_math_node = ShaderNode.vector_math(
                            group=self.node_tree,
                            name="QB_DOT_PRODUCT",
                            operation="DOT_PRODUCT",
                            position=self.position,
                        )
                        invert_node = ShaderNode.invert(
                            group=self.node_tree,
                            name="QB_INVERT",
                            position=self.position,
                        )
                        invert_node.mute = self.invert_edge
                        emission_node = ShaderNode.emission(
                            group=self.node_tree,
                            name="QB_EMISSION",
                            position=self.position,
                        )
                        material_output_node = ShaderNode.material_output(
                            group=self.node_tree,
                            name="QB_MATERIAL_OUTPUT",
                            target="CYCLES",
                            position=self.position,
                        )
                        self.node_tree.nodes.active = material_output_node

                        # links
                        self.node_tree.links.new(
                            output=bevel_node.outputs["Normal"],
                            input=vector_math_node.inputs[0],
                        )
                        self.node_tree.links.new(
                            output=geometry_node.outputs["Normal"],
                            input=vector_math_node.inputs[1],
                        )
                        self.node_tree.links.new(
                            output=vector_math_node.outputs["Value"],
                            input=invert_node.inputs["Color"],
                        )
                        self.node_tree.links.new(
                            output=invert_node.outputs["Color"],
                            input=emission_node.inputs["Color"],
                        )
                        self.node_tree.links.new(
                            output=emission_node.outputs["Emission"],
                            input=material_output_node.inputs["Surface"],
                        )

        if not self.use_preview:
            self.remove_nodes(context)

    def gradient_preview(self, context):
        if self.direction == "X":
            self.suffix = "Gradient_X"
        elif self.direction == "XYZ":
            self.suffix = "Gradient_XYZ"
        elif self.direction == "Y":
            self.suffix = "Gradient_Y"
        elif self.direction == "Z":
            self.suffix = "Gradient_Z"

        baker = context.scene.qbaker
        bake_group = baker.bake_groups[baker.bake_group_index]

        if self.use_preview:
            for map in baker.maps:
                map.occlusion.use_preview = False
                map.cavity.use_preview = False
                map.curvature.use_preview = False
                map.edge.use_preview = False
                map.thickness.use_preview = False
                map.toon_shadow.use_preview = False
                map.xyz.use_preview = False

        for item in bake_group.objects:
            if baker.maps and item.object.material_slots:
                for slot in item.object.material_slots:
                    if slot.material and slot.material.use_nodes:
                        self.node_tree = slot.material.node_tree

                        # nodes
                        texture_coordinate_node = ShaderNode.texture_coordinate(
                            group=self.node_tree,
                            name="QB_TEXTURE_COORDINATE",
                            position=self.position,
                        )
                        separate_xyz_node = ShaderNode.separate_xyz(
                            group=self.node_tree,
                            name="QB_SEPARATE_XYZ",
                            position=self.position,
                        )
                        combine_xyz_node = ShaderNode.combine_xyz(
                            group=self.node_tree,
                            name="QB_COMBINE_XYZ",
                            position=self.position,
                        )
                        gradient_texture_node = ShaderNode.gradient_texture(
                            group=self.node_tree,
                            name="QB_TEXTURE",
                            position=self.position,
                        )
                        map_range_node = ShaderNode.map_range(
                            group=self.node_tree,
                            name="QB_MAP_RANGE",
                            type="SMOOTHERSTEP",
                            position=self.position,
                        )
                        invert_node = ShaderNode.invert(
                            group=self.node_tree,
                            name="QB_INVERT",
                            position=self.position,
                        )
                        invert_node.mute = not self.invert_gradient
                        material_output_node = ShaderNode.material_output(
                            group=self.node_tree,
                            name="QB_MATERIAL_OUTPUT",
                            target="CYCLES",
                            position=self.position,
                        )
                        self.node_tree.nodes.active = material_output_node

                        # links
                        if self.direction == "XYZ":
                            self.node_tree.links.new(
                                output=texture_coordinate_node.outputs["Generated"],
                                input=invert_node.inputs["Color"],
                            )

                        elif self.direction in {"X", "Y", "Z"}:
                            self.node_tree.links.new(
                                output=texture_coordinate_node.outputs["Generated"],
                                input=separate_xyz_node.inputs["Vector"],
                            )
                            if self.direction == "X":
                                self.node_tree.links.new(
                                    output=separate_xyz_node.outputs["X"],
                                    input=invert_node.inputs["Color"],
                                )
                            if self.direction == "Y":
                                self.node_tree.links.new(
                                    output=separate_xyz_node.outputs["Y"],
                                    input=invert_node.inputs["Color"],
                                )
                            if self.direction == "Z":
                                self.node_tree.links.new(
                                    output=separate_xyz_node.outputs["Z"],
                                    input=invert_node.inputs["Color"],
                                )

                        self.node_tree.links.new(
                            output=invert_node.outputs["Color"],
                            input=material_output_node.inputs["Surface"],
                        )

        if not self.use_preview:
            self.remove_nodes(context)

    def thickness_preview(self, context):
        baker = context.scene.qbaker
        bake_group = baker.bake_groups[baker.bake_group_index]

        if self.use_preview:
            for map in baker.maps:
                map.occlusion.use_preview = False
                map.cavity.use_preview = False
                map.curvature.use_preview = False
                map.edge.use_preview = False
                map.gradient.use_preview = False
                map.toon_shadow.use_preview = False
                map.xyz.use_preview = False

        for item in bake_group.objects:
            if baker.maps and item.object.material_slots:
                for slot in item.object.material_slots:
                    if slot.material and slot.material.use_nodes:
                        self.node_tree = slot.material.node_tree

                        if self.use_preview:
                            context.scene.cycles.preview_samples = self.samples

                        # nodes
                        ao_node = ShaderNode.ambient_occlusion(
                            group=self.node_tree,
                            name="QB_AMBIENT_OCCLUSION",
                            samples=128,
                            inside=True,
                            only_local=True,
                            distance=self.distance,
                            position=self.position,
                        )
                        invert_node = ShaderNode.invert(
                            group=self.node_tree,
                            name="QB_INVERT",
                            position=self.position,
                        )
                        invert_node.mute = not self.invert_thickness
                        emission_node = ShaderNode.emission(
                            group=self.node_tree,
                            name="QB_EMISSION",
                            position=self.position,
                        )
                        material_output_node = ShaderNode.material_output(
                            group=self.node_tree,
                            name="QB_MATERIAL_OUTPUT",
                            target="CYCLES",
                            position=self.position,
                        )
                        self.node_tree.nodes.active = material_output_node

                        # links
                        self.node_tree.links.new(
                            output=ao_node.outputs["AO"],
                            input=invert_node.inputs["Color"],
                        )
                        self.node_tree.links.new(
                            output=invert_node.outputs["Color"],
                            input=emission_node.inputs["Color"],
                        )
                        self.node_tree.links.new(
                            output=emission_node.outputs["Emission"],
                            input=material_output_node.inputs["Surface"],
                        )

        if not self.use_preview:
            self.remove_nodes(context)

    def toon_shadow_preview(self, context):
        baker = context.scene.qbaker
        bake_group = baker.bake_groups[baker.bake_group_index]

        if self.use_preview:
            for map in baker.maps:
                map.occlusion.use_preview = False
                map.cavity.use_preview = False
                map.curvature.use_preview = False
                map.edge.use_preview = False
                map.gradient.use_preview = False
                map.thickness.use_preview = False
                map.xyz.use_preview = False

        for item in bake_group.objects:
            if baker.maps and item.object.material_slots:
                for slot in item.object.material_slots:
                    if slot.material and slot.material.use_nodes:
                        self.node_tree = slot.material.node_tree

                        if self.use_preview:
                            context.scene.cycles.preview_samples = self.samples

                        # nodes
                        toon_bsdf_node = ShaderNode.toon_bsdf(
                            group=self.node_tree,
                            name="QB_TOON_BSDF",
                            component="DIFFUSE",
                            color=(1, 1, 1, 1),
                            size=self.size,
                            smooth=self.smooth,
                            position=self.position,
                        )
                        material_output_node = ShaderNode.material_output(
                            group=self.node_tree,
                            name="QB_MATERIAL_OUTPUT",
                            target="CYCLES",
                            position=self.position,
                        )
                        self.node_tree.nodes.active = material_output_node

                        # links
                        self.node_tree.links.new(
                            output=toon_bsdf_node.outputs["BSDF"],
                            input=material_output_node.inputs["Surface"],
                        )

        if not self.use_preview:
            self.remove_nodes(context)

    def xyz_preview(self, context):
        if self.direction == "X":
            self.suffix = "X"
        elif self.direction == "XYZ":
            self.suffix = "XYZ"
        elif self.direction == "Y":
            self.suffix = "Y"
        elif self.direction == "Z":
            self.suffix = "Z"

        baker = context.scene.qbaker
        bake_group = baker.bake_groups[baker.bake_group_index]

        if self.use_preview:
            for map in baker.maps:
                map.occlusion.use_preview = False
                map.cavity.use_preview = False
                map.curvature.use_preview = False
                map.edge.use_preview = False
                map.gradient.use_preview = False
                map.thickness.use_preview = False
                map.toon_shadow.use_preview = False

        for item in bake_group.objects:
            if baker.maps and item.object.material_slots:
                for slot in item.object.material_slots:
                    if slot.material and slot.material.use_nodes:
                        self.node_tree = slot.material.node_tree

                        # nodes
                        texture_coordinate_node = ShaderNode.texture_coordinate(
                            group=self.node_tree,
                            name="QB_TEXTURE_COORDINATE",
                            position=self.position,
                        )
                        separate_xyz_node = ShaderNode.separate_xyz(
                            group=self.node_tree,
                            name="QB_SEPARATE_XYZ",
                            position=self.position,
                        )
                        combine_xyz_node = ShaderNode.combine_xyz(
                            group=self.node_tree,
                            name="QB_COMBINE_XYZ",
                            position=self.position,
                        )
                        gradient_texture_node = ShaderNode.gradient_texture(
                            group=self.node_tree,
                            name="QB_TEXTURE",
                            position=self.position,
                        )
                        map_range_node = ShaderNode.map_range(
                            group=self.node_tree,
                            name="QB_MAP_RANGE",
                            type="SMOOTHERSTEP",
                            position=self.position,
                        )
                        vector_math_node = ShaderNode.vector_math(
                            group=self.node_tree,
                            name="QB_VECTOR_MATH",
                            operation="MULTIPLY",
                            input_1=(-1, -1, -1),
                            position=self.position,
                        )
                        vector_math_node.mute = not self.invert_xyz
                        emission_node = ShaderNode.emission(
                            group=self.node_tree,
                            name="QB_EMISSION",
                            position=self.position,
                        )
                        material_output_node = ShaderNode.material_output(
                            group=self.node_tree,
                            name="QB_MATERIAL_OUTPUT",
                            target="CYCLES",
                            position=self.position,
                        )
                        self.node_tree.nodes.active = material_output_node

                        # links
                        self.node_tree.links.new(
                            output=texture_coordinate_node.outputs["Normal"],
                            input=separate_xyz_node.inputs["Vector"],
                        )

                        if self.direction == "XYZ":
                            self.node_tree.links.new(
                                output=separate_xyz_node.outputs["X"],
                                input=combine_xyz_node.inputs["X"],
                            )
                            self.node_tree.links.new(
                                output=separate_xyz_node.outputs["Y"],
                                input=combine_xyz_node.inputs["Y"],
                            )
                            self.node_tree.links.new(
                                output=separate_xyz_node.outputs["Z"],
                                input=combine_xyz_node.inputs["Z"],
                            )
                            self.node_tree.links.new(
                                output=combine_xyz_node.outputs["Vector"],
                                input=vector_math_node.inputs[0],
                            )
                            self.node_tree.links.new(
                                output=vector_math_node.outputs["Vector"],
                                input=emission_node.inputs["Color"],
                            )

                        elif self.direction in {"X", "Y", "Z"}:
                            if self.direction == "X":
                                self.node_tree.links.new(
                                    output=separate_xyz_node.outputs["X"],
                                    input=vector_math_node.inputs[0],
                                )
                            if self.direction == "Y":
                                self.node_tree.links.new(
                                    output=separate_xyz_node.outputs["Y"],
                                    input=vector_math_node.inputs[0],
                                )
                            if self.direction == "Z":
                                self.node_tree.links.new(
                                    output=separate_xyz_node.outputs["Z"],
                                    input=vector_math_node.inputs[0],
                                )

                            self.node_tree.links.new(
                                output=vector_math_node.outputs["Vector"],
                                input=gradient_texture_node.inputs["Vector"],
                            )
                            self.node_tree.links.new(
                                output=gradient_texture_node.outputs["Color"],
                                input=map_range_node.inputs["Value"],
                            )
                            self.node_tree.links.new(
                                output=map_range_node.outputs["Result"],
                                input=emission_node.inputs["Color"],
                            )

                        self.node_tree.links.new(
                            output=emission_node.outputs["Emission"],
                            input=material_output_node.inputs["Surface"],
                        )

        if not self.use_preview:
            self.remove_nodes(context)

    def remove_nodes(self, context):
        baker = context.scene.qbaker
        bake_group = baker.bake_groups[baker.bake_group_index]

        for item in bake_group.objects:
            if baker.maps and item.object.material_slots:
                for slot in item.object.material_slots:
                    if slot.material and slot.material.use_nodes:
                        self.node_tree = slot.material.node_tree
                        for node in self.node_tree.nodes:
                            if node.name.split("_")[0] == "QB":
                                self.node_tree.nodes.remove(node)
