import bpy
import os


class ExportUVLayout:
    def wireframe(self, context, bake_group, map):
        if bake_group.use_high_to_low:
            objects = []
            for group in bake_group.groups:
                objects.extend(item.object for item in group.low_poly)
        else:
            objects = [item.object for item in bake_group.objects]

        size = map.wireframe.size_custom if map.wireframe.size == "CUSTOM" else int(map.wireframe.size)

        if map.wireframe.size == "512":
            self.size_name = "512"
        elif map.wireframe.size == "1024":
            self.size_name = "1K"
        elif map.wireframe.size == "2048":
            self.size_name = "2K"
        elif map.wireframe.size == "4096":
            self.size_name = "4K"
        elif map.wireframe.size == "8192":
            self.size_name = "8K"
        elif map.wireframe.size == "CUSTOM":
            self.size_name = str(map.wireframe.size_custom)

        if bake_group.bake.batch_name:
            name = (
                bake_group.bake.batch_name.replace("$name", bake_group.name.strip())
                .replace("$size", self.size_name)
                .replace("$type", map.wireframe.suffix.strip())
            )
        else:
            name = f"{bake_group.name.strip()}_{map.wireframe.suffix.strip()}"

        if path := self.bake_settings.folders[self.bake_settings.folder_index].path:
            if self.bake_settings.sub_folder:
                filepath = os.path.join(path, f"{bake_group.name}", name)
            else:
                filepath = os.path.join(path, name)
        else:
            filepath = bpy.app.tempdir + name

        filepath = bpy.path.ensure_ext(filepath, f".{map.wireframe.format.lower()}")
        meshes = list(self.iter_meshes_to_export(context, objects, map))
        polygon_data = list(self.iter_polygon_data_to_draw(context, meshes, map))
        different_colors = {color for _, color in polygon_data}

        if map.wireframe.modified:
            depsgraph = context.evaluated_depsgraph_get()
            for obj in self.iter_objects_to_export(context, objects):
                obj_eval = obj.evaluated_get(depsgraph)
                obj_eval.to_mesh_clear()

        export = self.get_exporter(map)
        export(filepath, polygon_data, different_colors, size, size, map.wireframe)

    def iter_meshes_to_export(self, context, objects, map):
        depsgraph = context.evaluated_depsgraph_get()
        for obj in self.iter_objects_to_export(context, objects):
            if map.wireframe.modified:
                yield obj.evaluated_get(depsgraph).to_mesh()
            else:
                yield obj.data

    @staticmethod
    def iter_objects_to_export(context, objects):
        for obj in objects:
            mesh = obj.data
            if mesh.uv_layers.active is None:
                continue
            yield obj

    @staticmethod
    def currently_image_image_editor(context):
        return isinstance(context.space_data, bpy.types.SpaceImageEditor)

    def get_currently_opened_image(self, context):
        return context.space_data.image if self.currently_image_image_editor(context) else None

    def get_image_size(self, context):
        # fallback if not in image context
        image_width = self.size[0]
        image_height = self.size[1]

        # get size of "active" image if some exist
        image = self.get_currently_opened_image(context)
        if image is not None:
            width, height = image.size
            if width and height:
                image_width = width
                image_height = height

        return image_width, image_height

    def iter_polygon_data_to_draw(self, context, meshes, map):
        for mesh in meshes:
            uv_layer = mesh.uv_layers.active.data
            for polygon in mesh.polygons:
                if map.wireframe.export_all or polygon.select:
                    start = polygon.loop_start
                    end = start + polygon.loop_total
                    uvs = tuple(tuple(uv.uv) for uv in uv_layer[start:end])
                    yield (uvs, self.get_polygon_color(mesh, polygon))

    @staticmethod
    def get_polygon_color(mesh, polygon, default=(0.8, 0.8, 0.8, 1)):
        if polygon.material_index < len(mesh.materials):
            material = mesh.materials[polygon.material_index]
            if material is not None:
                return tuple(material.diffuse_color)
        return default

    def get_exporter(self, map):
        if map.wireframe.format == "PNG":
            from . import export_uv_png

            return export_uv_png.export
        elif map.wireframe.format == "EPS":
            from . import export_uv_eps

            return export_uv_eps.export
        elif map.wireframe.format == "SVG":
            from . import export_uv_svg

            return export_uv_svg.export
        else:
            assert False
