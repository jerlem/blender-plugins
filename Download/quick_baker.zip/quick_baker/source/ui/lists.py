import bpy
from bpy.types import UIList


class QBAKER_UL_bake_group(UIList):
    def draw_item(self, context, layout, data, item, icon, active_data, active_propname, index):
        row = layout.row(align=True)
        row.prop(
            item,
            "use_bake",
            text="",
            icon="CHECKBOX_HLT" if item.use_bake else "CHECKBOX_DEHLT",
            emboss=False,
        )
        row.prop(item, "name", text="", emboss=False)
        row.operator("qbaker.bake_group_remove", text="", icon="X", emboss=False).index = index


class QBAKER_UL_group(UIList):
    def draw_item(self, context, layout, data, item, icon, active_data, active_propname, index):
        row = layout.row(align=True)
        row.prop(
            item,
            "use_bake",
            text="",
            icon="CHECKBOX_HLT" if item.use_bake else "CHECKBOX_DEHLT",
            emboss=False,
        )
        row.prop(item, "name", text="", emboss=False)
        row.operator("qbaker.group_remove", text="", icon="X", emboss=False).index = index


class QBAKER_UL_high_poly(UIList):
    def draw_item(self, context, layout, data, item, icon, active_data, active_propname, index):
        row = layout.row(align=True)

        if item.object:
            row.prop(item.object, "name", text="", icon="OBJECT_DATA", emboss=False)
        else:
            row.label(text="")

        row.operator("qbaker.high_poly_remove", text="", icon="X", emboss=False).index = index


class QBAKER_UL_low_poly(UIList):
    def draw_item(self, context, layout, data, item, icon, active_data, active_propname, index):
        row = layout.row(align=True)

        if item.object:
            row.prop(item.object, "name", text="", icon="OBJECT_DATA", emboss=False)
        else:
            row.label(text="")

        row.operator("qbaker.low_poly_remove", text="", icon="X", emboss=False).index = index


class QBAKER_UL_object(UIList):
    def draw_item(self, context, layout, data, item, icon, active_data, active_propname, index):
        row = layout.row(align=True)

        if item.object:
            row.prop(item.object, "name", text="", icon="OBJECT_DATA", emboss=False)
        else:
            row.label(text="")

        row.operator("qbaker.object_remove", text="", icon="X", emboss=False).index = index


class QBAKER_UL_material_group(UIList):
    def draw_item(self, context, layout, data, item, icon, active_data, active_propname, index):
        row = layout.row(align=True)

        if item.material:
            icon = bpy.types.UILayout.icon(item.material)
            row.prop(item.material, "name", text="", icon_value=icon, emboss=False)
        else:
            row.label(text="")

        row.operator("qbaker.material_group_remove", text="", icon="X", emboss=False).index = index


class QBAKER_UL_material(UIList):
    def draw_item(self, context, layout, data, item, icon, active_data, active_propname, index):
        row = layout.row(align=True)

        if item.material:
            icon = bpy.types.UILayout.icon(item.material)
            row.prop(item.material, "name", text="", icon_value=icon, emboss=False)
        else:
            row.label(text="")

        row.operator("qbaker.material_remove", text="", icon="X", emboss=False).index = index


class QBAKER_UL_map(UIList):
    def draw_item(self, context, layout, data, item, icon, active_data, active_propname, index):
        row = layout.row(align=True)
        row.prop(
            item,
            "use_bake",
            text="",
            icon="CHECKBOX_HLT" if item.use_bake else "CHECKBOX_DEHLT",
            emboss=False,
        )
        row.prop(item, "label", text="", emboss=False)

        baker = context.scene.qbaker
        bake_group = baker.bake_groups[baker.bake_group_index]

        if not bake_group.use_high_to_low:
            self.draw_use_preview(item, row)

        row.operator("qbaker.map_remove", text="", icon="X", emboss=False).index = index

    def draw_use_preview(self, item, row):
        type_to_attr = {
            "OCCLUSION": "occlusion",
            "CAVITY": "cavity",
            "CURVATURE": "curvature",
            "EDGE": "edge",
            "GRADIENT": "gradient",
            "THICKNESS": "thickness",
            "TOON_SHADOW": "toon_shadow",
            "XYZ": "xyz",
        }

        if item.type in type_to_attr:
            attr = getattr(item, type_to_attr[item.type])
            row.prop(
                attr,
                "use_preview",
                text="",
                icon="RESTRICT_VIEW_OFF" if attr.use_preview else "RESTRICT_VIEW_ON",
                emboss=False,
            )


class QBAKER_UL_material_map(UIList):
    def draw_item(self, context, layout, data, item, icon, active_data, active_propname, index):
        row = layout.row(align=True)
        row.prop(
            item,
            "use_bake",
            text="",
            icon="CHECKBOX_HLT" if item.use_bake else "CHECKBOX_DEHLT",
            emboss=False,
        )
        row.prop(item, "label", text="", emboss=False)
        row.operator("qbaker.material_bake_map_remove", text="", icon="X", emboss=False).index = index


class QBAKER_UL_folder(UIList):
    def draw_item(self, context, layout, data, item, icon, active_data, active_propname, index):
        row = layout.row(align=True)
        if item.use_subfolder:
            row.label(text="", icon="BLANK1")
        row.prop(item, "name", text="", icon="FILE_FOLDER", emboss=False)
        row.operator("qbaker.folder_remove", text="", icon="X", emboss=False).index = index


class QBAKER_UL_material_folder(UIList):
    def draw_item(self, context, layout, data, item, icon, active_data, active_propname, index):
        row = layout.row(align=True)
        if item.use_subfolder:
            row.label(text="", icon="BLANK1")
        row.prop(item, "name", text="", icon="FILE_FOLDER", emboss=False)
        row.operator("qbaker.material_bake_folder_remove", text="", icon="X", emboss=False).index = index


classes = (
    QBAKER_UL_bake_group,
    QBAKER_UL_group,
    QBAKER_UL_high_poly,
    QBAKER_UL_low_poly,
    QBAKER_UL_object,
    QBAKER_UL_material_group,
    QBAKER_UL_material,
    QBAKER_UL_map,
    QBAKER_UL_material_map,
    QBAKER_UL_folder,
    QBAKER_UL_material_folder,
)


register, unregister = bpy.utils.register_classes_factory(classes)
