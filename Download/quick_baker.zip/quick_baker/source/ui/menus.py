import bpy
from bpy.types import Menu
import os


def operator_preset(layout, text, filepath, menu):
    result = layout.operator("script.execute_preset", text=text)
    result.filepath = filepath
    result.menu_idname = menu
    return result


class QBAKER_MT_global_map_preset(Menu):
    bl_label = "Global Map Presets"
    preset_operator = "script.execute_preset"
    preset_subdir = "Q-Baker/maps/global"
    preset_add_operator = "qbaker.global_map_preset_add"
    preset_operator_defaults = {"menu_idname": "QBAKER_MT_global_map_preset"}

    def draw(self, context):
        layout = self.layout.column()
        preset_dir = os.path.join(os.path.dirname(__file__), "../../presets/maps")
        operator_preset(
            layout,
            "Unity (Standard)",
            f"{preset_dir}/global/Unity_Standard.py",
            "QBAKER_MT_global_map_preset",
        )

        if bpy.app.version >= (4, 0, 0):
            operator_preset(
                layout,
                "Unity (Standard Specular)",
                f"{preset_dir}/global/Unity_Standard_Specular.py",
                "QBAKER_MT_global_map_preset",
            )
        operator_preset(
            layout,
            "Unity (Autodesk Interactive)",
            f"{preset_dir}/global/Unity_Autodesk_Interactive.py",
            "QBAKER_MT_global_map_preset",
        )
        operator_preset(
            layout,
            "Unity (HDRP/Lit)",
            f"{preset_dir}/global/Unity_HDRP_Lit.py",
            "QBAKER_MT_global_map_preset",
        )
        layout.separator()
        operator_preset(
            layout,
            "Unreal",
            f"{preset_dir}/global/Unreal.py",
            "QBAKER_MT_global_map_preset",
        )
        operator_preset(
            layout,
            "Unreal Packed",
            f"{preset_dir}/global/Unreal_Packed.py",
            "QBAKER_MT_global_map_preset",
        )
        layout.separator()

        self.draw_preset(context)


class QBAKER_MT_local_map_preset(Menu):
    bl_label = "Local Map Presets"
    preset_operator = "script.execute_preset"
    preset_subdir = "Q-Baker/maps/local"
    preset_add_operator = "qbaker.local_map_preset_add"
    preset_operator_defaults = {"menu_idname": "QBAKER_MT_local_map_preset"}

    def draw(self, context):
        layout = self.layout.column()
        preset_dir = os.path.join(os.path.dirname(__file__), "../../presets/maps")
        operator_preset(
            layout,
            "Unity (Standard)",
            f"{preset_dir}/local/Unity_Standard.py",
            "QBAKER_MT_local_map_preset",
        )

        if bpy.app.version >= (4, 0, 0):
            operator_preset(
                layout,
                "Unity (Standard Specular)",
                f"{preset_dir}/local/Unity_Standard_Specular.py",
                "QBAKER_MT_local_map_preset",
            )
        operator_preset(
            layout,
            "Unity (Autodesk Interactive)",
            f"{preset_dir}/local/Unity_Autodesk_Interactive.py",
            "QBAKER_MT_local_map_preset",
        )
        operator_preset(
            layout,
            "Unity (HDRP/Lit)",
            f"{preset_dir}/local/Unity_HDRP_Lit.py",
            "QBAKER_MT_local_map_preset",
        )
        layout.separator()
        operator_preset(
            layout,
            "Unreal",
            f"{preset_dir}/local/Unreal.py",
            "QBAKER_MT_local_map_preset",
        )
        operator_preset(
            layout,
            "Unreal Packed",
            f"{preset_dir}/local/Unreal_Packed.py",
            "QBAKER_MT_local_map_preset",
        )
        layout.separator()

        self.draw_preset(context)


class QBAKER_MT_global_bake_preset(Menu):
    bl_label = "Global Bake Presets"
    preset_operator = "script.execute_preset"
    preset_subdir = "Q-Baker/bake/global"
    preset_add_operator = "qbaker.global_bake_preset_add"
    preset_operator_defaults = {"menu_idname": "QBAKER_MT_global_bake_preset"}

    def draw(self, context):
        self.draw_preset(context)


class QBAKER_MT_local_bake_preset(Menu):
    bl_label = "Local Bake Presets"
    preset_operator = "script.execute_preset"
    preset_subdir = "Q-Baker/bake/local"
    preset_add_operator = "qbaker.local_bake_preset_add"
    preset_operator_defaults = {"menu_idname": "QBAKER_MT_local_bake_preset"}

    def draw(self, context):
        self.draw_preset(context)


class QBAKER_MT_global_material_map_preset(Menu):
    bl_label = "Global Material Map Presets"
    preset_operator = "script.execute_preset"
    preset_subdir = "Q-Baker/maps/material_global"
    preset_add_operator = "qbaker.global_material_map_preset_add"
    preset_operator_defaults = {"menu_idname": "QBAKER_MT_global_material_map_preset"}

    def draw(self, context):
        layout = self.layout.column()
        self.draw_preset(context)


class QBAKER_MT_local_material_map_preset(Menu):
    bl_label = "Local Material Map Presets"
    preset_operator = "script.execute_preset"
    preset_subdir = "Q-Baker/maps/material_local"
    preset_add_operator = "qbaker.local_material_map_preset_add"
    preset_operator_defaults = {"menu_idname": "QBAKER_MT_local_material_map_preset"}

    def draw(self, context):
        self.draw_preset(context)


class QBAKER_MT_global_material_bake_preset(Menu):
    bl_label = "Global Material Bake Presets"
    preset_operator = "script.execute_preset"
    preset_subdir = "Q-Baker/bake/material_global"
    preset_add_operator = "qbaker.global_material_bake_preset_add"
    preset_operator_defaults = {"menu_idname": "QBAKER_MT_global_material_bake_preset"}

    def draw(self, context):
        self.draw_preset(context)


class QBAKER_MT_local_material_bake_preset(Menu):
    bl_label = "Local Material Bake Presets"
    preset_operator = "script.execute_preset"
    preset_subdir = "Q-Baker/bake/material_local"
    preset_add_operator = "qbaker.local_material_bake_preset_add"
    preset_operator_defaults = {"menu_idname": "QBAKER_MT_local_material_bake_preset"}

    def draw(self, context):
        self.draw_preset(context)


classes = (
    QBAKER_MT_global_map_preset,
    QBAKER_MT_local_map_preset,
    QBAKER_MT_global_bake_preset,
    QBAKER_MT_local_bake_preset,
    QBAKER_MT_global_material_map_preset,
    QBAKER_MT_local_material_map_preset,
    QBAKER_MT_global_material_bake_preset,
    QBAKER_MT_local_material_bake_preset,
)


register, unregister = bpy.utils.register_classes_factory(classes)
