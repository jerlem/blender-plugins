import bpy
from bpy.types import AddonPreferences, PropertyGroup
from bpy.props import *
import os


class QBAKER_AP_bake_settings(PropertyGroup):
    size: EnumProperty(
        name="Size",
        description="Texture size",
        items=(
            ("512", "512", "512x512"),
            ("1024", "1024", "1024x1024"),
            ("2048", "2048", "2048x2048"),
            ("4096", "4096", "4096x4096"),
            ("8192", "8192", "8192x8192"),
            ("CUSTOM", "Custom", "Custom bake size"),
        ),
        default="1024",
    )

    size_custom: IntProperty(
        name="Custom",
        description="Custom texture size",
        subtype="PIXEL",
        min=2,
        default=1024,
    )

    format: EnumProperty(
        name="Format",
        description="File format to save the rendered images as",
        items=(
            ("PNG", "PNG", "Output image in PNG format"),
            ("JPEG", "JPEG", "Output image in JPEG format"),
            ("TARGA", "Targa", "Output image in Targa format"),
            ("TIFF", "TIFF", "Output image in TIFF format"),
            ("OPEN_EXR", "OpenEXR", "Output image in OpenEXR format"),
            ("WEBP", "WebP", "Output image in WebP format"),
        ),
        default="PNG",
    )

    color_depth: EnumProperty(
        name="Color Depth",
        description="Bit depth per channel",
        items=(
            ("8", "8", "8-bit color channels"),
            ("16", "16", "16-bit color channels"),
        ),
    )

    color_depth_exr: EnumProperty(
        name="Color Depth",
        description="Bit depth per channel",
        items=(
            ("16", "16", "16-bit color channels"),
            ("32", "32", "32-bit color channels"),
        ),
        default="32",
    )

    compression: IntProperty(
        name="Compression",
        description="Amount of time to determine best compression: 0 = no compression with fast file output, 100 = maximum lossless compression with slow file output",
        subtype="PERCENTAGE",
        min=0,
        max=100,
        default=15,
    )

    quality: IntProperty(
        name="Quality",
        description="Quality for image formats that support lossy compression",
        subtype="PERCENTAGE",
        min=0,
        max=100,
        default=90,
    )

    exr_codec: EnumProperty(
        name="Codec",
        description="Codec settings for OpenEXR",
        items=(
            ("NONE", "None", ""),
            ("PXR24", "Pxr24 (lossy)", ""),
            ("ZIP", "ZIP (lossless)", ""),
            ("PIZ", "PIZ (lossless)", ""),
            ("RLE", "RLE (lossless)", ""),
            ("ZIPS", "ZIPS (lossless)", ""),
            ("B44", "B44 (lossy)", ""),
            ("B44A", "B44A (lossy)", ""),
            ("DWAA", "DWAA (lossy)", ""),
            ("DWAB", "DWAB (lossy)", ""),
        ),
        default="ZIP",
    )

    tiff_codec: EnumProperty(
        name="Compression",
        description="Compression mode for TIFF",
        items=(
            ("NONE", "None", ""),
            ("DEFLATE", "Deflate", ""),
            ("LZW", "LZW", ""),
            ("PACKBITS", "Pack Bits", ""),
        ),
        default="DEFLATE",
    )

    def draw(self, context, layout):
        layout.use_property_split = True
        col = layout.column()
        col.prop(self, "size")
        if self.size == "CUSTOM":
            col.prop(self, "size_custom")
        col.prop(self, "format")
        if self.format in {"PNG", "TIFF"}:
            row = col.row(align=True)
            row.prop(self, "color_depth", expand=True)
            if self.format in {"TIFF"}:
                col.prop(self, "tiff_codec")
        if self.format in {"OPEN_EXR"}:
            row = col.row(align=True)
            row.prop(self, "color_depth_exr", expand=True)
            col.prop(self, "exr_codec")
        if self.format in {"PNG"}:
            col.prop(self, "compression")
        if self.format in {"JPEG", "WEBP"}:
            col.prop(self, "quality")


class QBAKER_AP_principled(PropertyGroup):
    samples: IntProperty(
        name="Samples",
        description="Number of samples to render for each pixel",
        min=1,
        soft_max=128,
        default=1,
    )

    denoise: BoolProperty(name="Denoise", description="Denoise the baked map", default=False)

    custom: BoolProperty(
        name="Custom",
        description="Custom bake settings",
    )

    bake: PointerProperty(type=QBAKER_AP_bake_settings)

    def draw(self, context, layout):
        col = layout.column()
        col.prop(self, "suffix")
        col.prop(self, "samples")
        col = layout.column(align=True)
        col.prop(self, "denoise")
        col.prop(self, "custom")
        if self.custom:
            self.bake.draw(context, layout)

    def draw_channel(self, context, layout):
        col = layout.column()
        col.prop(self, "samples")
        col = layout.column(align=True)
        col.prop(self, "denoise")


# PBR


class QBAKER_AP_base_color(QBAKER_AP_principled, PropertyGroup):
    name: StringProperty(
        name="Name",
        default="Base Color",
    )

    suffix: StringProperty(
        name="Suffix",
        description="Suffix of the map",
        default="Color",
    )


class QBAKER_AP_emission(QBAKER_AP_principled, PropertyGroup):
    name: StringProperty(
        name="Name",
        default="Emission",
    )

    suffix: StringProperty(
        name="Suffix",
        description="Suffix of the map",
        default="Emission",
    )


class QBAKER_AP_glossiness(QBAKER_AP_principled, PropertyGroup):
    name: StringProperty(
        name="Name",
        default="Glossiness",
    )

    suffix: StringProperty(
        name="Suffix",
        description="Suffix of the map",
        default="Glossiness",
    )


class QBAKER_AP_metallic(QBAKER_AP_principled, PropertyGroup):
    name: StringProperty(
        name="Name",
        default="Metallic",
    )

    suffix: StringProperty(
        name="Suffix",
        description="Suffix of the map",
        default="Metallic",
    )


class QBAKER_AP_normal(PropertyGroup):
    name: StringProperty(
        name="Name",
        default="Normal",
    )

    suffix_mapping = {
        "OPENGL": "NormalGL",
        "DIRECTX": "NormalDX",
        "CUSTOM": "Normal",
    }

    suffix: StringProperty(
        name="Suffix",
        description="Suffix of the map",
        default="NormalGL",
    )

    def update_suffix(self, context):
        self.suffix = self.suffix_mapping[self.type]

    space: EnumProperty(
        name="Space",
        description="Choose normal space for baking",
        items=(
            ("TANGENT", "Tangent", "Bake the normals in tangent space"),
            ("OBJECT", "Object", "Bake the normals in object space"),
        ),
    )

    type: EnumProperty(
        name="Type",
        description="Normal type",
        items=(
            ("OPENGL", "OpenGL", "Unity Engine"),
            ("DIRECTX", "DirectX", "Unreal Engine"),
            ("CUSTOM", "Custom", ""),
        ),
        update=update_suffix,
    )

    r: EnumProperty(
        name="R",
        description="Axis to bake in red channel",
        items=(
            ("POS_X", "+X", ""),
            ("POS_Y", "+Y", ""),
            ("POS_Z", "+Z", ""),
            ("NEG_X", "-X", ""),
            ("NEG_Y", "-Y", ""),
            ("NEG_Z", "-Z", ""),
        ),
    )

    g: EnumProperty(
        name="G",
        description="Axis to bake in green channel",
        items=(
            ("POS_X", "+X", ""),
            ("POS_Y", "+Y", ""),
            ("POS_Z", "+Z", ""),
            ("NEG_X", "-X", ""),
            ("NEG_Y", "-Y", ""),
            ("NEG_Z", "-Z", ""),
        ),
    )

    b: EnumProperty(
        name="B",
        description="Axis to bake in blue channel",
        items=(
            ("POS_X", "+X", ""),
            ("POS_Y", "+Y", ""),
            ("POS_Z", "+Z", ""),
            ("NEG_X", "-X", ""),
            ("NEG_Y", "-Y", ""),
            ("NEG_Z", "-Z", ""),
        ),
    )

    samples: IntProperty(
        name="Samples",
        description="Number of samples to render for each pixel",
        min=1,
        soft_max=128,
        default=1,
    )

    denoise: BoolProperty(name="Denoise", description="Denoise the baked map", default=False)

    custom: BoolProperty(
        name="Custom",
        description="Custom bake settings",
    )

    bake: PointerProperty(type=QBAKER_AP_bake_settings)

    def draw(self, context, layout):
        col = layout.column()
        col.prop(self, "suffix")
        col.prop(self, "space")
        col.prop(self, "type")
        if self.type == "CUSTOM":
            col = col.column(align=True)
            col.prop(self, "r")
            col.prop(self, "g")
            col.prop(self, "b")
        col = layout.column(align=True)
        col.prop(self, "samples")
        col.prop(self, "denoise")
        col.prop(self, "custom")
        if self.custom:
            self.bake.draw(context, layout)

    def draw_channel(self, context, layout):
        col = layout.column()
        col.prop(self, "space")
        col.prop(self, "type")
        if self.type == "CUSTOM":
            col = col.column(align=True)
            col.prop(self, "r")
            col.prop(self, "g")
            col.prop(self, "b")
        col = layout.column(align=True)
        col.prop(self, "samples")
        col.prop(self, "denoise")


class QBAKER_AP_occlusion(PropertyGroup):
    name: StringProperty(
        name="Name",
        default="Occlusion",
    )

    suffix: StringProperty(
        name="Suffix",
        description="Suffix of the map",
        default="Occlusion",
    )

    samples: IntProperty(
        name="Samples",
        description="Number of samples to render for each pixel",
        min=1,
        soft_max=128,
        default=10,
    )

    distance: FloatProperty(
        name="Distance",
        description="Ambient occlusion distance",
        min=0.1,
        soft_max=1,
        step=0.1,
        default=0.5,
    )

    only_local: BoolProperty(
        name="Only Local",
        description="Only consider the object itself when computing AO",
        default=True,
    )

    invert_ao: BoolProperty(
        name="Invert",
        description="Invert map",
    )

    denoise: BoolProperty(name="Denoise", description="Denoise the baked map", default=False)

    custom: BoolProperty(
        name="Custom",
        description="Custom bake settings",
    )

    bake: PointerProperty(type=QBAKER_AP_bake_settings)

    def draw(self, context, layout):
        col = layout.column()
        col.prop(self, "suffix")
        col.prop(self, "distance")
        col.prop(self, "samples")
        col = layout.column(align=True)
        col.prop(self, "only_local")
        col.prop(self, "invert_ao")
        col.prop(self, "denoise")
        col.prop(self, "custom")
        if self.custom:
            self.bake.draw(context, layout)

    def draw_channel(self, context, layout):
        col = layout.column()
        col.prop(self, "distance")
        col.prop(self, "samples")
        col = layout.column(align=True)
        col.prop(self, "only_local")
        col.prop(self, "invert_ao")
        col.prop(self, "denoise")


class QBAKER_AP_roughness(QBAKER_AP_principled, PropertyGroup):
    name: StringProperty(
        name="Name",
        default="Roughness",
    )

    suffix: StringProperty(
        name="Suffix",
        description="Suffix of the map",
        default="Roughness",
    )


class QBAKER_AP_specular(QBAKER_AP_principled, PropertyGroup):
    name: StringProperty(
        name="Name",
        default="Specular",
    )

    suffix: StringProperty(
        name="Suffix",
        description="Suffix of the map",
        default="Specular",
    )


# Mesh


class QBAKER_AP_alpha(QBAKER_AP_principled, PropertyGroup):
    name: StringProperty(
        name="Name",
        default="Alpha",
    )

    suffix: StringProperty(
        name="Suffix",
        description="Suffix of the map",
        default="Alpha",
    )


class QBAKER_AP_bevel_normal(PropertyGroup):
    name: StringProperty(
        name="Name",
        default="Bevel Normal",
    )

    suffix_mapping = {
        "OPENGL": "Bevel_NormalGL",
        "DIRECTX": "Bevel_NormalDX",
        "CUSTOM": "Bevel_Normal",
    }

    suffix: StringProperty(
        name="Suffix",
        description="Suffix of the map",
        default="Bevel_NormalGL",
    )

    def update_suffix(self, context):
        self.suffix = self.suffix_mapping[self.type]

    space: EnumProperty(
        name="Space",
        description="Choose normal space for baking",
        items=(
            ("TANGENT", "Tangent", "Bake the normals in tangent space"),
            ("OBJECT", "Object", "Bake the normals in object space"),
        ),
    )

    type: EnumProperty(
        name="Type",
        description="Normal type",
        items=(
            ("OPENGL", "OpenGL", "Unity Engine"),
            ("DIRECTX", "DirectX", "Unreal Engine"),
            ("CUSTOM", "Custom", ""),
        ),
        update=update_suffix,
    )

    r: EnumProperty(
        name="R",
        description="Axis to bake in red channel",
        items=(
            ("POS_X", "+X", ""),
            ("POS_Y", "+Y", ""),
            ("POS_Z", "+Z", ""),
            ("NEG_X", "-X", ""),
            ("NEG_Y", "-Y", ""),
            ("NEG_Z", "-Z", ""),
        ),
    )

    g: EnumProperty(
        name="G",
        description="Axis to bake in green channel",
        items=(
            ("POS_X", "+X", ""),
            ("POS_Y", "+Y", ""),
            ("POS_Z", "+Z", ""),
            ("NEG_X", "-X", ""),
            ("NEG_Y", "-Y", ""),
            ("NEG_Z", "-Z", ""),
        ),
    )

    b: EnumProperty(
        name="B",
        description="Axis to bake in blue channel",
        items=(
            ("POS_X", "+X", ""),
            ("POS_Y", "+Y", ""),
            ("POS_Z", "+Z", ""),
            ("NEG_X", "-X", ""),
            ("NEG_Y", "-Y", ""),
            ("NEG_Z", "-Z", ""),
        ),
    )

    samples: IntProperty(
        name="Samples",
        description="Number of samples to render for each pixel",
        min=1,
        soft_max=128,
        default=1,
    )

    radius: FloatProperty(
        name="Radius",
        description="Bevel normal radius",
        min=0.01,
        soft_max=1,
        step=0.1,
        default=0.01,
    )

    denoise: BoolProperty(name="Denoise", description="Denoise the baked map", default=False)

    custom: BoolProperty(
        name="Custom",
        description="Custom bake settings",
    )

    bake: PointerProperty(type=QBAKER_AP_bake_settings)

    def draw(self, context, layout):
        col = layout.column()
        col.prop(self, "suffix")
        col.prop(self, "space")
        col.prop(self, "type")
        if self.type == "CUSTOM":
            col = col.column(align=True)
            col.prop(self, "r")
            col.prop(self, "g")
            col.prop(self, "b")
        col = layout.column()
        col.prop(self, "radius")
        col.prop(self, "samples")
        col = layout.column(align=True)
        col.prop(self, "denoise")
        col.prop(self, "custom")
        if self.custom:
            self.bake.draw(context, layout)

    def draw_channel(self, context, layout):
        col = layout.column()
        col.prop(self, "space")
        col.prop(self, "type")
        if self.type == "CUSTOM":
            col = col.column(align=True)
            col.prop(self, "r")
            col.prop(self, "g")
            col.prop(self, "b")
        col = layout.column(align=True)
        col.prop(self, "radius")
        col.prop(self, "samples")
        col.prop(self, "denoise")


class QBAKER_AP_cavity(PropertyGroup):
    name: StringProperty(
        name="Name",
        default="Cavity",
    )

    suffix: StringProperty(
        name="Suffix",
        description="Suffix of the map",
        default="Cavity",
    )

    power: FloatProperty(
        name="Power",
        description="Cavity power",
        min=1,
        soft_max=2,
        step=0.1,
        default=1,
    )

    samples: IntProperty(
        name="Samples",
        description="Number of samples to render for each pixel",
        min=1,
        soft_max=128,
        default=1,
    )

    invert_cavity: BoolProperty(
        name="Invert",
        description="Invert map",
    )

    denoise: BoolProperty(name="Denoise", description="Denoise the baked map", default=False)

    custom: BoolProperty(
        name="Custom",
        description="Custom bake settings",
    )

    bake: PointerProperty(type=QBAKER_AP_bake_settings)

    def draw(self, context, layout):
        col = layout.column()
        col.prop(self, "suffix")
        col.prop(self, "power")
        col.prop(self, "samples")
        col = layout.column(align=True)
        col.prop(self, "invert_cavity")
        col.prop(self, "denoise")
        col.prop(self, "custom")
        if self.custom:
            self.bake.draw(context, layout)

    def draw_channel(self, context, layout):
        col = layout.column()
        col.prop(self, "power")
        col.prop(self, "samples")
        col = layout.column(align=True)
        col.prop(self, "invert_cavity")
        col.prop(self, "denoise")


class QBAKER_AP_curvature(PropertyGroup):
    name: StringProperty(
        name="Name",
        default="Curvature",
    )

    suffix: StringProperty(
        name="Suffix",
        description="Suffix of the map",
        default="Curvature",
    )

    power: FloatProperty(
        name="Power",
        description="Curvature power",
        min=1,
        soft_max=2,
        step=0.1,
        default=1,
    )

    samples: IntProperty(
        name="Samples",
        description="Number of samples to render for each pixel",
        min=1,
        soft_max=128,
        default=1,
    )

    invert_curvature: BoolProperty(
        name="Invert",
        description="Invert map",
    )

    denoise: BoolProperty(name="Denoise", description="Denoise the baked map", default=False)

    custom: BoolProperty(
        name="Custom",
        description="Custom bake settings",
    )

    bake: PointerProperty(type=QBAKER_AP_bake_settings)

    def draw(self, context, layout):
        col = layout.column()
        col.prop(self, "suffix")
        col.prop(self, "power")
        col.prop(self, "samples")
        col = layout.column(align=True)
        col.prop(self, "invert_curvature")
        col.prop(self, "denoise")
        col.prop(self, "custom")
        if self.custom:
            self.bake.draw(context, layout)

    def draw_channel(self, context, layout):
        col = layout.column()
        col.prop(self, "power")
        col.prop(self, "samples")
        col = layout.column(align=True)
        col.prop(self, "invert_curvature")
        col.prop(self, "denoise")


class QBAKER_AP_displacement(PropertyGroup):
    name: StringProperty(
        name="Name",
        default="Displacement",
    )

    suffix: StringProperty(
        name="Suffix",
        description="Suffix of the map",
        default="Displacement",
    )

    samples: IntProperty(
        name="Samples",
        description="Number of samples to render for each pixel",
        min=1,
        soft_max=128,
        default=1,
    )

    invert_displacement: BoolProperty(
        name="Invert",
        description="Invert map",
    )

    denoise: BoolProperty(name="Denoise", description="Denoise the baked map", default=False)

    custom: BoolProperty(
        name="Custom",
        description="Custom bake settings",
    )

    bake: PointerProperty(type=QBAKER_AP_bake_settings)

    def draw(self, context, layout):
        col = layout.column()
        col.prop(self, "suffix")
        col.prop(self, "samples")
        col = layout.column(align=True)
        col.prop(self, "invert_displacement")
        col.prop(self, "denoise")
        col.prop(self, "custom")
        if self.custom:
            self.bake.draw(context, layout)

    def draw_channel(self, context, layout):
        col = layout.column()
        col.prop(self, "samples")
        col = layout.column(align=True)
        col.prop(self, "invert_displacement")
        col.prop(self, "denoise")


class QBAKER_AP_edge(PropertyGroup):
    name: StringProperty(
        name="Name",
        default="Edge",
    )

    suffix: StringProperty(
        name="Suffix",
        description="Suffix of the map",
        default="Edge",
    )

    samples: IntProperty(
        name="Samples",
        description="Number of samples to render for each pixel",
        min=1,
        soft_max=128,
        default=10,
    )

    radius: FloatProperty(
        name="Radius",
        description="Edge radius",
        min=0.01,
        soft_max=1,
        step=0.1,
        default=0.1,
    )

    invert_edge: BoolProperty(
        name="Invert",
        description="Invert map",
    )

    denoise: BoolProperty(name="Denoise", description="Denoise the baked map", default=False)

    custom: BoolProperty(
        name="Custom",
        description="Custom bake settings",
    )

    bake: PointerProperty(type=QBAKER_AP_bake_settings)

    def draw(self, context, layout):
        col = layout.column()
        col.prop(self, "suffix")
        col.prop(self, "radius")
        col.prop(self, "samples")
        col = layout.column(align=True)
        col.prop(self, "invert_edge")
        col.prop(self, "denoise")
        col.prop(self, "custom")
        if self.custom:
            self.bake.draw(context, layout)

    def draw_channel(self, context, layout):
        col = layout.column()
        col.prop(self, "radius")
        col.prop(self, "samples")
        col = layout.column(align=True)
        col.prop(self, "invert_edge")
        col.prop(self, "denoise")


class QBAKER_AP_gradient(PropertyGroup):
    name: StringProperty(
        name="Name",
        default="Gradient",
    )

    suffix_mapping = {
        "XYZ": "Gradient_XYZ",
        "X": "Gradient_X",
        "Y": "Gradient_Y",
        "Z": "Gradient_Z",
    }

    suffix: StringProperty(
        name="Suffix",
        description="Suffix of the map",
        default="Gradient_XYZ",
    )

    def update_suffix(self, context):
        self.suffix = self.suffix_mapping[self.direction]

    direction: EnumProperty(
        name="Direction",
        description="Gradient direction",
        items=(
            ("XYZ", "XYZ", "Red channel is X\nGreen channel is Y\nBlue channel is Z"),
            ("X", "X", ""),
            ("Y", "Y", ""),
            ("Z", "Z", ""),
        ),
        default="XYZ",
        update=update_suffix,
    )

    samples: IntProperty(
        name="Samples",
        description="Number of samples to render for each pixel",
        min=1,
        soft_max=128,
        default=1,
    )

    invert_gradient: BoolProperty(
        name="Invert",
        description="Invert map",
    )

    denoise: BoolProperty(name="Denoise", description="Denoise the baked map", default=False)

    custom: BoolProperty(
        name="Custom",
        description="Custom bake settings",
    )

    bake: PointerProperty(type=QBAKER_AP_bake_settings)

    def draw(self, context, layout):
        col = layout.column()
        col.prop(self, "suffix")
        col.prop(self, "direction", expand=True)
        col.prop(self, "samples")
        col = layout.column(align=True)
        col.prop(self, "invert_gradient")
        col.prop(self, "denoise")
        col.prop(self, "custom")
        if self.custom:
            self.bake.draw(context, layout)

    def draw_channel(self, context, layout):
        col = layout.column()
        col.prop(self, "direction", expand=True)
        col.prop(self, "samples")
        col = layout.column(align=True)
        col.prop(self, "invert_gradient")
        col.prop(self, "denoise")


class QBAKER_AP_height(PropertyGroup):
    name: StringProperty(
        name="Name",
        default="Heightmap",
    )

    suffix: StringProperty(
        name="Suffix",
        description="Suffix of the map",
        default="Heightmap",
    )

    samples: IntProperty(
        name="Samples",
        description="Number of samples to render for each pixel",
        min=1,
        soft_max=128,
        default=1,
    )

    invert_height: BoolProperty(
        name="Invert",
        description="Invert map",
    )

    denoise: BoolProperty(name="Denoise", description="Denoise the baked map", default=False)

    custom: BoolProperty(
        name="Custom",
        description="Custom bake settings",
    )

    bake: PointerProperty(type=QBAKER_AP_bake_settings)

    def draw(self, context, layout):
        col = layout.column()
        col.prop(self, "suffix")
        col.prop(self, "samples")
        col = layout.column(align=True)
        col.prop(self, "invert_height")
        col.prop(self, "denoise")
        col.prop(self, "custom")
        if self.custom:
            self.bake.draw(context, layout)

    def draw_channel(self, context, layout):
        col = layout.column()
        col.prop(self, "radius")
        col.prop(self, "samples")
        col = layout.column(align=True)
        col.prop(self, "invert_height")
        col.prop(self, "denoise")


class QBAKER_AP_material_id(PropertyGroup):
    name: StringProperty(
        name="Name",
        default="Material ID",
    )

    suffix: StringProperty(
        name="Suffix",
        description="Suffix of the map",
        default="Material_ID",
    )

    type: EnumProperty(
        name="Type",
        description="Type of Material ID map",
        items=(
            ("MATERIAL", "Material", "Material ID map based on materials"),
            ("OBJECT", "Object", "Material ID map based on objects"),
            ("VERTEX_COLOR", "Vertex Color", "Material ID map based on vertex colors"),
        ),
    )

    samples: IntProperty(
        name="Samples",
        description="Number of samples to render for each pixel",
        min=1,
        soft_max=128,
        default=1,
    )

    denoise: BoolProperty(name="Denoise", description="Denoise the baked map", default=False)

    custom: BoolProperty(
        name="Custom",
        description="Custom bake settings",
    )

    bake: PointerProperty(type=QBAKER_AP_bake_settings)

    def draw(self, context, layout):
        col = layout.column()
        col.prop(self, "suffix")
        col.prop(self, "type")
        col.prop(self, "samples")
        col = layout.column(align=True)
        col.prop(self, "denoise")
        col.prop(self, "custom")
        if self.custom:
            self.bake.draw(context, layout)

    def draw_channel(self, context, layout):
        col = layout.column()
        col.prop(self, "type")
        col.prop(self, "samples")
        col = layout.column(align=True)
        col.prop(self, "denoise")


class QBAKER_AP_thickness(PropertyGroup):
    name: StringProperty(
        name="Name",
        default="Thickness",
    )

    suffix: StringProperty(
        name="Suffix",
        description="Suffix of the map",
        default="Thickness",
    )

    samples: IntProperty(
        name="Samples",
        description="Number of samples to render for each pixel",
        min=1,
        soft_max=128,
        default=10,
    )

    distance: FloatProperty(
        name="Distance",
        description="Thickness distance",
        min=0.1,
        soft_max=1,
        step=0.1,
        default=0.5,
    )

    invert_thickness: BoolProperty(
        name="Invert",
        description="Invert map",
    )

    denoise: BoolProperty(name="Denoise", description="Denoise the baked map", default=False)

    custom: BoolProperty(
        name="Custom",
        description="Custom bake settings",
    )

    bake: PointerProperty(type=QBAKER_AP_bake_settings)

    def draw(self, context, layout):
        col = layout.column()
        col.prop(self, "suffix")
        col.prop(self, "distance")
        col.prop(self, "samples")
        col = layout.column(align=True)
        col.prop(self, "invert_thickness")
        col.prop(self, "denoise")
        col.prop(self, "custom")
        if self.custom:
            self.bake.draw(context, layout)

    def draw_channel(self, context, layout):
        col = layout.column()
        col.prop(self, "distance")
        col.prop(self, "samples")
        col = layout.column(align=True)
        col.prop(self, "invert_thickness")
        col.prop(self, "denoise")


class QBAKER_AP_vdm(QBAKER_AP_principled, PropertyGroup):
    name: StringProperty(
        name="Name",
        default="Vector Displacement",
    )

    suffix: StringProperty(
        name="Suffix",
        description="Suffix of the map",
        default="VDM",
    )


class QBAKER_AP_wireframe(PropertyGroup):
    name: StringProperty(
        name="Name",
        default="Wireframe",
    )

    suffix: StringProperty(
        name="Suffix",
        description="Suffix of the map",
        default="Wireframe",
    )

    size: EnumProperty(
        name="Size",
        description="Texture size",
        items=(
            ("512", "512", "512x512"),
            ("1024", "1024", "1024x1024"),
            ("2048", "2048", "2048x2048"),
            ("4096", "4096", "4096x4096"),
            ("8192", "8192", "8192x8192"),
        ),
        default="1024",
    )

    size_custom: IntProperty(
        name="Custom",
        description="Custom texture size",
        subtype="PIXEL",
        min=2,
        default=1024,
    )

    format: EnumProperty(
        name="Format",
        description="File format to export the UV layout to",
        items=(
            ("PNG", "PNG", "Export the UV layout to a bitmap image (.png)"),
            ("SVG", "SVG", "Export the UV layout to a vector SVG file (.svg)"),
        ),
        default="PNG",
    )

    face_color: FloatVectorProperty(
        name="Face Color",
        description="Color for UV faces",
        subtype="COLOR",
        size=4,
        min=0.0,
        max=1.0,
        default=(0.8, 0.8, 0.8, 0.5),
    )

    line_color: FloatVectorProperty(
        name="Line Color",
        description="Color for UV lines",
        subtype="COLOR",
        size=4,
        min=0.0,
        max=1.0,
        default=(0, 0, 0, 1),
    )

    line_width: FloatProperty(
        name="Line Width",
        description="Line width for UV lines",
        min=0.1,
        soft_max=1.0,
        default=1,
    )

    export_all: BoolProperty(
        name="All UVs",
        description="Export all UVs in this mesh (not just visible ones)",
        default=True,
    )

    modified: BoolProperty(
        name="Modified",
        description="Exports UVs from the modified mesh",
        default=False,
    )

    def draw(self, context, layout):
        col = layout.column()
        col.prop(self, "suffix")
        col.prop(self, "size")
        if self.size == "CUSTOM":
            col.prop(self, "size_custom")
        col.prop(self, "format")
        col.prop(self, "face_color")
        if self.format != "SVG":
            col.prop(self, "line_color")
        col.prop(self, "line_width")

        col = layout.column(align=True)
        col.prop(self, "export_all")
        col.prop(self, "modified")


class QBAKER_AP_xyz(PropertyGroup):
    name: StringProperty(
        name="Name",
        default="XYZ",
    )

    suffix_mapping = {
        "XYZ": "XYZ",
        "X": "X",
        "Y": "Y",
        "Z": "Z",
    }

    suffix: StringProperty(
        name="Suffix",
        description="Suffix of the map",
        default="XYZ",
    )

    def update_suffix(self, context):
        self.suffix = self.suffix_mapping[self.direction]

    direction: EnumProperty(
        name="Direction",
        description="XYZ mask direction",
        items=(
            ("XYZ", "XYZ", "Red channel is X\nGreen channel is Y\nBlue channel is Z"),
            ("X", "X", ""),
            ("Y", "Y", ""),
            ("Z", "Z", ""),
        ),
        default="XYZ",
        update=update_suffix,
    )

    samples: IntProperty(
        name="Samples",
        description="Number of samples to render for each pixel",
        min=1,
        soft_max=128,
        default=1,
    )

    invert_xyz: BoolProperty(
        name="Invert",
        description="Invert map",
    )

    denoise: BoolProperty(name="Denoise", description="Denoise the baked map", default=False)

    custom: BoolProperty(
        name="Custom",
        description="Custom bake settings",
    )

    bake: PointerProperty(type=QBAKER_AP_bake_settings)

    def draw(self, context, layout):
        col = layout.column()
        col.prop(self, "suffix")
        col.prop(self, "direction", expand=True)
        col.prop(self, "samples")
        col = layout.column(align=True)
        col.prop(self, "invert_xyz")
        col.prop(self, "denoise")
        col.prop(self, "custom")
        if self.custom:
            self.bake.draw(context, layout)

    def draw_channel(self, context, layout):
        col = layout.column()
        col.prop(self, "direction", expand=True)
        col.prop(self, "samples")
        col = layout.column(align=True)
        col.prop(self, "invert_xyz")
        col.prop(self, "denoise")


# Principled BSDF


class QBAKER_AP_subsurface(QBAKER_AP_principled, PropertyGroup):
    name: StringProperty(
        name="Name",
        default="Subsurface",
    )

    suffix: StringProperty(
        name="Suffix",
        description="Suffix of the map",
        default="Subsurface",
    )


class QBAKER_AP_subsurface_color(QBAKER_AP_principled, PropertyGroup):
    name: StringProperty(
        name="Name",
        default="Subsurface Color",
    )

    suffix: StringProperty(
        name="Suffix",
        description="Suffix of the map",
        default="Subsurface_Color",
    )


class QBAKER_AP_subsurface_ior(QBAKER_AP_principled, PropertyGroup):
    name: StringProperty(
        name="Name",
        default="Subsurface IOR",
    )

    suffix: StringProperty(
        name="Suffix",
        description="Suffix of the map",
        default="Subsurface_IOR",
    )


class QBAKER_AP_subsurface_anisotropy(QBAKER_AP_principled, PropertyGroup):
    name: StringProperty(
        name="Name",
        default="Subsurface Anisotropy",
    )

    suffix: StringProperty(
        name="Suffix",
        description="Suffix of the map",
        default="Subsurface_Anisotropy",
    )


class QBAKER_AP_specular_tint(QBAKER_AP_principled, PropertyGroup):
    name: StringProperty(
        name="Name",
        default="Subsurface Tint",
    )

    suffix: StringProperty(
        name="Suffix",
        description="Suffix of the map",
        default="Subsurface_Tint",
    )


class QBAKER_AP_anisotropic(QBAKER_AP_principled, PropertyGroup):
    name: StringProperty(
        name="Name",
        default="Anisotropic",
    )

    suffix: StringProperty(
        name="Suffix",
        description="Suffix of the map",
        default="Anisotropic",
    )


class QBAKER_AP_anisotropic_rotation(QBAKER_AP_principled, PropertyGroup):
    name: StringProperty(
        name="Name",
        default="Anisotropic Rotation",
    )

    suffix: StringProperty(
        name="Suffix",
        description="Suffix of the map",
        default="Anisotropic_Rotation",
    )


class QBAKER_AP_sheen(QBAKER_AP_principled, PropertyGroup):
    name: StringProperty(
        name="Name",
        default="Sheen",
    )

    suffix: StringProperty(
        name="Suffix",
        description="Suffix of the map",
        default="Sheen",
    )


class QBAKER_AP_sheen_tint(QBAKER_AP_principled, PropertyGroup):
    name: StringProperty(
        name="Name",
        default="Sheen Tint",
    )

    suffix: StringProperty(
        name="Suffix",
        description="Suffix of the map",
        default="Sheen_Tint",
    )


class QBAKER_AP_clearcoat(QBAKER_AP_principled, PropertyGroup):
    name: StringProperty(
        name="Name",
        default="Clearcoat",
    )

    suffix: StringProperty(
        name="Suffix",
        description="Suffix of the map",
        default="Clearcoat",
    )


class QBAKER_AP_clearcoat_roughness(QBAKER_AP_principled, PropertyGroup):
    name: StringProperty(
        name="Name",
        default="Clearcoat Roughness",
    )

    suffix: StringProperty(
        name="Suffix",
        description="Suffix of the map",
        default="Clearcoat_Roughness",
    )


class QBAKER_AP_ior(QBAKER_AP_principled, PropertyGroup):
    name: StringProperty(
        name="Name",
        default="IOR",
    )

    suffix: StringProperty(
        name="Suffix",
        description="Suffix of the map",
        default="IOR",
    )


class QBAKER_AP_transmission_roughness(QBAKER_AP_principled, PropertyGroup):
    name: StringProperty(
        name="Name",
        default="Transmission Roughness",
    )

    suffix: StringProperty(
        name="Suffix",
        description="Suffix of the map",
        default="Transmission_Roughness",
    )


class QBAKER_AP_emission_strength(QBAKER_AP_principled, PropertyGroup):
    name: StringProperty(
        name="Name",
        default="Emission Strength",
    )

    suffix: StringProperty(
        name="Suffix",
        description="Suffix of the map",
        default="Emission_Strength",
    )


class QBAKER_AP_clearcoat_normal(PropertyGroup):
    name: StringProperty(
        name="Name",
        default="Clearcoat Normal",
    )

    suffix_mapping = {
        "OPENGL": "Clearcoat_NormalGL",
        "DIRECTX": "Clearcoat_NormalDX",
        "CUSTOM": "Clearcoat_Normal",
    }

    suffix: StringProperty(
        name="Suffix",
        description="Suffix of the map",
        default="Clearcoat_NormalGL",
    )

    def update_suffix(self, context):
        self.suffix = self.suffix_mapping[self.type]

    space: EnumProperty(
        name="Space",
        description="Choose normal space for baking",
        items=(
            ("TANGENT", "Tangent", "Bake the normals in tangent space"),
            ("OBJECT", "Object", "Bake the normals in object space"),
        ),
    )

    type: EnumProperty(
        name="Type",
        description="Normal type",
        items=(
            ("OPENGL", "OpenGL", "Unity Engine"),
            ("DIRECTX", "DirectX", "Unreal Engine"),
            ("CUSTOM", "Custom", ""),
        ),
        update=update_suffix,
    )

    r: EnumProperty(
        name="R",
        description="Axis to bake in red channel",
        items=(
            ("POS_X", "+X", ""),
            ("POS_Y", "+Y", ""),
            ("POS_Z", "+Z", ""),
            ("NEG_X", "-X", ""),
            ("NEG_Y", "-Y", ""),
            ("NEG_Z", "-Z", ""),
        ),
    )

    g: EnumProperty(
        name="G",
        description="Axis to bake in green channel",
        items=(
            ("POS_X", "+X", ""),
            ("POS_Y", "+Y", ""),
            ("POS_Z", "+Z", ""),
            ("NEG_X", "-X", ""),
            ("NEG_Y", "-Y", ""),
            ("NEG_Z", "-Z", ""),
        ),
    )

    b: EnumProperty(
        name="B",
        description="Axis to bake in blue channel",
        items=(
            ("POS_X", "+X", ""),
            ("POS_Y", "+Y", ""),
            ("POS_Z", "+Z", ""),
            ("NEG_X", "-X", ""),
            ("NEG_Y", "-Y", ""),
            ("NEG_Z", "-Z", ""),
        ),
    )

    samples: IntProperty(
        name="Samples",
        description="Number of samples to render for each pixel",
        min=1,
        soft_max=128,
        default=1,
    )

    denoise: BoolProperty(name="Denoise", description="Denoise the baked map", default=False)

    custom: BoolProperty(
        name="Custom",
        description="Custom bake settings",
    )

    bake: PointerProperty(type=QBAKER_AP_bake_settings)

    def draw(self, context, layout):
        col = layout.column()
        col.prop(self, "suffix")
        col.prop(self, "space")
        col.prop(self, "type")
        if self.type == "CUSTOM":
            col = col.column(align=True)
            col.prop(self, "r")
            col.prop(self, "g")
            col.prop(self, "b")
        col = layout.column(align=True)
        col.prop(self, "samples")
        col.prop(self, "denoise")
        col.prop(self, "custom")
        if self.custom:
            self.bake.draw(context, layout)

    def draw_channel(self, context, layout):
        col = layout.column()
        col.prop(self, "space")
        col.prop(self, "type")
        if self.type == "CUSTOM":
            col = col.column(align=True)
            col.prop(self, "r")
            col.prop(self, "g")
            col.prop(self, "b")
        col = layout.column(align=True)
        col.prop(self, "samples")
        col.prop(self, "denoise")


class QBAKER_AP_tangent(PropertyGroup):
    name: StringProperty(
        name="Name",
        default="Tangent",
    )

    suffix_mapping = {
        "OPENGL": "TangentGL",
        "DIRECTX": "TangentDX",
        "CUSTOM": "Tangent",
    }

    suffix: StringProperty(
        name="Suffix",
        description="Suffix of the map",
        default="TangentGL",
    )

    def update_suffix(self, context):
        self.suffix = self.suffix_mapping[self.type]

    space: EnumProperty(
        name="Space",
        description="Choose normal space for baking",
        items=(
            ("TANGENT", "Tangent", "Bake the normals in tangent space"),
            ("OBJECT", "Object", "Bake the normals in object space"),
        ),
    )

    type: EnumProperty(
        name="Type",
        description="Normal type",
        items=(
            ("OPENGL", "OpenGL", "Unity Engine"),
            ("DIRECTX", "DirectX", "Unreal Engine"),
            ("CUSTOM", "Custom", ""),
        ),
        update=update_suffix,
    )

    r: EnumProperty(
        name="R",
        description="Axis to bake in red channel",
        items=(
            ("POS_X", "+X", ""),
            ("POS_Y", "+Y", ""),
            ("POS_Z", "+Z", ""),
            ("NEG_X", "-X", ""),
            ("NEG_Y", "-Y", ""),
            ("NEG_Z", "-Z", ""),
        ),
    )

    g: EnumProperty(
        name="G",
        description="Axis to bake in green channel",
        items=(
            ("POS_X", "+X", ""),
            ("POS_Y", "+Y", ""),
            ("POS_Z", "+Z", ""),
            ("NEG_X", "-X", ""),
            ("NEG_Y", "-Y", ""),
            ("NEG_Z", "-Z", ""),
        ),
    )

    b: EnumProperty(
        name="B",
        description="Axis to bake in blue channel",
        items=(
            ("POS_X", "+X", ""),
            ("POS_Y", "+Y", ""),
            ("POS_Z", "+Z", ""),
            ("NEG_X", "-X", ""),
            ("NEG_Y", "-Y", ""),
            ("NEG_Z", "-Z", ""),
        ),
    )

    samples: IntProperty(
        name="Samples",
        description="Number of samples to render for each pixel",
        min=1,
        soft_max=128,
        default=1,
    )

    denoise: BoolProperty(name="Denoise", description="Denoise the baked map", default=False)

    custom: BoolProperty(
        name="Custom",
        description="Custom bake settings",
    )

    bake: PointerProperty(type=QBAKER_AP_bake_settings)

    def draw(self, context, layout):
        col = layout.column()
        col.prop(self, "suffix")
        col.prop(self, "space")
        col.prop(self, "type")
        if self.type == "CUSTOM":
            col = col.column(align=True)
            col.prop(self, "r")
            col.prop(self, "g")
            col.prop(self, "b")
        col = layout.column(align=True)
        col.prop(self, "samples")
        col.prop(self, "denoise")
        col.prop(self, "custom")
        if self.custom:
            self.bake.draw(context, layout)

    def draw_channel(self, context, layout):
        col = layout.column()
        col.prop(self, "space")
        col.prop(self, "type")
        if self.type == "CUSTOM":
            col = col.column(align=True)
            col.prop(self, "r")
            col.prop(self, "g")
            col.prop(self, "b")
        col = layout.column(align=True)
        col.prop(self, "samples")
        col.prop(self, "denoise")


# Cycles


class QBAKER_AP_ambient_occlusion(QBAKER_AP_principled, PropertyGroup):
    name: StringProperty(
        name="Name",
        default="Ambient Occlusion",
    )

    suffix: StringProperty(
        name="Suffix",
        description="Suffix of the map",
        default="Ambient_Occlusion",
    )

    samples: IntProperty(
        name="Samples",
        description="Number of samples to render for each pixel",
        min=1,
        soft_max=128,
        default=10,
    )


class QBAKER_AP_combined(PropertyGroup):
    name: StringProperty(
        name="Name",
        default="Combined",
    )

    suffix: StringProperty(
        name="Suffix",
        description="Suffix of the map",
        default="Combined",
    )

    use_pass_direct: BoolProperty(
        name="Direct",
        description="Add direct lighting contribution",
        default=True,
    )

    use_pass_indirect: BoolProperty(name="Indirect", description="Add indirect lighting contribution", default=True)

    use_pass_diffuse: BoolProperty(
        name="Diffuse",
        description="Add diffuse contribution",
        default=True,
    )

    use_pass_glossy: BoolProperty(name="Glossy", description="Add glossy contribution", default=True)

    use_pass_transmission: BoolProperty(name="Transmission", description="Add transmision contribution", default=True)

    use_pass_emit: BoolProperty(name="Emit", description="Add emission contribution", default=True)

    samples: IntProperty(
        name="Samples",
        description="Number of samples to render for each pixel",
        min=1,
        soft_max=128,
        default=128,
    )

    denoise: BoolProperty(name="Denoise", description="Denoise the baked map", default=False)

    custom: BoolProperty(
        name="Custom",
        description="Custom bake settings",
    )

    bake: PointerProperty(type=QBAKER_AP_bake_settings)

    def draw(self, context, layout):
        col = layout.column()
        col.prop(self, "suffix")
        col = layout.column(heading="Lighting", align=True)
        col.prop(self, "use_pass_direct")
        col.prop(self, "use_pass_indirect")
        col = layout.column(heading="Contributions", align=True)
        col.enabled = self.use_pass_direct or self.use_pass_indirect
        col.prop(self, "use_pass_diffuse")
        col.prop(self, "use_pass_glossy")
        col.prop(self, "use_pass_transmission")
        col.prop(self, "use_pass_emit")
        col = layout.column(align=True)
        col.prop(self, "samples")
        col.prop(self, "denoise")
        col.prop(self, "custom")
        if self.custom:
            self.bake.draw(context, layout)

    def draw_channel(self, context, layout):
        col = layout.column(heading="Lighting", align=True)
        col.prop(self, "use_pass_direct")
        col.prop(self, "use_pass_indirect")
        col = layout.column(heading="Contributions", align=True)
        col.enabled = self.use_pass_direct or self.use_pass_indirect
        col.prop(self, "use_pass_diffuse")
        col.prop(self, "use_pass_glossy")
        col.prop(self, "use_pass_transmission")
        col.prop(self, "use_pass_emit")
        col = layout.column(align=True)
        col.prop(self, "samples")
        col.prop(self, "denoise")


class QBAKER_AP_diffuse(PropertyGroup):
    name: StringProperty(
        name="Name",
        default="Diffuse",
    )

    suffix: StringProperty(
        name="Suffix",
        description="Suffix of the map",
        default="Diffuse",
    )

    direct: BoolProperty(name="Direct", description="Add direct lighting contribution", default=True)

    indirect: BoolProperty(name="Indirect", description="Add indirect lighting contribution", default=True)

    color: BoolProperty(name="Color", description="Color the pass", default=True)

    samples: IntProperty(
        name="Samples",
        description="Number of samples to render for each pixel",
        min=1,
        soft_max=128,
        default=10,
    )

    denoise: BoolProperty(name="Denoise", description="Denoise the baked map", default=False)

    custom: BoolProperty(
        name="Custom",
        description="Custom bake settings",
    )

    bake: PointerProperty(type=QBAKER_AP_bake_settings)

    def draw(self, context, layout):
        col = layout.column()
        col.prop(self, "suffix")
        col = layout.column(align=True)
        col.prop(self, "direct")
        col.prop(self, "indirect")
        col.prop(self, "color")
        col = layout.column(align=True)
        col.prop(self, "samples")
        col.prop(self, "denoise")
        col.prop(self, "custom")
        if self.custom:
            self.bake.draw(context, layout)

    def draw_channel(self, context, layout):
        col = layout.column(align=True)
        col.prop(self, "direct")
        col.prop(self, "indirect")
        col.prop(self, "color")
        col = layout.column(align=True)
        col.prop(self, "samples")
        col.prop(self, "denoise")


class QBAKER_AP_environment(QBAKER_AP_principled, PropertyGroup):
    name: StringProperty(
        name="Name",
        default="Environment",
    )

    suffix: StringProperty(
        name="Suffix",
        description="Suffix of the map",
        default="Environment",
    )


class QBAKER_AP_glossy(PropertyGroup):
    name: StringProperty(
        name="Name",
        default="Glossy",
    )

    suffix: StringProperty(
        name="Suffix",
        description="Suffix of the map",
        default="Glossy",
    )

    direct: BoolProperty(name="Direct", description="Add direct lighting contribution", default=True)

    indirect: BoolProperty(name="Indirect", description="Add indirect lighting contribution", default=True)

    color: BoolProperty(name="Color", description="Color the pass", default=True)

    samples: IntProperty(
        name="Samples",
        description="Number of samples to render for each pixel",
        min=1,
        soft_max=128,
        default=10,
    )

    denoise: BoolProperty(name="Denoise", description="Denoise the baked map", default=False)

    custom: BoolProperty(
        name="Custom",
        description="Custom bake settings",
    )

    bake: PointerProperty(type=QBAKER_AP_bake_settings)

    def draw(self, context, layout):
        col = layout.column()
        col.prop(self, "suffix")
        col = layout.column(align=True)
        col.prop(self, "direct")
        col.prop(self, "indirect")
        col.prop(self, "color")
        col = layout.column(align=True)
        col.prop(self, "samples")
        col.prop(self, "denoise")
        col.prop(self, "custom")
        if self.custom:
            self.bake.draw(context, layout)

    def draw_channel(self, context, layout):
        col = layout.column(align=True)
        col.prop(self, "direct")
        col.prop(self, "indirect")
        col.prop(self, "color")
        col = layout.column(align=True)
        col.prop(self, "samples")
        col.prop(self, "denoise")


class QBAKER_AP_position(QBAKER_AP_principled, PropertyGroup):
    name: StringProperty(
        name="Name",
        default="Position",
    )

    suffix: StringProperty(
        name="Suffix",
        description="Suffix of the map",
        default="Position",
    )


class QBAKER_AP_shadow(QBAKER_AP_principled, PropertyGroup):
    name: StringProperty(
        name="Name",
        default="Shadow",
    )

    suffix: StringProperty(
        name="Suffix",
        description="Suffix of the map",
        default="Shadow",
    )

    samples: IntProperty(
        name="Samples",
        description="Number of samples to render for each pixel",
        min=1,
        soft_max=128,
        default=10,
    )


class QBAKER_AP_transmission(PropertyGroup):
    name: StringProperty(
        name="Name",
        default="Transmission",
    )

    suffix: StringProperty(
        name="Suffix",
        description="Suffix of the map",
        default="Transmission",
    )

    direct: BoolProperty(name="Direct", description="Add direct lighting contribution", default=True)

    indirect: BoolProperty(name="Indirect", description="Add indirect lighting contribution", default=True)

    color: BoolProperty(name="Color", description="Color the pass", default=True)

    samples: IntProperty(
        name="Samples",
        description="Number of samples to render for each pixel",
        min=1,
        soft_max=128,
        default=10,
    )

    denoise: BoolProperty(name="Denoise", description="Denoise the baked map", default=False)

    custom: BoolProperty(
        name="Custom",
        description="Custom bake settings",
    )

    bake: PointerProperty(type=QBAKER_AP_bake_settings)

    def draw(self, context, layout):
        col = layout.column()
        col.prop(self, "suffix")
        col = layout.column(align=True)
        col.prop(self, "direct")
        col.prop(self, "indirect")
        col.prop(self, "color")
        col = layout.column(align=True)
        col.prop(self, "samples")
        col.prop(self, "denoise")
        col.prop(self, "custom")
        if self.custom:
            self.bake.draw(context, layout)

    def draw_channel(self, context, layout):
        col = layout.column(align=True)
        col.prop(self, "direct")
        col.prop(self, "indirect")
        col.prop(self, "color")
        col = layout.column(align=True)
        col.prop(self, "samples")
        col.prop(self, "denoise")


class QBAKER_AP_uv(QBAKER_AP_principled, PropertyGroup):
    name: StringProperty(
        name="Name",
        default="UV",
    )

    suffix: StringProperty(
        name="Suffix",
        description="Suffix of the map",
        default="UV",
    )


class QBAKER_AP_channel_pack(PropertyGroup):
    name: StringProperty(
        name="Name",
        default="Channel Pack",
    )

    suffix_mapping = {
        "BASE_COLOR": "C",
        "COMBINED": "CO",
        "CLEARCOAT_NORMAL": "CCN",
        "MATERIAL_ID": "ID",
        "NORMAL": "N",
        "EMISSION": "E",
        "SUBSURFACE_COLOR": "SSC",
        "TANGENT": "TANG",
        "GLOSSINESS": "G",
        "METALLIC": "M",
        "OCCLUSION": "O",
        "ROUGHNESS": "R",
        "SPECULAR": "S",
        "ALPHA": "A",
        "CAVITY": "CA",
        "CURVATURE": "CU",
        "DISPLACEMENT": "D",
        "EDGE": "EDGE",
        "HEIGHT": "H",
        "THICKNESS": "T",
        "SUBSURFACE": "SS",
        "SUBSURFACE_IOR": "SSIOR",
        "SUBSURFACE_ANISOTROPY": "SSA",
        "SPECULAR_TINT": "SPECT",
        "ANISOTROPIC": "ANIS",
        "ANISOTROPIC_ROT": "ANISROT",
        "SHEEN": "SHN",
        "SHEEN_TINT": "SHNT",
        "CLEARCOAT": "CC",
        "CLEARCOAT_ROUGHNESS": "CCR",
        "IOR": "IOR",
        "TRANSMISSION_ROUGHNESS": "TR",
        "EMISSION_STRENGTH": "ES",
    }

    def get_suffix(self):
        if self.mode == "RGBA":
            suffix = f"{f'{self.suffix_mapping[self.r_channel]}' if self.r_channel != 'NONE' else ''}{f'_{self.suffix_mapping[self.g_channel]}' if self.g_channel != 'NONE' else ''}{f'_{self.suffix_mapping[self.b_channel]}' if self.b_channel != 'NONE' else ''}{f'_{self.suffix_mapping[self.a_channel]}' if self.a_channel != 'NONE' else ''}"
        else:
            suffix = f"{self.suffix_mapping[self.rgb_channel]}{f'_{self.suffix_mapping[self.a_channel]}' if self.a_channel != 'NONE' else ''}"
        return self.get("suffix", suffix)

    def set_suffix(self, value):
        self["suffix"] = value

    suffix: StringProperty(
        name="Suffix",
        description="Suffix of the map",
        get=get_suffix,
        set=set_suffix,
    )

    mode: EnumProperty(
        name="Mode",
        items=(
            ("RGBA", "Channels", "R + G + B + A"),
            ("RGB_A", "Map + Channel", "RGB + A"),
        ),
        default="RGBA",
    )

    channel_items = (
        ("", "PBR", "", "SHADING_RENDERED", 0),
        ("GLOSSINESS", "Glossiness", "Glossiness / Smoothness Map"),
        ("METALLIC", "Metallic", "Metallic Map"),
        ("OCCLUSION", "Occlusion", "Ambient Occlusion Map"),
        ("ROUGHNESS", "Roughness", "Roughness Map"),
        ("SPECULAR", "Specular", "Specular Map"),
        ("", "Mesh", "", "MESH_DATA", 0),
        ("ALPHA", "Alpha", "Alpha / Opacity / Transparency Map"),
        ("CAVITY", "Cavity", "Cavity / Concavity Map"),
        ("CURVATURE", "Curvature", "Curvature Map"),
        ("DISPLACEMENT", "Displacement", "Displacement / Bump Map"),
        ("EDGE", "Edge", "Edge / Convexity Map"),
        ("HEIGHT", "Heightmap", "Height Map"),
        ("THICKNESS", "Thickness", "Thickness / Translucency Map"),
        ("", "Principled BSDF", "", "NODE", 0),
        ("SUBSURFACE", "Subsurface", "Subsurface Map"),
        ("SUBSURFACE_IOR", "Subsurface IOR", "Subsurface IOR Map"),
        ("SUBSURFACE_ANISOTROPY", "Subsurface Anisotropy", "Subsurface Anisotropy Map"),
        ("SPECULAR_TINT", "Specular Tint", "Specular Tint Map"),
        ("ANISOTROPIC", "Anisotropic", "Anisotropic Map"),
        ("ANISOTROPIC_ROT", "Anisotropic Rotation", "Anisotropic Rotation Map"),
        ("SHEEN", "Sheen", "Sheen Map"),
        ("SHEEN_TINT", "Sheen Tint", "Sheen Tint Map"),
        ("CLEARCOAT", "Clearcoat", "Clearcoat Map"),
        ("CLEARCOAT_ROUGHNESS", "Clearcoat Roughness", "Clearcoat Roughness Map"),
        ("IOR", "IOR", "IOR Map"),
        (
            "TRANSMISSION_ROUGHNESS",
            "Transmission Roughness",
            "Transmission Roughness Map",
        ),
        ("EMISSION_STRENGTH", "Emission Strength", "Emission Strength Map"),
        ("", "", "", "", 0),
        ("NONE", "None", ""),
    )

    r_channel: EnumProperty(name="R", description="Red Channel", items=channel_items, default="OCCLUSION")

    g_channel: EnumProperty(name="G", description="Green Channel", items=channel_items, default="METALLIC")

    b_channel: EnumProperty(name="B", description="Blue Channel", items=channel_items, default="ROUGHNESS")

    rgb_channel: EnumProperty(
        name="RGB",
        description="RGB Channel",
        items=(
            ("", "PBR", "", "SHADING_RENDERED", 0),
            ("BASE_COLOR", "Base Color", "Base Color / Albedo / Diffuse Map"),
            ("EMISSION", "Emission", "Emission Map"),
            ("NORMAL", "Normal", "Normal"),
            ("", "Mesh", "", "MESH_DATA", 0),
            ("MATERIAL_ID", "Material ID", "Material ID Map"),
            ("", "Principled BSDF", "", "NODE", 0),
            ("CLEARCOAT_NORMAL", "Clearcoat Normal", "Clearcoat Normal Map"),
            ("SUBSURFACE_COLOR", "Subsurface Color", "Subsurface Color Map"),
            ("TANGENT", "Tangent", "Tangent Map"),
            ("", "Cycles", "", "SHADING_TEXTURE", 0),
            ("COMBINED", "Combined", "Combined Map"),
        ),
        default="BASE_COLOR",
    )

    a_channel: EnumProperty(name="A", description="Alpha Channel", items=channel_items, default="ALPHA")

    # map
    base_color: PointerProperty(type=QBAKER_AP_base_color)
    combined: PointerProperty(type=QBAKER_AP_combined)
    clearcoat_normal: PointerProperty(type=QBAKER_AP_clearcoat_normal)
    material_id: PointerProperty(type=QBAKER_AP_material_id)
    normal: PointerProperty(type=QBAKER_AP_normal)
    emission: PointerProperty(type=QBAKER_AP_emission)
    subsurface_color: PointerProperty(type=QBAKER_AP_subsurface_color)
    tangent: PointerProperty(type=QBAKER_AP_tangent)
    # channel
    alpha: PointerProperty(type=QBAKER_AP_alpha)
    cavity: PointerProperty(type=QBAKER_AP_cavity)
    curvature: PointerProperty(type=QBAKER_AP_curvature)
    edge: PointerProperty(type=QBAKER_AP_edge)
    displacement: PointerProperty(type=QBAKER_AP_displacement)
    glossiness: PointerProperty(type=QBAKER_AP_glossiness)
    height: PointerProperty(type=QBAKER_AP_height)
    metallic: PointerProperty(type=QBAKER_AP_metallic)
    occlusion: PointerProperty(type=QBAKER_AP_occlusion)
    roughness: PointerProperty(type=QBAKER_AP_roughness)
    specular: PointerProperty(type=QBAKER_AP_specular)
    thickness: PointerProperty(type=QBAKER_AP_thickness)
    # Principled BSDF
    subsurface: PointerProperty(type=QBAKER_AP_subsurface)
    subsurface_ior: PointerProperty(type=QBAKER_AP_subsurface_ior)
    subsurface_anisotropy: PointerProperty(type=QBAKER_AP_subsurface_anisotropy)
    specular_tint: PointerProperty(type=QBAKER_AP_specular_tint)
    anisotropic: PointerProperty(type=QBAKER_AP_anisotropic)
    anisotropic_rotation: PointerProperty(type=QBAKER_AP_anisotropic_rotation)
    sheen: PointerProperty(type=QBAKER_AP_sheen)
    sheen_tint: PointerProperty(type=QBAKER_AP_sheen_tint)
    clearcoat: PointerProperty(type=QBAKER_AP_clearcoat)
    clearcoat_roughness: PointerProperty(type=QBAKER_AP_clearcoat_roughness)
    ior: PointerProperty(type=QBAKER_AP_ior)
    transmission_roughness: PointerProperty(type=QBAKER_AP_transmission_roughness)
    emission_strength: PointerProperty(type=QBAKER_AP_emission_strength)

    custom: BoolProperty(
        name="Custom",
        description="Custom bake settings",
    )

    bake: PointerProperty(type=QBAKER_AP_bake_settings)

    def draw(self, context, layout):
        col = layout.column()
        col.prop(self, "suffix")
        col.prop(self, "mode")

        col = layout.column()
        if self.mode == "RGBA":
            col.prop(self, "r_channel")
            col.prop(self, "g_channel")
            col.prop(self, "b_channel")
        else:
            col.prop(self, "rgb_channel")
        col.prop(self, "a_channel")

        col.prop(self, "custom")
        if self.custom:
            self.bake.draw(context, layout)

    def get_single_channel_map(self, channel):
        # PBR
        if channel == "GLOSSINESS":
            return self.glossiness
        elif channel == "METALLIC":
            return self.metallic
        elif channel == "OCCLUSION":
            return self.occlusion
        elif channel == "ROUGHNESS":
            return self.roughness
        elif channel == "SPECULAR":
            return self.specular
        # Mesh
        elif channel == "ALPHA":
            return self.alpha
        elif channel == "CAVITY":
            return self.cavity
        elif channel == "CURVATURE":
            return self.curvature
        elif channel == "DISPLACEMENT":
            return self.displacement
        elif channel == "EDGE":
            return self.edge
        elif channel == "HEIGHT":
            return self.height
        elif channel == "THICKNESS":
            return self.thickness
        # Principled BSDF
        elif channel == "SUBSURFACE":
            return self.subsurface
        elif channel == "SUBSURFACE_IOR":
            return self.subsurface_ior
        elif channel == "SUBSURFACE_ANISOTROPY":
            return self.subsurface_anisotropy
        elif channel == "SPECULAR_TINT":
            return self.specular_tint
        elif channel == "ANISOTROPIC":
            return self.anisotropic
        elif channel == "ANISOTROPIC_ROT":
            return self.anisotropic_rotation
        elif channel == "SHEEN":
            return self.sheen
        elif channel == "SHEEN_TINT":
            return self.sheen_tint
        elif channel == "CLEARCOAT":
            return self.clearcoat
        elif channel == "CLEARCOAT_ROUGHNESS":
            return self.clearcoat_roughness
        elif channel == "IOR":
            return self.ior
        elif channel == "TRANSMISSION_ROUGHNESS":
            return self.transmission_roughness
        elif channel == "EMISSION_STRENGTH":
            return self.emission_strength

    def get_multi_channel_map(self, channel):
        if channel == "BASE_COLOR":
            return self.base_color
        elif channel == "COMBINED":
            return self.combined
        elif channel == "CLEARCOAT_NORMAL":
            return self.clearcoat_normal
        elif channel == "EMISSION":
            return self.emission
        elif channel == "MATERIAL_ID":
            return self.material_id
        elif channel == "NORMAL":
            return self.normal
        elif channel == "SUBSURFACE_COLOR":
            return self.subsurface_color
        elif channel == "TANGENT":
            return self.tangent

    def draw_map(self, context, layout):
        if self.mode == "RGBA":
            box = layout.box()
            box.label(text=" R")
            if map := self.get_single_channel_map(self.r_channel):
                map.draw_channel(context, box)

            box = layout.box()
            box.label(text=" G")
            if map := self.get_single_channel_map(self.g_channel):
                map.draw_channel(context, box)

            box = layout.box()
            box.label(text=" B")
            if map := self.get_single_channel_map(self.b_channel):
                map.draw_channel(context, box)
        else:
            box = layout.box()
            box.label(text=" RGB")
            if map := self.get_multi_channel_map(self.rgb_channel):
                map.draw_channel(context, box)

        box = layout.box()
        box.label(text=" A")
        if map := self.get_single_channel_map(self.a_channel):
            map.draw_channel(context, box)


class QBAKER_AP_map(PropertyGroup):
    pbr_items = (
        ("BASE_COLOR", "Base Color", "Base Color / Albedo / Diffuse Map"),
        ("EMISSION", "Emission", "Emission Map"),
        ("GLOSSINESS", "Glossiness", "Glossiness / Smoothness Map"),
        ("METALLIC", "Metallic", "Metallic Map"),
        ("NORMAL", "Normal", "Normal Map"),
        ("OCCLUSION", "Occlusion", "Occlusion Map"),
        ("ROUGHNESS", "Roughness", "Roughness Map"),
        ("SPECULAR", "Specular", "Specular Map"),
        ("CHANNEL_PACK", "Channel Pack", "Channel Pack Map"),
        (None),
    )

    mesh_items = (
        ("ALPHA", "Alpha", "Alpha / Opacity / Transparency Map"),
        ("BEVEL_NORMAL", "Bevel Normal", "Bevel Normal Map"),
        ("CAVITY", "Cavity", "Cavity Map"),
        ("CURVATURE", "Curvature", "Curvature Map"),
        ("EDGE", "Edge", "Edge Map"),
        ("DISPLACEMENT", "Displacement", "Displacement / Bump Map"),
        ("GRADIENT", "Gradient", "Gradient Map"),
        ("HEIGHT", "Heightmap", "Height Map"),
        ("MATERIAL_ID", "Material ID", "Material ID Map"),
        ("THICKNESS", "Thickness", "Thickness / Translucency Map"),
        ("VDM", "Vector Displacement", "Vector Displacement Map"),
        ("WIREFRAME", "Wireframe", "Wireframe / UV Layout Map"),
        ("XYZ", "XYZ", "XYZ Map"),
        (None),
    )

    principled_items = (
        ("SUBSURFACE", "Subsurface", "Subsurface Map"),
        ("SUBSURFACE_COLOR", "Subsurface Color", "Subsurface Color Map"),
        ("SUBSURFACE_IOR", "Subsurface IOR", "Subsurface IOR Map"),
        ("SUBSURFACE_ANISOTROPY", "Subsurface Anisotropy", "Subsurface Anisotropy Map"),
        ("SPECULAR_TINT", "Specular Tint", "Specular Tint Map"),
        ("ANISOTROPIC", "Anisotropic", "Anisotropic Map"),
        ("ANISOTROPIC_ROT", "Anisotropic Rotation", "Anisotropic Rotation Map"),
        ("SHEEN", "Sheen", "Sheen Map"),
        ("SHEEN_TINT", "Sheen Tint", "Sheen Tint Map"),
        ("CLEARCOAT", "Clearcoat", "Clearcoat Map"),
        ("CLEARCOAT_ROUGHNESS", "Clearcoat Roughness", "Clearcoat Roughness Map"),
        ("IOR", "IOR", "IOR Map"),
        (
            "TRANSMISSION_ROUGHNESS",
            "Transmission Roughness",
            "Transmission Roughness Map",
        ),
        ("EMISSION_STRENGTH", "Emission Strength", "Emission Strength Map"),
        ("CLEARCOAT_NORMAL", "Clearcoat Normal", "Clearcoat Normal Map"),
        ("TANGENT", "Tangent", "Tangent Map"),
        (None),
    )

    cycles_items = (
        ("AO", "Ambient Occlusion", "Ambient Occlusion Map"),
        ("COMBINED", "Combined", "Combined Map"),
        ("DIFFUSE", "Diffuse", "Diffuse Map"),
        ("ENVIRONMENT", "Environment", "Environment Map"),
        ("GLOSSY", "Glossy", "Glossy Map"),
        ("POSITION", "Position", "Position Map"),
        ("SHADOW", "Shadow", "Shadow Map"),
        ("TRANSMISSION", "Transmission", "Transmission Map"),
        ("UV", "UV", "UV Map"),
    )

    type: EnumProperty(
        name="Texture Type",
        description="Texture type",
        items=(pbr_items + mesh_items + principled_items + cycles_items),
    )

    pbr_type: EnumProperty(
        name="PBR Type",
        description="PBR type",
        items=(pbr_items),
    )

    mesh_type: EnumProperty(
        name="Mesh Type",
        description="Mesh type",
        items=(mesh_items),
    )

    principled_type: EnumProperty(
        name="Principled Type",
        description="Principled type",
        items=(principled_items),
    )

    cycles_type: EnumProperty(
        name="Cycles Type",
        description="Cycles type",
        items=(cycles_items),
    )

    # PBR
    base_color: PointerProperty(type=QBAKER_AP_base_color)
    emission: PointerProperty(type=QBAKER_AP_emission)
    glossiness: PointerProperty(type=QBAKER_AP_glossiness)
    metallic: PointerProperty(type=QBAKER_AP_metallic)
    normal: PointerProperty(type=QBAKER_AP_normal)
    occlusion: PointerProperty(type=QBAKER_AP_occlusion)
    roughness: PointerProperty(type=QBAKER_AP_roughness)
    specular: PointerProperty(type=QBAKER_AP_specular)
    channel_pack: PointerProperty(type=QBAKER_AP_channel_pack)
    # Mesh
    alpha: PointerProperty(type=QBAKER_AP_alpha)
    bevel_normal: PointerProperty(type=QBAKER_AP_bevel_normal)
    cavity: PointerProperty(type=QBAKER_AP_cavity)
    curvature: PointerProperty(type=QBAKER_AP_curvature)
    displacement: PointerProperty(type=QBAKER_AP_displacement)
    edge: PointerProperty(type=QBAKER_AP_edge)
    gradient: PointerProperty(type=QBAKER_AP_gradient)
    height: PointerProperty(type=QBAKER_AP_height)
    material_id: PointerProperty(type=QBAKER_AP_material_id)
    thickness: PointerProperty(type=QBAKER_AP_thickness)
    vdm: PointerProperty(type=QBAKER_AP_vdm)
    wireframe: PointerProperty(type=QBAKER_AP_wireframe)
    xyz: PointerProperty(type=QBAKER_AP_xyz)
    # Principled BSDF
    subsurface: PointerProperty(type=QBAKER_AP_subsurface)
    subsurface_color: PointerProperty(type=QBAKER_AP_subsurface_color)
    subsurface_ior: PointerProperty(type=QBAKER_AP_subsurface_ior)
    subsurface_anisotropy: PointerProperty(type=QBAKER_AP_subsurface_anisotropy)
    specular_tint: PointerProperty(type=QBAKER_AP_specular_tint)
    anisotropic: PointerProperty(type=QBAKER_AP_anisotropic)
    anisotropic_rotation: PointerProperty(type=QBAKER_AP_anisotropic_rotation)
    sheen: PointerProperty(type=QBAKER_AP_sheen)
    sheen_tint: PointerProperty(type=QBAKER_AP_sheen_tint)
    clearcoat: PointerProperty(type=QBAKER_AP_clearcoat)
    clearcoat_roughness: PointerProperty(type=QBAKER_AP_clearcoat_roughness)
    ior: PointerProperty(type=QBAKER_AP_ior)
    transmission_roughness: PointerProperty(type=QBAKER_AP_transmission_roughness)
    emission_strength: PointerProperty(type=QBAKER_AP_emission_strength)
    clearcoat_normal: PointerProperty(type=QBAKER_AP_clearcoat_normal)
    tangent: PointerProperty(type=QBAKER_AP_tangent)
    # Cycles
    ambient_occlusion: PointerProperty(type=QBAKER_AP_ambient_occlusion)
    combined: PointerProperty(type=QBAKER_AP_combined)
    diffuse: PointerProperty(type=QBAKER_AP_diffuse)
    environment: PointerProperty(type=QBAKER_AP_environment)
    glossy: PointerProperty(type=QBAKER_AP_glossy)
    position: PointerProperty(type=QBAKER_AP_position)
    shadow: PointerProperty(type=QBAKER_AP_shadow)
    transmission: PointerProperty(type=QBAKER_AP_transmission)
    uv: PointerProperty(type=QBAKER_AP_uv)

    def draw_pbr_maps(self, context, layout):
        if self.type == "BASE_COLOR":
            self.base_color.draw(context, layout)
        elif self.type == "EMISSION":
            self.emission.draw(context, layout)
        elif self.type == "GLOSSINESS":
            self.glossiness.draw(context, layout)
        elif self.type == "METALLIC":
            self.metallic.draw(context, layout)
        elif self.type == "NORMAL":
            self.normal.draw(context, layout)
        elif self.type == "OCCLUSION":
            self.occlusion.draw(context, layout)
        elif self.type == "ROUGHNESS":
            self.roughness.draw(context, layout)
        elif self.type == "SPECULAR":
            self.specular.draw(context, layout)
        elif self.type == "CHANNEL_PACK":
            self.channel_pack.draw(context, layout)
            self.channel_pack.draw_map(context, layout)

    def draw_mesh_maps(self, context, layout):
        if self.type == "ALPHA":
            self.alpha.draw(context, layout)
        elif self.type == "BEVEL_NORMAL":
            self.bevel_normal.draw(context, layout)
        elif self.type == "CAVITY":
            self.cavity.draw(context, layout)
        elif self.type == "CURVATURE":
            self.curvature.draw(context, layout)
        elif self.type == "DISPLACEMENT":
            self.displacement.draw(context, layout)
        elif self.type == "EDGE":
            self.edge.draw(context, layout)
        elif self.type == "GRADIENT":
            self.gradient.draw(context, layout)
        elif self.type == "HEIGHT":
            self.height.draw(context, layout)
        elif self.type == "MATERIAL_ID":
            self.material_id.draw(context, layout)
        elif self.type == "THICKNESS":
            self.thickness.draw(context, layout)
        elif self.type == "VDM":
            self.vdm.draw(context, layout)
        elif self.type == "WIREFRAME":
            self.wireframe.draw(context, layout)
        elif self.type == "XYZ":
            self.xyz.draw(context, layout)

    def draw_principled_maps(self, context, layout):
        if self.type == "SUBSURFACE":
            self.subsurface.draw(context, layout)
        elif self.type == "SUBSURFACE_COLOR":
            self.subsurface_color.draw(context, layout)
        elif self.type == "SUBSURFACE_IOR":
            self.subsurface_ior.draw(context, layout)
        elif self.type == "SUBSURFACE_ANISOTROPY":
            self.subsurface_anisotropy.draw(context, layout)
        elif self.type == "SPECULAR_TINT":
            self.specular_tint.draw(context, layout)
        elif self.type == "ANISOTROPIC":
            self.anisotropic.draw(context, layout)
        elif self.type == "ANISOTROPIC_ROT":
            self.anisotropic_rotation.draw(context, layout)
        elif self.type == "SHEEN":
            self.sheen.draw(context, layout)
        elif self.type == "SHEEN_TINT":
            self.sheen_tint.draw(context, layout)
        elif self.type == "CLEARCOAT":
            self.clearcoat.draw(context, layout)
        elif self.type == "CLEARCOAT_ROUGHNESS":
            self.clearcoat_roughness.draw(context, layout)
        elif self.type == "IOR":
            self.ior.draw(context, layout)
        elif self.type == "TRANSMISSION_ROUGHNESS":
            self.transmission_roughness.draw(context, layout)
        elif self.type == "EMISSION_STRENGTH":
            self.emission_strength.draw(context, layout)
        elif self.type == "CLEARCOAT_NORMAL":
            self.clearcoat_normal.draw(context, layout)
        elif self.type == "TANGENT":
            self.tangent.draw(context, layout)

    def draw_cycles_maps(self, context, layout):
        if self.type == "AO":
            self.ambient_occlusion.draw(context, layout)
        elif self.type == "COMBINED":
            self.combined.draw(context, layout)
        elif self.type == "DIFFUSE":
            self.diffuse.draw(context, layout)
        elif self.type == "ENVIRONMENT":
            self.environment.draw(context, layout)
        elif self.type == "GLOSSY":
            self.glossy.draw(context, layout)
        elif self.type == "POSITION":
            self.position.draw(context, layout)
        elif self.type == "SHADOW":
            self.shadow.draw(context, layout)
        elif self.type == "TRANSMISSION":
            self.transmission.draw(context, layout)
        elif self.type == "UV":
            self.uv.draw(context, layout)

    def draw(self, context, layout):
        self.draw_pbr_maps(context, layout)
        self.draw_mesh_maps(context, layout)
        self.draw_principled_maps(context, layout)
        self.draw_cycles_maps(context, layout)


class QBAKER_AP_bake(PropertyGroup):
    batch_name: StringProperty(
        name="Batch Name",
        description="Name the maps with additional info.\n\n$name - Name of the BakeGroup (Bakegroup_$size_$type).\n$size    - Size of the map ($name_1K_$type).\n$type   - Type of the map ($name_$size_Color)",
        default="$name_$size_$type",
    )

    size: EnumProperty(
        name="Size",
        description="Texture size",
        items=(
            ("512", "512", "512x512"),
            ("1024", "1024", "1024x1024"),
            ("2048", "2048", "2048x2048"),
            ("4096", "4096", "4096x4096"),
            ("8192", "8192", "8192x8192"),
            ("CUSTOM", "Custom", "Custom bake size"),
        ),
        default="1024",
    )

    size_custom: IntProperty(
        name="Custom",
        description="Custom texture size",
        subtype="PIXEL",
        min=2,
        default=1024,
    )

    format: EnumProperty(
        name="Format",
        description="File format to save the rendered images as",
        items=(
            ("PNG", "PNG", "Output image in PNG format"),
            ("JPEG", "JPEG", "Output image in JPEG format"),
            ("TARGA", "Targa", "Output image in Targa format"),
            ("TIFF", "TIFF", "Output image in TIFF format"),
            ("OPEN_EXR", "OpenEXR", "Output image in OpenEXR format"),
            ("WEBP", "WebP", "Output image in WebP format"),
        ),
        default="PNG",
    )

    color_depth: EnumProperty(
        name="Color Depth",
        description="Bit depth per channel",
        items=(
            ("8", "8", "8-bit color channels"),
            ("16", "16", "16-bit color channels"),
        ),
    )

    color_depth_exr: EnumProperty(
        name="Color Depth",
        description="Bit depth per channel",
        items=(
            ("16", "16", "16-bit color channels"),
            ("32", "32", "32-bit color channels"),
        ),
        default="32",
    )

    compression: IntProperty(
        name="Compression",
        description="Amount of time to determine best compression: 0 = no compression with fast file output, 100 = maximum lossless compression with slow file output",
        subtype="PERCENTAGE",
        min=0,
        max=100,
        default=15,
    )

    quality: IntProperty(
        name="Quality",
        description="Quality for image formats that support lossy compression",
        subtype="PERCENTAGE",
        min=0,
        max=100,
        default=90,
    )

    exr_codec: EnumProperty(
        name="Codec",
        description="Codec settings for OpenEXR",
        items=(
            ("NONE", "None", ""),
            ("PXR24", "Pxr24 (lossy)", ""),
            ("ZIP", "ZIP (lossless)", ""),
            ("PIZ", "PIZ (lossless)", ""),
            ("RLE", "RLE (lossless)", ""),
            ("ZIPS", "ZIPS (lossless)", ""),
            ("B44", "B44 (lossy)", ""),
            ("B44A", "B44A (lossy)", ""),
            ("DWAA", "DWAA (lossy)", ""),
            ("DWAB", "DWAB (lossy)", ""),
        ),
        default="ZIP",
    )

    tiff_codec: EnumProperty(
        name="Compression",
        description="Compression mode for TIFF",
        items=(
            ("NONE", "None", ""),
            ("DEFLATE", "Deflate", ""),
            ("LZW", "LZW", ""),
            ("PACKBITS", "Pack Bits", ""),
        ),
        default="DEFLATE",
    )

    dilate: BoolProperty(name="Dilate", description="Dilate or Infinite margin to the baked result")

    margin: IntProperty(
        name="Margin",
        description="Extends the baked result as a post process filter",
        subtype="PIXEL",
        min=0,
        soft_max=64,
        default=8,
    )

    def get_cpu_count():
        try:
            cpu_count = len(os.sched_getaffinity(0))
        except AttributeError:
            cpu_count = os.cpu_count()
        return cpu_count

    processes: IntProperty(
        name="Processes",
        description="Max processes used while baking",
        min=1,
        soft_max=int(get_cpu_count() / 2),
        max=get_cpu_count() - 2,
        default=int(get_cpu_count() / 4),
    )

    def draw(self, context, layout):
        layout.use_property_split = True
        layout.prop(self, "size")
        if self.size == "CUSTOM":
            layout.prop(self, "size_custom")
        layout.prop(self, "format")
        if self.format in {"PNG", "TIFF"}:
            row = layout.row(align=True)
            row.prop(self, "color_depth", expand=True)
            if self.format in {"TIFF"}:
                layout.prop(self, "tiff_codec")
        if self.format in {"OPEN_EXR"}:
            row = layout.row(align=True)
            row.prop(self, "color_depth_exr", expand=True)
            layout.prop(self, "exr_codec")
        if self.format in {"PNG"}:
            layout.prop(self, "compression")
        if self.format in {"JPEG", "WEBP"}:
            layout.prop(self, "quality")
        # row = layout.row(heading='Dilate', align=True)
        # row.prop(self, 'dilate', text='')
        # subrow = row.row()
        # if self.dilate:
        #     subrow.enabled = False
        # subrow.prop(self, 'margin')
        layout.prop(self, "margin")
        layout.prop(self, "processes")


class QBAKER_AP_cage(PropertyGroup):
    color: FloatVectorProperty(
        name="Cage Color",
        description="Color for cage objects",
        subtype="COLOR",
        size=4,
        min=0.0,
        max=1.0,
        default=(0.7, 0.6, 0.5, 0.5),
    )

    wireframe: BoolProperty(
        name="Wireframe",
        description="Display the object's wireframe over solid shading",
        default=True,
    )


class QBAKER_AP_qbaker(PropertyGroup):
    cage: PointerProperty(type=QBAKER_AP_cage)
    map: PointerProperty(type=QBAKER_AP_map)
    bake: PointerProperty(type=QBAKER_AP_bake)


class QBAKER_AP_preference(AddonPreferences):
    bl_idname = __package__

    pref_tabs: EnumProperty(
        name="Tabs",
        items=(("GENERAL", "General", ""), ("MAP", "Maps", ""), ("BAKE", "Bake", "")),
        default="GENERAL",
    )

    map_types: EnumProperty(
        name="Map Types",
        items=(
            ("PBR", "PBR", ""),
            ("MESH", "Mesh", ""),
            ("PRINCIPLED", "Principled BSDF", ""),
            ("CYCLES", "Cycles", ""),
        ),
        default="PBR",
    )

    qbaker: PointerProperty(type=QBAKER_AP_qbaker)

    def draw(self, context):
        layout = self.layout
        layout.use_property_decorate = False

        row = layout.row(align=True)
        row.prop(self, "pref_tabs", expand=True)

        if self.pref_tabs == "GENERAL":
            col = layout.column()
            col.use_property_split = True
            col.prop(self.qbaker.bake, "batch_name")

            col = layout.column(heading="Cage")
            col.use_property_split = True
            col.prop(self.qbaker.cage, "color")
            col.prop(self.qbaker.cage, "wireframe")
        elif self.pref_tabs == "MAP":
            row = layout.row()
            row.prop(self, "map_types", expand=True)
            self.draw_maps(layout, context)
        elif self.pref_tabs == "BAKE":
            col = layout.column()
            self.qbaker.bake.draw(context, layout=col)

    def draw_maps(self, layout, context):
        split = layout.split(factor=0.3)

        col = split.column(align=True)
        # col.prop(self.qbaker.map, 'type', expand=True)
        if self.map_types == "PBR":
            col.prop_enum(self.qbaker.map, "type", value="BASE_COLOR")
            col.prop_enum(self.qbaker.map, "type", value="EMISSION")
            col.prop_enum(self.qbaker.map, "type", value="GLOSSINESS")
            col.prop_enum(self.qbaker.map, "type", value="METALLIC")
            col.prop_enum(self.qbaker.map, "type", value="NORMAL")
            col.prop_enum(self.qbaker.map, "type", value="OCCLUSION")
            col.prop_enum(self.qbaker.map, "type", value="ROUGHNESS")
            col.prop_enum(self.qbaker.map, "type", value="SPECULAR")
            col.prop_enum(self.qbaker.map, "type", value="CHANNEL_PACK")
        elif self.map_types == "MESH":
            col.prop_enum(self.qbaker.map, "type", value="ALPHA")
            col.prop_enum(self.qbaker.map, "type", value="BEVEL_NORMAL")
            col.prop_enum(self.qbaker.map, "type", value="CAVITY")
            col.prop_enum(self.qbaker.map, "type", value="CURVATURE")
            col.prop_enum(self.qbaker.map, "type", value="EDGE")
            col.prop_enum(self.qbaker.map, "type", value="DISPLACEMENT")
            col.prop_enum(self.qbaker.map, "type", value="GRADIENT")
            col.prop_enum(self.qbaker.map, "type", value="HEIGHT")
            col.prop_enum(self.qbaker.map, "type", value="MATERIAL_ID")
            col.prop_enum(self.qbaker.map, "type", value="THICKNESS")
            col.prop_enum(self.qbaker.map, "type", value="VDM")
            col.prop_enum(self.qbaker.map, "type", value="WIREFRAME")
            col.prop_enum(self.qbaker.map, "type", value="XYZ")
        elif self.map_types == "PRINCIPLED":
            col.prop_enum(self.qbaker.map, "type", value="SUBSURFACE")
            col.prop_enum(self.qbaker.map, "type", value="SUBSURFACE_COLOR")
            col.prop_enum(self.qbaker.map, "type", value="SUBSURFACE_IOR")
            col.prop_enum(self.qbaker.map, "type", value="SUBSURFACE_ANISOTROPY")
            col.prop_enum(self.qbaker.map, "type", value="SPECULAR_TINT")
            col.prop_enum(self.qbaker.map, "type", value="ANISOTROPIC")
            col.prop_enum(self.qbaker.map, "type", value="ANISOTROPIC_ROT")
            col.prop_enum(self.qbaker.map, "type", value="SHEEN")
            col.prop_enum(self.qbaker.map, "type", value="SHEEN_TINT")
            col.prop_enum(self.qbaker.map, "type", value="CLEARCOAT")
            col.prop_enum(self.qbaker.map, "type", value="CLEARCOAT_ROUGHNESS")
            col.prop_enum(self.qbaker.map, "type", value="IOR")
            col.prop_enum(self.qbaker.map, "type", value="TRANSMISSION_ROUGHNESS")
            col.prop_enum(self.qbaker.map, "type", value="EMISSION_STRENGTH")
            col.prop_enum(self.qbaker.map, "type", value="CLEARCOAT_NORMAL")
            col.prop_enum(self.qbaker.map, "type", value="TANGENT")
        elif self.map_types == "CYCLES":
            col.prop_enum(self.qbaker.map, "type", value="AO")
            col.prop_enum(self.qbaker.map, "type", value="COMBINED")
            col.prop_enum(self.qbaker.map, "type", value="DIFFUSE")
            col.prop_enum(self.qbaker.map, "type", value="ENVIRONMENT")
            col.prop_enum(self.qbaker.map, "type", value="GLOSSY")
            col.prop_enum(self.qbaker.map, "type", value="POSITION")
            col.prop_enum(self.qbaker.map, "type", value="SHADOW")
            col.prop_enum(self.qbaker.map, "type", value="TRANSMISSION")
            col.prop_enum(self.qbaker.map, "type", value="UV")

        col = split.column()
        col.use_property_split = True
        box = col.box()
        self.qbaker.map.draw(context, layout=box)


classes = (
    QBAKER_AP_bake_settings,
    # PBR
    QBAKER_AP_base_color,
    QBAKER_AP_emission,
    QBAKER_AP_glossiness,
    QBAKER_AP_metallic,
    QBAKER_AP_normal,
    QBAKER_AP_occlusion,
    QBAKER_AP_roughness,
    QBAKER_AP_specular,
    # Mesh
    QBAKER_AP_alpha,
    QBAKER_AP_bevel_normal,
    QBAKER_AP_cavity,
    QBAKER_AP_curvature,
    QBAKER_AP_displacement,
    QBAKER_AP_edge,
    QBAKER_AP_gradient,
    QBAKER_AP_height,
    QBAKER_AP_material_id,
    QBAKER_AP_thickness,
    QBAKER_AP_vdm,
    QBAKER_AP_wireframe,
    QBAKER_AP_xyz,
    # Principled BSDF
    QBAKER_AP_subsurface,
    QBAKER_AP_subsurface_color,
    QBAKER_AP_subsurface_ior,
    QBAKER_AP_subsurface_anisotropy,
    QBAKER_AP_specular_tint,
    QBAKER_AP_anisotropic,
    QBAKER_AP_anisotropic_rotation,
    QBAKER_AP_sheen,
    QBAKER_AP_sheen_tint,
    QBAKER_AP_clearcoat,
    QBAKER_AP_clearcoat_roughness,
    QBAKER_AP_ior,
    QBAKER_AP_transmission_roughness,
    QBAKER_AP_emission_strength,
    QBAKER_AP_clearcoat_normal,
    QBAKER_AP_tangent,
    # Cycles
    QBAKER_AP_ambient_occlusion,
    QBAKER_AP_combined,
    QBAKER_AP_diffuse,
    QBAKER_AP_environment,
    QBAKER_AP_glossy,
    QBAKER_AP_position,
    QBAKER_AP_shadow,
    QBAKER_AP_transmission,
    QBAKER_AP_uv,
    QBAKER_AP_channel_pack,
    QBAKER_AP_cage,
    QBAKER_AP_map,
    QBAKER_AP_bake,
    QBAKER_AP_qbaker,
    QBAKER_AP_preference,
)


register, unregister = bpy.utils.register_classes_factory(classes)
