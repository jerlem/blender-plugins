# -*- coding: utf-8 -*-
"""
Properties definitions for Chord for Blender addon.
"""

import bpy
from bpy.props import (
    StringProperty,
    BoolProperty,
    IntProperty,
    FloatProperty,
    EnumProperty,
    PointerProperty,
    CollectionProperty
)


def poll_mesh_object(self, obj):
    return obj.type == 'MESH'


class CHORD_PG_HistoryItem(bpy.types.PropertyGroup):
    """Data item representing a generated PBR texture set in history."""
    name: StringProperty(name="Folder Name", default="")
    date: StringProperty(name="Created Date", default="")
    dir_path: StringProperty(name="Directory Path", default="")
    basecolor_path: StringProperty(name="BaseColor Path", default="")
    normal_path: StringProperty(name="Normal Path", default="")
    roughness_path: StringProperty(name="Roughness Path", default="")
    metalness_path: StringProperty(name="Metalness Path", default="")
    preview_path: StringProperty(name="Preview Path", default="")
    has_preview: BoolProperty(name="Has Preview", default=False)


def register_properties():
    # Navigation
    bpy.types.Scene.chord_active_tab = EnumProperty(
        name="Active Tab",
        items=[
            ('HOME', "Home", "Overview & Quick Start", 'HOME', 0),
            ('GENERATE', "Generate", "Generate PBR Textures", 'TEXTURE', 1),
            ('MATERIAL', "Material", "Material & Mesh Assignment", 'MATERIAL', 2),
            ('HISTORY', "History", "Browse and re-apply generated PBR textures", 'TIME', 3),
            ('SETTINGS', "Settings", "Server & Model Configuration", 'PREFERENCES', 4),
            ('ABOUT', "About", "Developer & Credits", 'INFO', 5),
        ],
        default='HOME'
    )

    # Server Configuration
    bpy.types.Scene.chord_server_mode = EnumProperty(
        name="Server Mode",
        items=[
            ('LOCAL', "Local Server", "Run local resident Chord AI server"),
            ('REMOTE', "Remote Server", "Connect to external / cloud server instance"),
        ],
        default='LOCAL'
    )
    bpy.types.Scene.chord_server_url = StringProperty(
        name="Server URL",
        description="HTTP URL for the Chord server",
        default="http://127.0.0.1:8188"
    )
    bpy.types.Scene.chord_server_port = IntProperty(
        name="Server Port",
        description="Local TCP Port for Chord server",
        default=8188,
        min=1024,
        max=65535
    )
    bpy.types.Scene.chord_server_status = StringProperty(
        name="Server Status",
        default="Offline"
    )
    bpy.types.Scene.chord_server_device = StringProperty(
        name="Server Device",
        default=""
    )
    bpy.types.Scene.chord_server_model = StringProperty(
        name="Model Loaded",
        default="Chord v1"
    )

    # Path Settings
    bpy.types.Scene.chord_repo_path = StringProperty(
        name="Chord Repo Path",
        description="Path to ubisoft-laforge-chord repository",
        default=r"C:\Git\ubisoft-laforge-chord",
        subtype='DIR_PATH'
    )
    bpy.types.Scene.chord_model_path = StringProperty(
        name="Model Checkpoint",
        description="Path to chord_v1.safetensors checkpoint",
        default=r"C:\Git\ubisoft-laforge-chord\model\chord_v1.safetensors",
        subtype='FILE_PATH'
    )

    # Generation State
    bpy.types.Scene.chord_is_generating = BoolProperty(
        name="Is Generating",
        default=False
    )
    bpy.types.Scene.chord_cancel_requested = BoolProperty(
        name="Cancel Requested",
        default=False
    )
    bpy.types.Scene.chord_generation_progress = FloatProperty(
        name="Progress",
        min=0.0,
        max=100.0,
        default=0.0,
        subtype='PERCENTAGE'
    )
    bpy.types.Scene.chord_status_message = StringProperty(
        name="Status Message",
        default="Ready"
    )

    # Generation Parameters
    bpy.types.Scene.chord_generation_mode = EnumProperty(
        name="Mode",
        items=[
            ('PROMPT', "Text to PBR Texture", "Generate texture from descriptive text prompt + decompose to PBR"),
            ('IMAGE', "Image to PBR Texture", "Decompose existing image file into PBR channels (SVBRDF)"),
        ],
        default='PROMPT'
    )
    bpy.types.Scene.chord_prompt = StringProperty(
        name="Prompt",
        description="Text description of the texture to generate",
        default="weathered medieval stone wall with green moss and cracked mortar, high detail 4k texture"
    )
    bpy.types.Scene.chord_negative_prompt = StringProperty(
        name="Negative Prompt",
        description="Artifacts and styles to avoid",
        default="blurry, low quality, artifacts, specular highlights, direct lighting reflections, distorted"
    )
    bpy.types.Scene.chord_input_image_path = StringProperty(
        name="Source Image",
        description="Input texture image to decompose into PBR channels",
        default="",
        subtype='FILE_PATH'
    )
    bpy.types.Scene.chord_seamless = BoolProperty(
        name="Seamless / Tileable",
        description="Generate seamless repeatable texture",
        default=True
    )
    bpy.types.Scene.chord_seed = IntProperty(
        name="Seed",
        description="Random seed for generation (-1 for random)",
        default=-1,
        min=-1
    )
    bpy.types.Scene.chord_steps = IntProperty(
        name="Steps",
        description="Diffusion sampling steps (20-30 recommended)",
        default=25,
        min=10,
        max=80
    )
    bpy.types.Scene.chord_guidance_scale = FloatProperty(
        name="CFG Scale",
        description="Prompt guidance scale",
        default=7.5,
        min=1.0,
        max=20.0
    )
    bpy.types.Scene.chord_resolution = EnumProperty(
        name="Resolution",
        items=[
            ('512', "512 x 512 (Fast)", "Faster generation"),
            ('1024', "1024 x 1024 (HD)", "Standard high resolution PBR maps"),
        ],
        default='1024'
    )

    # Mesh & Material Assignment
    bpy.types.Scene.chord_target_mesh = PointerProperty(
        name="Target Mesh",
        description="Mesh object to apply the generated PBR material onto",
        type=bpy.types.Object,
        poll=poll_mesh_object
    )
    bpy.types.Scene.chord_material_name = StringProperty(
        name="Material Name",
        description="Name of the created or updated material",
        default="M_Chord_PBR"
    )
    bpy.types.Scene.chord_auto_unwrap = BoolProperty(
        name="Auto Smart UV",
        description="Automatically perform Smart UV Project if object has no UV map",
        default=True
    )
    bpy.types.Scene.chord_uv_tiling = FloatProperty(
        name="UV Tiling",
        description="UV mapping scale multiplier",
        default=1.0,
        min=0.01,
        max=50.0
    )
    bpy.types.Scene.chord_normal_strength = FloatProperty(
        name="Normal Strength",
        description="Strength of normal map displacement",
        default=1.0,
        min=0.0,
        max=5.0
    )
    bpy.types.Scene.chord_roughness_scale = FloatProperty(
        name="Roughness Scale",
        description="Roughness channel multiplier",
        default=1.0,
        min=0.0,
        max=2.0
    )
    bpy.types.Scene.chord_metallic_scale = FloatProperty(
        name="Metallic Scale",
        description="Metallic channel multiplier",
        default=1.0,
        min=0.0,
        max=2.0
    )

    # Output Cache & History
    bpy.types.Scene.chord_last_output_dir = StringProperty(name="Last Output Dir", default="")
    bpy.types.Scene.chord_last_basecolor = StringProperty(name="Last BaseColor", default="")
    bpy.types.Scene.chord_last_normal = StringProperty(name="Last Normal", default="")
    bpy.types.Scene.chord_last_roughness = StringProperty(name="Last Roughness", default="")
    bpy.types.Scene.chord_last_metalness = StringProperty(name="Last Metalness", default="")
    bpy.types.Scene.chord_last_preview = StringProperty(name="Last Preview", default="")

    # History Collection & Navigation
    bpy.types.Scene.chord_history_list = CollectionProperty(type=CHORD_PG_HistoryItem)
    bpy.types.Scene.chord_history_index = IntProperty(name="Active History Index", default=0)


def unregister_properties():
    props = [
        "chord_active_tab",
        "chord_history_list",
        "chord_history_index",
        "chord_server_mode",
        "chord_server_url",
        "chord_server_port",
        "chord_server_status",
        "chord_server_device",
        "chord_server_model",
        "chord_repo_path",
        "chord_model_path",
        "chord_is_generating",
        "chord_cancel_requested",
        "chord_generation_progress",
        "chord_status_message",
        "chord_generation_mode",
        "chord_prompt",
        "chord_negative_prompt",
        "chord_input_image_path",
        "chord_seamless",
        "chord_seed",
        "chord_steps",
        "chord_guidance_scale",
        "chord_resolution",
        "chord_target_mesh",
        "chord_material_name",
        "chord_auto_unwrap",
        "chord_uv_tiling",
        "chord_normal_strength",
        "chord_roughness_scale",
        "chord_metallic_scale",
        "chord_last_output_dir",
        "chord_last_basecolor",
        "chord_last_normal",
        "chord_last_roughness",
        "chord_last_metalness",
        "chord_last_preview",
    ]
    for prop in props:
        if hasattr(bpy.types.Scene, prop):
            delattr(bpy.types.Scene, prop)
