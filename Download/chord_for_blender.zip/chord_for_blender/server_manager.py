# -*- coding: utf-8 -*-
"""
Server Manager module for Chord for Blender.
Manages the lifecycle of the local Chord AI resident server:
- Environment detection & setup (uv, Python, PyTorch cu128, diffusers, transformers)
- Non-blocking execution in dedicated Windows console
- Server Start, Stop, Health Check, and Uninstallation
"""

import os
import sys
import stat
import json
import time
import shutil
import urllib.request
import urllib.error
import subprocess
from pathlib import Path


def get_addon_dir() -> Path:
    return Path(__file__).parent.resolve()


def get_default_localserv_path() -> Path:
    addon_dir = get_addon_dir()
    return (addon_dir.parent / "chord_localserv").resolve()


def find_uv_executable() -> str:
    # 1. System PATH
    uv_path = shutil.which("uv")
    if uv_path and Path(uv_path).exists():
        return uv_path

    # 2. Pinokio miniforge uv
    candidates = [
        Path(r"C:\pinokio\bin\miniforge\Library\bin\uv.exe"),
        Path(r"C:\pinokio\bin\miniforge\pkgs\uv-0.11.23-h2229357_0\Library\bin\uv.exe"),
        Path(r"C:\pinokio\api\comfy.git\app\env\Scripts\uv.exe"),
    ]
    for cand in candidates:
        if cand.exists():
            return str(cand)

    return ""


def check_installation_status(localserv_path: Path = None) -> dict:
    if localserv_path is None:
        localserv_path = get_default_localserv_path()
    localserv_path = Path(localserv_path)

    if not localserv_path.exists():
        return {
            "installed": False,
            "status": "NOT_FOUND",
            "message": "chord_localserv folder not found",
            "path": str(localserv_path),
            "python_path": "",
            "server_script": ""
        }

    py_path = localserv_path / "env" / "Scripts" / "python.exe"
    python_exists = py_path.exists()
    if not python_exists:
        # Check sibling localserv (Quasi_Modo environment)
        sibling_py = localserv_path.parent / "localserv" / "env" / "Scripts" / "python.exe"
        if sibling_py.exists():
            py_path = sibling_py
            python_exists = True

    server_script = localserv_path / "chord_server.py"
    if not server_script.exists():
        addon_server = get_addon_dir() / "server" / "chord_server.py"
        if addon_server.exists():
            server_script = addon_server
    server_exists = server_script.exists()

    is_complete = python_exists and (
        (localserv_path / "install_complete.tag").exists()
        or (localserv_path.parent / "localserv" / "install_complete.tag").exists()
    )

    return {
        "installed": is_complete,
        "status": "INSTALLED" if is_complete else "INCOMPLETE",
        "message": "Local server ready" if is_complete else "Installation incomplete",
        "path": str(localserv_path),
        "python_path": str(py_path) if python_exists else "",
        "server_script": str(server_script) if server_exists else "",
        "python_exists": python_exists,
        "server_exists": server_exists
    }


def check_server_health(url: str = "http://127.0.0.1:8188", timeout: float = 1.2) -> dict:
    url = url.rstrip('/')
    req = urllib.request.Request(f"{url}/health", headers={'User-Agent': 'Blender-Chord'})
    try:
        with urllib.request.urlopen(req, timeout=timeout) as response:
            if response.status == 200:
                data = json.loads(response.read().decode('utf-8'))
                return {
                    "online": True,
                    "status": "Online",
                    "device": data.get("device", "Unknown"),
                    "model": data.get("model", "Chord-v1"),
                    "details": data
                }
    except Exception:
        pass
    return {
        "online": False,
        "status": "Offline",
        "device": "",
        "model": "",
        "details": {}
    }


def generate_installer_script(
    localserv_path: Path = None,
    repo_path: str = r"C:\Git\ubisoft-laforge-chord",
    model_path: str = r"C:\Git\ubisoft-laforge-chord\model\chord_v1.safetensors"
) -> tuple[Path, Path]:
    if localserv_path is None:
        localserv_path = get_default_localserv_path()
    localserv_path = Path(localserv_path)
    localserv_path.mkdir(parents=True, exist_ok=True)
    ps1_file = localserv_path / "install_chord.ps1"
    bat_file = localserv_path / "install_chord.bat"

    addon_server_dir = get_addon_dir() / "server"
    known_uv = find_uv_executable().replace("\\", "/")
    addon_server_src = str(addon_server_dir).replace("\\", "/")
    repo_path_clean = repo_path.replace("\\", "/")
    model_path_clean = model_path.replace("\\", "/")

    ps1_content = f"""# Chord for Blender Local Server Installer
$Host.UI.RawUI.WindowTitle = "Chord for Blender - Local Server Installer"

Write-Host "==============================================================================" -ForegroundColor Cyan
Write-Host "       CHORD FOR BLENDER : LOCAL AI SERVER SETUP (CUDA 12.8)                  " -ForegroundColor Cyan
Write-Host "==============================================================================" -ForegroundColor Cyan
Write-Host ""
Write-Host "Target Directory : $PSScriptRoot"
Write-Host "Chord Repo Path  : {repo_path_clean}"
Write-Host "Model Weights    : {model_path_clean}"
Write-Host ""

Set-Location -Path "$PSScriptRoot"

# 1. Verification of uv
Write-Host "[1/5] Configuring uv package manager..." -ForegroundColor Yellow
$uvExe = ""
if ("{known_uv}" -ne "" -and (Test-Path "{known_uv}")) {{
    $uvExe = "{known_uv}"
}} elseif (Test-Path "$PSScriptRoot\\tools\\uv.exe") {{
    $uvExe = "$PSScriptRoot\\tools\\uv.exe"
}} else {{
    $systemUv = Get-Command uv -ErrorAction SilentlyContinue
    if ($systemUv) {{
        $uvExe = "uv"
    }}
}}

if (-not $uvExe) {{
    New-Item -ItemType Directory -Force -Path "$PSScriptRoot\\tools" | Out-Null
    $zipPath = "$PSScriptRoot\\tools\\uv.zip"
    Write-Host "      Downloading standalone uv from Astral GitHub..." -ForegroundColor Yellow
    [Net.ServicePointManager]::SecurityProtocol = [Net.SecurityProtocolType]::Tls12
    try {{
        Invoke-WebRequest -Uri "https://github.com/astral-sh/uv/releases/latest/download/uv-x86_64-pc-windows-msvc.zip" -OutFile $zipPath
        Expand-Archive -Path $zipPath -DestinationPath "$PSScriptRoot\\tools" -Force
        Remove-Item -Path $zipPath -Force
        if (Test-Path "$PSScriptRoot\\tools\\uv.exe") {{
            $uvExe = "$PSScriptRoot\\tools\\uv.exe"
        }} elseif (Test-Path "$PSScriptRoot\\tools\\uv-x86_64-pc-windows-msvc\\uv.exe") {{
            $uvExe = "$PSScriptRoot\\tools\\uv-x86_64-pc-windows-msvc\\uv.exe"
        }}
    }} catch {{
        Write-Host "[ERROR] Could not download uv: $_" -ForegroundColor Red
        Write-Host ""
        Read-Host "Press Enter to exit"
        exit 1
    }}
}}

if (-not $uvExe) {{
    Write-Host "[ERROR] uv package manager could not be found or downloaded." -ForegroundColor Red
    Write-Host ""
    Read-Host "Press Enter to exit"
    exit 1
}}
Write-Host "      uv configured : $uvExe" -ForegroundColor Green

# 2. Create isolated Python 3.10 virtual environment
Write-Host ""
Write-Host "[2/5] Creating isolated Python 3.10 virtual environment..." -ForegroundColor Yellow
$pyPath = "$PSScriptRoot\\env\\Scripts\\python.exe"
if (-not (Test-Path $pyPath)) {{
    & "$uvExe" venv "$PSScriptRoot\\env" --python 3.10
    if ($LASTEXITCODE -ne 0) {{
        Write-Host "[ERROR] Failed to create Python environment with uv." -ForegroundColor Red
        Write-Host ""
        Read-Host "Press Enter to exit"
        exit 1
    }}
}} else {{
    Write-Host "      Python environment already exists." -ForegroundColor Green
}}

# 3. Install PyTorch CUDA 12.8 and AI dependencies
Write-Host ""
Write-Host "[3/5] Installing PyTorch CUDA 12.8..." -ForegroundColor Yellow
& "$uvExe" pip install --python "$pyPath" torch torchvision --index-url https://download.pytorch.org/whl/cu128

Write-Host ""
Write-Host "[4/5] Installing AI texturing & diffusion dependencies..." -ForegroundColor Yellow
& "$uvExe" pip install --python "$pyPath" diffusers transformers==4.57.1 tokenizers==0.22.1 omegaconf typer safetensors imageio tqdm pillow huggingface_hub

# 4. Check for Hugging Face cache reuse
$pinokioHf = "C:\\pinokio\\api\\Kimodo.pinokio.git\\cache\\HF_HOME"
if (Test-Path $pinokioHf) {{
    Write-Host "      Reusing existing HuggingFace model cache ($pinokioHf)" -ForegroundColor Green
    [System.Environment]::SetEnvironmentVariable("HF_HOME", $pinokioHf, "Process")
}}

# 5. Deploy server scripts and mark complete
Write-Host ""
Write-Host "[5/5] Deploying Chord server files..." -ForegroundColor Yellow
$serverSrc = "{addon_server_src}"
Copy-Item -Path "$serverSrc/chord_server.py" -Destination "$PSScriptRoot/chord_server.py" -Force

Set-Content -Path "$PSScriptRoot\\install_complete.tag" -Value "install_complete"

Write-Host ""
Write-Host "==============================================================================" -ForegroundColor Green
Write-Host "   SUCCESS: Chord local AI server is installed and ready!                     " -ForegroundColor Green
Write-Host "   You can now close this window and click 'Start Server' in Blender.         " -ForegroundColor Green
Write-Host "==============================================================================" -ForegroundColor Green
Write-Host ""
Read-Host "Press Enter to finish"
"""
    ps1_file.write_text(ps1_content, encoding="utf-8")

    bat_content = f"""@echo off
title Chord for Blender Local Server Installer
powershell.exe -NoExit -ExecutionPolicy Bypass -File "%~dp0install_chord.ps1"
pause
"""
    bat_file.write_text(bat_content, encoding="utf-8")
    return ps1_file, bat_file


def launch_installer(
    localserv_path: Path = None,
    repo_path: str = r"C:\Git\ubisoft-laforge-chord",
    model_path: str = r"C:\Git\ubisoft-laforge-chord\model\chord_v1.safetensors"
) -> bool:
    if localserv_path is None:
        localserv_path = get_default_localserv_path()
    localserv_path = Path(localserv_path)
    ps1_file, bat_file = generate_installer_script(localserv_path, repo_path, model_path)

    try:
        cmd = [
            "powershell.exe",
            "-NoExit",
            "-ExecutionPolicy", "Bypass",
            "-File", str(ps1_file)
        ]
        subprocess.Popen(
            cmd,
            cwd=str(localserv_path),
            creationflags=subprocess.CREATE_NEW_CONSOLE
        )
        return True
    except Exception as e:
        print(f"[CHORD] Error launching PowerShell installer: {e}", file=sys.stderr)
        try:
            subprocess.Popen(
                ["cmd.exe", "/k", str(bat_file)],
                cwd=str(localserv_path),
                creationflags=subprocess.CREATE_NEW_CONSOLE
            )
            return True
        except Exception as e2:
            print(f"[CHORD] Error launching batch fallback: {e2}", file=sys.stderr)
            return False


def start_local_server(
    localserv_path: Path = None,
    port: int = 8188,
    repo_path: str = r"C:\Git\ubisoft-laforge-chord",
    model_path: str = r"C:\Git\ubisoft-laforge-chord\model\chord_v1.safetensors"
) -> tuple[bool, str]:
    if localserv_path is None:
        localserv_path = get_default_localserv_path()
    localserv_path = Path(localserv_path)

    status = check_installation_status(localserv_path)
    if not status["installed"]:
        return False, "Local server is not yet installed. Please run installation first."

    # Check if already running
    health = check_server_health(f"http://127.0.0.1:{port}", timeout=0.8)
    if health["online"]:
        return True, "Server is already running."

    py_path = status["python_path"]
    work_dir = localserv_path

    # Sync server script
    addon_server_dir = get_addon_dir() / "server"
    try:
        shutil.copy2(addon_server_dir / "chord_server.py", work_dir / "chord_server.py")
    except Exception as se:
        print(f"[CHORD] Warning syncing server script: {se}")
    server_script = str(work_dir / "chord_server.py")

    env = os.environ.copy()
    pinokio_hf = Path(r"C:\pinokio\api\Kimodo.pinokio.git\cache\HF_HOME")
    if pinokio_hf.exists() and "HF_HOME" not in env:
        env["HF_HOME"] = str(pinokio_hf)
    env["CHORD_REPO_PATH"] = repo_path
    env["CHORD_MODEL_PATH"] = model_path

    cmd = [py_path, server_script, str(port)]
    try:
        proc = subprocess.Popen(
            cmd,
            cwd=str(work_dir),
            env=env,
            creationflags=subprocess.CREATE_NEW_CONSOLE
        )
        (work_dir / "server.pid").write_text(str(proc.pid), encoding="utf-8")
        return True, f"Server started (PID {proc.pid}). Model loading in background..."
    except Exception as e:
        return False, f"Failed to start server: {e}"


def stop_local_server(localserv_path: Path = None, port: int = 8188) -> tuple[bool, str]:
    if localserv_path is None:
        localserv_path = get_default_localserv_path()
    localserv_path = Path(localserv_path)

    stopped = False

    # 1. Graceful HTTP shutdown
    try:
        req = urllib.request.Request(f"http://127.0.0.1:{port}/shutdown", headers={'User-Agent': 'Blender-Chord'})
        with urllib.request.urlopen(req, timeout=1.5) as r:
            if r.status == 200:
                stopped = True
    except Exception:
        pass

    # 2. Check PID file fallback
    pid_file = localserv_path / "server.pid"
    if pid_file.exists():
        try:
            pid = int(pid_file.read_text(encoding="utf-8").strip())
            subprocess.run(["taskkill", "/F", "/PID", str(pid), "/T"], capture_output=True)
            stopped = True
        except Exception:
            pass
        try:
            pid_file.unlink()
        except Exception:
            pass

    time.sleep(0.5)
    health = check_server_health(f"http://127.0.0.1:{port}", timeout=0.8)
    if not health["online"]:
        return True, "Server stopped successfully."
    elif stopped:
        return True, "Stop signal sent to server."
    else:
        return False, "Server is not running or refused to stop."


def uninstall_localserv(localserv_path: Path = None, port: int = 8188) -> tuple[bool, str]:
    if localserv_path is None:
        localserv_path = get_default_localserv_path()
    localserv_path = Path(localserv_path)

    if not localserv_path.exists():
        return True, "chord_localserv directory already deleted."

    try:
        stop_local_server(localserv_path, port)
    except Exception:
        pass

    time.sleep(0.5)

    try:
        subprocess.run(["attrib", "-r", "/s", "/d", str(localserv_path / "*")], capture_output=True, check=False)
    except Exception:
        pass

    def _remove_readonly(func, path, exc):
        try:
            os.chmod(path, stat.S_IWRITE | stat.S_IREAD)
            func(path)
        except Exception:
            pass

    try:
        shutil.rmtree(localserv_path, onerror=_remove_readonly)
        return True, "Local server uninstalled and directory removed."
    except Exception as e:
        return False, f"Could not remove folder: {e}"
