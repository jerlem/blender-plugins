# -*- coding: utf-8 -*-
"""
Chord for Blender - AI PBR Material & Texture Generation Studio.
Integrates Ubisoft LaForge Chord for SVBRDF estimation and PBR texturing directly onto meshes.
Compatible with Blender 4.2 LTS, 5.x.
"""

bl_info = {
    "name": "Chord for blender",
    "author": "Jérôme Lemarchand (goblingames.fr@gmail.com)",
    "version": (1, 0, 0),
    "blender": (4, 2, 0),
    "location": "View3D > Sidebar > Chord",
    "description": "AI PBR Material & Texture Generation with Ubisoft LaForge Chord",
    "category": "Material",
}

import bpy
import importlib

from . import properties
from . import material_manager
from . import server_manager
from . import operators_server
from . import operators_texture
from . import ui_panels

# Reload modules for active development
importlib.reload(properties)
importlib.reload(material_manager)
importlib.reload(server_manager)
importlib.reload(operators_server)
importlib.reload(operators_texture)
importlib.reload(ui_panels)

CLASSES = (
    properties.CHORD_PG_HistoryItem,
    operators_server.CHORD_OT_CheckServerStatus,
    operators_server.CHORD_OT_StartLocalServer,
    operators_server.CHORD_OT_StopLocalServer,
    operators_server.CHORD_OT_InstallLocalServer,
    operators_server.CHORD_OT_UninstallLocalServer,
    operators_server.CHORD_OT_OpenLocalServerFolder,
    operators_server.CHORD_OT_ToggleBlenderConsole,
    operators_texture.CHORD_OT_PickTargetMesh,
    operators_texture.CHORD_OT_RandomizeSeed,
    operators_texture.CHORD_OT_CancelGeneration,
    operators_texture.CHORD_OT_ForceResetGeneration,
    operators_texture.CHORD_OT_OpenOutputFolder,
    operators_texture.CHORD_OT_ApplyMaterial,
    operators_texture.CHORD_OT_GenerateTexture,
    operators_texture.CHORD_OT_RefreshHistory,
    operators_texture.CHORD_OT_ApplyHistoryItem,
    operators_texture.CHORD_OT_DeleteHistoryItem,
    ui_panels.CHORD_OT_SwitchTab,
    ui_panels.CHORD_OT_About,
    ui_panels.CHORD_UL_HistoryList,
    ui_panels.CHORD_PT_MainPanel,
)


@bpy.app.handlers.persistent
def ensure_default_state(dummy=None):
    try:
        sc = bpy.context.scene if bpy.context else None
        if sc:
            if hasattr(sc, "chord_is_generating") and sc.chord_is_generating:
                sc.chord_is_generating = False
            if hasattr(sc, "chord_cancel_requested") and sc.chord_cancel_requested:
                sc.chord_cancel_requested = False
    except Exception:
        pass


def register():
    for cls in CLASSES:
        bpy.utils.register_class(cls)
    properties.register_properties()

    # Reset any stuck generation flags in the current scene
    try:
        sc = bpy.context.scene if bpy.context else None
        if sc:
            if hasattr(sc, "chord_is_generating"):
                sc.chord_is_generating = False
            if hasattr(sc, "chord_cancel_requested"):
                sc.chord_cancel_requested = False
    except Exception:
        pass

    if ensure_default_state not in bpy.app.handlers.load_post:
        bpy.app.handlers.load_post.append(ensure_default_state)
    ensure_default_state()


def unregister():
    if ensure_default_state in bpy.app.handlers.load_post:
        bpy.app.handlers.load_post.remove(ensure_default_state)
    ui_panels.clear_preview_collections()
    properties.unregister_properties()
    for cls in reversed(CLASSES):
        try:
            bpy.utils.unregister_class(cls)
        except Exception:
            pass


if __name__ == "__main__":
    register()
