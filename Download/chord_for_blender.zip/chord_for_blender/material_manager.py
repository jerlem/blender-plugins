# -*- coding: utf-8 -*-
"""
Material Manager for Chord for Blender.
Builds and assigns Principled BSDF PBR shader node networks directly on Blender mesh objects.
"""

import os
from pathlib import Path
import bpy


def ensure_uv_map(obj):
    """Ensure the mesh object has a valid UV map, unwrapping if necessary."""
    if obj.type != 'MESH':
        return False

    mesh = obj.data
    if len(mesh.uv_layers) > 0:
        return True

    # No UV layers exist, let's auto-unwrap using Smart UV Project
    try:
        prev_mode = obj.mode
        prev_active = bpy.context.view_layer.objects.active
        bpy.context.view_layer.objects.active = obj
        bpy.ops.object.mode_set(mode='EDIT')
        bpy.ops.mesh.select_all(action='SELECT')
        bpy.ops.uv.smart_project(angle_limit=66.0, margin_method='SCALED', island_margin=0.02)
        bpy.ops.object.mode_set(mode=prev_mode if prev_mode != 'EDIT' else 'OBJECT')
        if prev_active:
            bpy.context.view_layer.objects.active = prev_active
        return len(mesh.uv_layers) > 0
    except Exception as e:
        print(f"[CHORD] Auto-UV unwrap failed: {e}")
        return False


def load_or_reload_image(image_path: str, colorspace: str = 'sRGB'):
    """Load or reload an image file cleanly into Blender, resolving relative paths if needed."""
    if not image_path:
        return None

    path_obj = Path(image_path)
    if not path_obj.exists():
        # Check candidate locations
        addon_dir = Path(__file__).parent.resolve()
        candidates = [
            addon_dir.parent / "chord_localserv" / image_path,
            addon_dir.parent / "chord_localserv" / path_obj.name,
            addon_dir / image_path,
        ]
        # Also check all subfolders in chord_localserv
        localserv_dir = addon_dir.parent / "chord_localserv"
        if localserv_dir.exists():
            for sub in localserv_dir.iterdir():
                if sub.is_dir():
                    candidates.append(sub / path_obj.name)

        found = False
        for cand in candidates:
            if cand.exists():
                path_obj = cand.resolve()
                found = True
                break
        if not found:
            print(f"[CHORD] Cannot find image file: {image_path}")
            return None

    norm_path = os.path.normpath(str(path_obj.resolve()))
    img_name = path_obj.name

    # Check if already loaded
    img = None
    for existing in bpy.data.images:
        if existing.filepath and os.path.normpath(bpy.path.abspath(existing.filepath)) == norm_path:
            img = existing
            img.reload()
            break

    if img is None:
        try:
            img = bpy.data.images.load(norm_path, check_existing=True)
        except Exception as e:
            print(f"[CHORD] Failed to load image {norm_path}: {e}")
            return None

    try:
        if colorspace in img.colorspace_settings.enum_items:
            img.colorspace_settings.name = colorspace
        elif 'Non-Color' in colorspace and 'Non-Color' in img.colorspace_settings.enum_items:
            img.colorspace_settings.name = 'Non-Color'
    except Exception:
        pass

    return img


def apply_pbr_material(
    obj: bpy.types.Object,
    basecolor_path: str,
    normal_path: str,
    roughness_path: str,
    metalness_path: str,
    material_name: str = "M_Chord_PBR",
    uv_tiling: float = 1.0,
    normal_strength: float = 1.0,
    roughness_scale: float = 1.0,
    metallic_scale: float = 1.0,
    auto_unwrap: bool = True
) -> bpy.types.Material:
    """Builds a complete Principled BSDF node network with PBR textures and assigns to mesh."""
    if obj is None or obj.type != 'MESH':
        raise ValueError("Target object must be a valid mesh.")

    # 1. Ensure UV mapping exists
    if auto_unwrap:
        ensure_uv_map(obj)

    # 2. Get or create Material
    mat = bpy.data.materials.get(material_name)
    if mat is None:
        mat = bpy.data.materials.new(name=material_name)
    mat.use_nodes = True
    nodes = mat.node_tree.nodes
    links = mat.node_tree.links

    # Clear nodes to rebuild cleanly
    nodes.clear()

    # 3. Create nodes
    # Output Node
    node_out = nodes.new(type='ShaderNodeOutputMaterial')
    node_out.location = (800, 0)

    # Principled BSDF
    node_bsdf = nodes.new(type='ShaderNodeBsdfPrincipled')
    node_bsdf.location = (400, 0)
    links.new(node_bsdf.outputs['BSDF'], node_out.inputs['Surface'])

    # Texture Coordinate & Mapping
    node_tex_coord = nodes.new(type='ShaderNodeTexCoord')
    node_tex_coord.location = (-600, 0)

    node_mapping = nodes.new(type='ShaderNodeMapping')
    node_mapping.location = (-400, 0)
    node_mapping.inputs['Scale'].default_value = (uv_tiling, uv_tiling, 1.0)
    links.new(node_tex_coord.outputs['UV'], node_mapping.inputs['Vector'])

    # 4. Connect Base Color
    img_bc = load_or_reload_image(basecolor_path, colorspace='sRGB')
    if img_bc:
        node_bc = nodes.new(type='ShaderNodeTexImage')
        node_bc.label = "Base Color (Albedo)"
        node_bc.image = img_bc
        node_bc.location = (-100, 250)
        links.new(node_mapping.outputs['Vector'], node_bc.inputs['Vector'])
        if 'Base Color' in node_bsdf.inputs:
            links.new(node_bc.outputs['Color'], node_bsdf.inputs['Base Color'])

    # 5. Connect Roughness
    img_rou = load_or_reload_image(roughness_path, colorspace='Non-Color')
    if img_rou:
        node_rou = nodes.new(type='ShaderNodeTexImage')
        node_rou.label = "Roughness"
        node_rou.image = img_rou
        node_rou.location = (-100, -20)
        links.new(node_mapping.outputs['Vector'], node_rou.inputs['Vector'])

        if abs(roughness_scale - 1.0) > 0.001:
            node_mult_r = nodes.new(type='ShaderNodeMath')
            node_mult_r.operation = 'MULTIPLY'
            node_mult_r.location = (150, -20)
            node_mult_r.inputs[1].default_value = roughness_scale
            links.new(node_rou.outputs['Color'], node_mult_r.inputs[0])
            if 'Roughness' in node_bsdf.inputs:
                links.new(node_mult_r.outputs['Value'], node_bsdf.inputs['Roughness'])
        else:
            if 'Roughness' in node_bsdf.inputs:
                links.new(node_rou.outputs['Color'], node_bsdf.inputs['Roughness'])

    # 6. Connect Metallic
    img_met = load_or_reload_image(metalness_path, colorspace='Non-Color')
    if img_met:
        node_met = nodes.new(type='ShaderNodeTexImage')
        node_met.label = "Metallic"
        node_met.image = img_met
        node_met.location = (-100, -280)
        links.new(node_mapping.outputs['Vector'], node_met.inputs['Vector'])

        if abs(metallic_scale - 1.0) > 0.001:
            node_mult_m = nodes.new(type='ShaderNodeMath')
            node_mult_m.operation = 'MULTIPLY'
            node_mult_m.location = (150, -280)
            node_mult_m.inputs[1].default_value = metallic_scale
            links.new(node_met.outputs['Color'], node_mult_m.inputs[0])
            if 'Metallic' in node_bsdf.inputs:
                links.new(node_mult_m.outputs['Value'], node_bsdf.inputs['Metallic'])
        else:
            if 'Metallic' in node_bsdf.inputs:
                links.new(node_met.outputs['Color'], node_bsdf.inputs['Metallic'])

    # 7. Connect Normal Map
    img_nor = load_or_reload_image(normal_path, colorspace='Non-Color')
    if img_nor:
        node_nor = nodes.new(type='ShaderNodeTexImage')
        node_nor.label = "Normal Map"
        node_nor.image = img_nor
        node_nor.location = (-100, -540)
        links.new(node_mapping.outputs['Vector'], node_nor.inputs['Vector'])

        node_normap = nodes.new(type='ShaderNodeNormalMap')
        node_normap.location = (150, -540)
        node_normap.inputs['Strength'].default_value = normal_strength
        links.new(node_nor.outputs['Color'], node_normap.inputs['Color'])

        if 'Normal' in node_bsdf.inputs:
            links.new(node_normap.outputs['Normal'], node_bsdf.inputs['Normal'])

    # 8. Assign Material to Object & Material Slots
    if len(obj.data.materials) == 0:
        obj.data.materials.append(mat)
    else:
        obj.data.materials[0] = mat

    if len(obj.material_slots) == 0:
        # Creating a slot if none exists
        try:
            obj.data.materials.append(mat)
        except Exception:
            pass
    if len(obj.material_slots) > 0:
        obj.material_slots[0].link = 'DATA'
        obj.material_slots[0].material = mat

    obj.active_material = mat

    # 9. Set Viewport Shading to Material Preview mode so user sees the result immediately
    try:
        for area in bpy.context.screen.areas:
            if area.type == 'VIEW_3D':
                for space in area.spaces:
                    if space.type == 'VIEW_3D':
                        space.shading.type = 'MATERIAL'
    except Exception:
        pass

    return mat
