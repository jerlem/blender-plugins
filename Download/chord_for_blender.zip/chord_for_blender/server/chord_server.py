# -*- coding: utf-8 -*-
"""
Resident HTTP Server for Chord PBR Material Generation.
Keeps Stable Diffusion & Ubisoft Chord AI models resident in GPU VRAM for fast on-demand generations.
Listens on http://127.0.0.1:8188 by default.
"""

import sys
import os
import json
import time
import random
import tempfile
import threading
from pathlib import Path
from http.server import HTTPServer, BaseHTTPRequestHandler
from socketserver import ThreadingMixIn

CURRENT_DIR = str(Path(__file__).parent.resolve())
if CURRENT_DIR not in sys.path:
    sys.path.insert(0, CURRENT_DIR)

os.environ["HF_HUB_DISABLE_SYMLINKS_WARNING"] = "1"

# Chord repository path
REPO_PATH = Path(os.environ.get("CHORD_REPO_PATH", r"C:\Git\ubisoft-laforge-chord")).resolve()
if str(REPO_PATH) not in sys.path:
    sys.path.insert(0, str(REPO_PATH))

# Global variables
DEVICE = "cpu"
SERVER_INSTANCE = None
CHORD_MODEL = None
SD_PIPELINE = None

PROGRESS_STATE = {
    "status": "idle",
    "step": 0,
    "total_steps": 25,
    "percent": 0.0,
    "message": "Ready",
    "cancelled": False
}
CANCEL_EVENT = threading.Event()

try:
    import torch
    from torchvision.transforms import v2
    from PIL import Image
    from omegaconf import OmegaConf
    from chord import ChordModel
    from chord.io import read_image, save_maps, load_torch_file, create_img

    DEVICE = "cuda" if torch.cuda.is_available() else "cpu"
    print(f"[CHORD SERVER] PyTorch initialized on {DEVICE}")
    if DEVICE == "cuda":
        print(f"[CHORD SERVER] Device Name: {torch.cuda.get_device_name(0)}")
except Exception as e:
    print(f"[CHORD SERVER INIT ERROR] {e}", file=sys.stderr)


def get_chord_model():
    """Loads and caches ChordModel with chord_v1 weights in VRAM."""
    global CHORD_MODEL
    if CHORD_MODEL is None:
        print("[CHORD SERVER] Loading Chord PBR Model...")
        t0 = time.time()
        config_path = REPO_PATH / "config" / "chord.yaml"
        if not config_path.exists():
            raise FileNotFoundError(f"Chord config not found: {config_path}")

        config = OmegaConf.load(str(config_path))
        model = ChordModel(config)

        model_path = Path(os.environ.get("CHORD_MODEL_PATH", str(REPO_PATH / "model" / "chord_v1.safetensors")))
        if not model_path.exists():
            raise FileNotFoundError(f"Chord checkpoint not found at: {model_path}")

        print(f"[CHORD SERVER] Loading checkpoint: {model_path}")
        state_dict = load_torch_file(str(model_path))
        model.load_state_dict(state_dict)
        model.eval()
        model.to(DEVICE)
        CHORD_MODEL = model
        print(f"[CHORD SERVER] Chord Model loaded in {round(time.time() - t0, 2)}s.")
    return CHORD_MODEL


def get_sd_pipeline():
    """Loads and caches Stable Diffusion pipeline for text-to-texture generation."""
    global SD_PIPELINE
    if SD_PIPELINE is None:
        print("[CHORD SERVER] Initializing Stable Diffusion pipeline...")
        t0 = time.time()
        from diffusers import StableDiffusionPipeline, DPMSolverMultistepScheduler

        candidate_ids = [
            "Manojb/stable-diffusion-2-1-base",
            "ckpt/stable-diffusion-2-1-base",
        ]
        pipe = None
        last_err = None
        for mid in candidate_ids:
            try:
                print(f"[CHORD SERVER] Loading SD pipeline from {mid}...")
                pipe = StableDiffusionPipeline.from_pretrained(
                    mid,
                    torch_dtype=torch.float16 if DEVICE == "cuda" else torch.float32,
                    safety_checker=None
                )
                print(f"[CHORD SERVER] Successfully loaded SD from {mid}")
                break
            except Exception as e:
                print(f"[CHORD SERVER] Could not load from {mid}: {e}")
                last_err = e

        if pipe is None:
            raise RuntimeError(f"Failed to load Stable Diffusion pipeline from candidate mirrors: {last_err}")

        pipe.scheduler = DPMSolverMultistepScheduler.from_config(pipe.scheduler.config)
        pipe = pipe.to(DEVICE)
        try:
            pipe.enable_attention_slicing()
        except Exception:
            pass
        SD_PIPELINE = pipe
        print(f"[CHORD SERVER] SD Pipeline loaded in {round(time.time() - t0, 2)}s.")
    return SD_PIPELINE


def set_seamless(pipe, seamless: bool):
    """Enable or disable circular padding for seamless tileable texture generation."""
    mode = 'circular' if seamless else 'zeros'
    try:
        for name, module in pipe.unet.named_modules():
            if isinstance(module, torch.nn.Conv2d):
                module.padding_mode = mode
        for name, module in pipe.vae.named_modules():
            if isinstance(module, torch.nn.Conv2d):
                module.padding_mode = mode
    except Exception as e:
        print(f"[CHORD SERVER] Warning setting seamless padding: {e}")


class ThreadedHTTPServer(ThreadingMixIn, HTTPServer):
    daemon_threads = True
    allow_reuse_address = True


class ChordRequestHandler(BaseHTTPRequestHandler):
    def log_message(self, format, *args):
        # Suppress routine health check log spam
        if args and any("health" in str(a) or "progress" in str(a) for a in args):
            return
        super().log_message(format, *args)

    def _send_json(self, status_code: int, data: dict):
        response_bytes = json.dumps(data).encode("utf-8")
        self.send_response(status_code)
        self.send_header("Content-Type", "application/json")
        self.send_header("Content-Length", str(len(response_bytes)))
        self.send_header("Access-Control-Allow-Origin", "*")
        self.send_header("Access-Control-Allow-Methods", "GET, POST, OPTIONS")
        self.send_header("Access-Control-Allow-Headers", "Content-Type")
        self.end_headers()
        self.wfile.write(response_bytes)

    def do_OPTIONS(self):
        self.send_response(200)
        self.send_header("Access-Control-Allow-Origin", "*")
        self.send_header("Access-Control-Allow-Methods", "GET, POST, OPTIONS")
        self.send_header("Access-Control-Allow-Headers", "Content-Type")
        self.end_headers()

    def do_GET(self):
        path = self.path.split("?")[0].rstrip("/")

        if path in ("", "/health"):
            vram_mb = 0.0
            if DEVICE == "cuda":
                vram_mb = round(torch.cuda.memory_allocated() / (1024 * 1024), 1)
            self._send_json(200, {
                "online": True,
                "status": "Online",
                "device": DEVICE,
                "model": "Chord-v1",
                "vram_mb": vram_mb,
                "chord_loaded": CHORD_MODEL is not None,
                "sd_loaded": SD_PIPELINE is not None
            })

        elif path == "/progress":
            self._send_json(200, PROGRESS_STATE)

        elif path == "/shutdown":
            self._send_json(200, {"success": True, "message": "Server shutting down..."})
            def _stop():
                time.sleep(0.5)
                os._exit(0)
            threading.Thread(target=_stop, daemon=True).start()

        else:
            self._send_json(404, {"error": f"Endpoint not found: {path}"})

    def do_POST(self):
        path = self.path.split("?")[0].rstrip("/")

        if path == "/cancel":
            CANCEL_EVENT.set()
            PROGRESS_STATE["cancelled"] = True
            PROGRESS_STATE["message"] = "Cancelling generation..."
            self._send_json(200, {"success": True, "message": "Cancellation requested."})

        elif path == "/generate":
            content_length = int(self.headers.get("Content-Length", 0))
            body_bytes = self.rfile.read(content_length)
            try:
                params = json.loads(body_bytes.decode("utf-8"))
            except Exception as e:
                self._send_json(400, {"error": f"Invalid JSON body: {e}"})
                return

            try:
                result = self._process_generation(params)
                self._send_json(200, result)
            except Exception as ex:
                import traceback
                traceback.print_exc()
                PROGRESS_STATE["status"] = "error"
                PROGRESS_STATE["message"] = f"Error: {ex}"
                self._send_json(500, {"error": str(ex)})

        else:
            self._send_json(404, {"error": f"Endpoint not found: {path}"})

    def _process_generation(self, params: dict) -> dict:
        CANCEL_EVENT.clear()
        mode = params.get("mode", "PROMPT")  # PROMPT or IMAGE
        prompt = params.get("prompt", "medieval cobblestone texture, realistic")
        negative_prompt = params.get("negative_prompt", "blurry, low quality, artifacts, specular reflection")
        image_path = params.get("image_path", "")
        seamless = params.get("seamless", True)
        seed = int(params.get("seed", -1))
        steps = int(params.get("steps", 25))
        guidance_scale = float(params.get("guidance_scale", 7.5))
        res = int(params.get("resolution", 1024))

        if seed == -1:
            seed = random.randint(0, 2147483647)

        # Prepare output directory
        out_base = Path(params.get("output_dir", ""))
        if not out_base or not out_base.exists():
            out_base = Path(CURRENT_DIR) / "outputs"
        timestamp = time.strftime("%Y%m%d_%H%M%S")
        run_dir = out_base / f"chord_{timestamp}_{seed}"
        run_dir.mkdir(parents=True, exist_ok=True)

        t_start = time.time()
        PROGRESS_STATE["status"] = "generating"
        PROGRESS_STATE["cancelled"] = False
        PROGRESS_STATE["step"] = 0
        PROGRESS_STATE["total_steps"] = steps + 5
        PROGRESS_STATE["percent"] = 5.0
        PROGRESS_STATE["message"] = "Initializing generation pipeline..."

        beauty_image = None

        if mode == "IMAGE":
            # Direct Image Decomposition Mode
            PROGRESS_STATE["message"] = "Loading source image..."
            if not image_path or not os.path.exists(image_path):
                raise FileNotFoundError(f"Input image not found: {image_path}")
            raw_tensor = read_image(image_path).to(DEVICE)
            beauty_image = raw_tensor
            PROGRESS_STATE["percent"] = 40.0

        else:
            # Text-to-PBR Mode
            pipe = get_sd_pipeline()
            set_seamless(pipe, seamless)

            PROGRESS_STATE["message"] = f"Diffusion sampling: 0/{steps} steps..."

            def _step_callback(step: int, timestep: int, latents: torch.FloatTensor):
                if CANCEL_EVENT.is_set():
                    raise InterruptedError("Generation cancelled by user.")
                pct = 5.0 + (step / max(1, steps)) * 60.0
                PROGRESS_STATE["step"] = step
                PROGRESS_STATE["percent"] = round(pct, 1)
                PROGRESS_STATE["message"] = f"Diffusion sampling: {step}/{steps} ({int(pct)}%)"

            generator = torch.Generator(device=DEVICE).manual_seed(seed)
            enhanced_prompt = f"{prompt}, pbr texture map, texture surface, flat diffuse lighting"

            output = pipe(
                prompt=enhanced_prompt,
                negative_prompt=negative_prompt,
                height=res,
                width=res,
                num_inference_steps=steps,
                guidance_scale=guidance_scale,
                generator=generator,
                callback=_step_callback,
                callback_steps=1
            )
            pil_img = output.images[0]
            # Convert to float tensor CxHxW [0, 1]
            to_tensor = v2.Compose([v2.ToImage(), v2.ToDtype(torch.float32, scale=True)])
            beauty_image = to_tensor(pil_img).to(DEVICE)
            PROGRESS_STATE["percent"] = 68.0

        if CANCEL_EVENT.is_set():
            raise InterruptedError("Generation cancelled by user.")

        # Save preview / beauty image
        preview_path = run_dir / "preview.png"
        img_pil = create_img(beauty_image)
        img_pil.save(str(preview_path))

        # Run Chord Decomposition
        PROGRESS_STATE["message"] = "Decomposing SVBRDF material channels with Chord AI..."
        PROGRESS_STATE["percent"] = 72.0

        chord_model = get_chord_model()

        # Resize to 1024x1024 for Chord model forward pass
        ori_h, ori_w = beauty_image.shape[-2:]
        x = v2.Resize(size=(1024, 1024), antialias=True)(beauty_image).unsqueeze(0)

        with torch.no_grad():
            if DEVICE == "cuda":
                with torch.autocast(device_type="cuda"):
                    chord_out = chord_model(x)
            else:
                chord_out = chord_model(x)

        if CANCEL_EVENT.is_set():
            raise InterruptedError("Generation cancelled by user.")

        PROGRESS_STATE["message"] = "Saving PBR maps..."
        PROGRESS_STATE["percent"] = 90.0

        # Resize maps back to target resolution if needed
        resize_back = v2.Resize(size=(ori_h, ori_w), antialias=True)
        maps_to_save = {}
        for k in chord_out.keys():
            maps_to_save[k] = resize_back(chord_out[k])

        run_dir = run_dir.resolve()
        save_maps(str(run_dir), maps_to_save)

        basecolor_file = (run_dir / "basecolor.png").resolve()
        normal_file = (run_dir / "normal.png").resolve()
        roughness_file = (run_dir / "roughness.png").resolve()
        metalness_file = (run_dir / "metalness.png").resolve()
        preview_path = (run_dir / "preview.png").resolve()

        elapsed = round(time.time() - t_start, 2)
        PROGRESS_STATE["status"] = "idle"
        PROGRESS_STATE["percent"] = 100.0
        PROGRESS_STATE["message"] = f"Complete in {elapsed}s"

        return {
            "success": True,
            "output_dir": str(run_dir),
            "basecolor": str(basecolor_file),
            "normal": str(normal_file),
            "roughness": str(roughness_file),
            "metalness": str(metalness_file),
            "preview": str(preview_path),
            "seed": seed,
            "elapsed": elapsed
        }


def run_server(port: int = 8188):
    global SERVER_INSTANCE
    host = "127.0.0.1"
    server_address = (host, port)
    SERVER_INSTANCE = ThreadedHTTPServer(server_address, ChordRequestHandler)
    print(f"==================================================================")
    print(f"  CHORD PBR AI RESIDENT SERVER RUNNING ON http://{host}:{port}    ")
    print(f"  CUDA Device: {DEVICE}                                           ")
    print(f"==================================================================")
    try:
        SERVER_INSTANCE.serve_forever()
    except KeyboardInterrupt:
        print("\n[CHORD SERVER] Stopping...")
    finally:
        SERVER_INSTANCE.server_close()


if __name__ == "__main__":
    port_arg = 8188
    if len(sys.argv) > 1:
        try:
            port_arg = int(sys.argv[1])
        except ValueError:
            pass
    run_server(port_arg)
