# -*- coding: utf-8 -*-
"""
Server management operators for Chord for Blender.
"""

import os
import subprocess
import bpy
from . import server_manager


class CHORD_OT_CheckServerStatus(bpy.types.Operator):
    bl_idname = "chord.check_server_status"
    bl_label = "Check Status"
    bl_description = "Check if the Chord AI server is reachable"
    bl_options = {'INTERNAL'}

    def execute(self, context):
        scene = context.scene
        url = scene.chord_server_url.strip() or f"http://127.0.0.1:{scene.chord_server_port}"
        health = server_manager.check_server_health(url, timeout=1.0)
        if health["online"]:
            device_str = health.get("device", "cuda")
            scene.chord_server_status = f"Online ({device_str})"
            scene.chord_server_device = str(device_str)
            scene.chord_server_model = str(health.get("model", "Chord-v1"))
            self.report({'INFO'}, f"Server is online ({device_str})")
        else:
            scene.chord_server_status = "Offline"
            scene.chord_server_device = ""
            self.report({'WARNING'}, "Server is offline")
        return {'FINISHED'}


class CHORD_OT_StartLocalServer(bpy.types.Operator):
    bl_idname = "chord.start_server"
    bl_label = "Start Local Server"
    bl_description = "Launch the resident Chord AI server in background"
    bl_options = {'INTERNAL'}

    def execute(self, context):
        scene = context.scene
        port = scene.chord_server_port
        repo_path = scene.chord_repo_path
        model_path = scene.chord_model_path

        success, msg = server_manager.start_local_server(
            port=port,
            repo_path=repo_path,
            model_path=model_path
        )
        if success:
            scene.chord_server_status = "Starting..."
            self.report({'INFO'}, msg)

            # Auto-poll health every 1.5s until online (up to 20 attempts)
            attempts = [0]
            def _poll():
                attempts[0] += 1
                h = server_manager.check_server_health(f"http://127.0.0.1:{port}", timeout=0.8)
                if h["online"]:
                    dev = h.get("device", "cuda")
                    scene.chord_server_status = f"Online ({dev})"
                    scene.chord_server_device = dev
                    return None
                if attempts[0] > 25:
                    if scene.chord_server_status == "Starting...":
                        scene.chord_server_status = "Offline"
                    return None
                return 1.5
            bpy.app.timers.register(_poll, first_interval=1.5)
            return {'FINISHED'}
        else:
            self.report({'ERROR'}, msg)
            return {'CANCELLED'}


class CHORD_OT_StopLocalServer(bpy.types.Operator):
    bl_idname = "chord.stop_server"
    bl_label = "Stop Local Server"
    bl_description = "Gracefully shutdown the resident Chord AI server"
    bl_options = {'INTERNAL'}

    def execute(self, context):
        scene = context.scene
        port = scene.chord_server_port
        success, msg = server_manager.stop_local_server(port=port)
        scene.chord_server_status = "Offline"
        scene.chord_server_device = ""
        if success:
            self.report({'INFO'}, msg)
            return {'FINISHED'}
        else:
            self.report({'WARNING'}, msg)
            return {'FINISHED'}


class CHORD_OT_InstallLocalServer(bpy.types.Operator):
    bl_idname = "chord.install_server"
    bl_label = "Install Local Server"
    bl_description = "Open standalone installer console to setup Python environment and PyTorch CUDA"
    bl_options = {'INTERNAL'}

    def execute(self, context):
        scene = context.scene
        launched = server_manager.launch_installer(
            repo_path=scene.chord_repo_path,
            model_path=scene.chord_model_path
        )
        if launched:
            self.report({'INFO'}, "Installer console opened. Follow the instructions in the window.")
            return {'FINISHED'}
        else:
            self.report({'ERROR'}, "Failed to launch installer script.")
            return {'CANCELLED'}


class CHORD_OT_UninstallLocalServer(bpy.types.Operator):
    bl_idname = "chord.uninstall_server"
    bl_label = "Uninstall Local Server"
    bl_description = "Remove local server environment and delete files"
    bl_options = {'INTERNAL'}

    def invoke(self, context, event):
        return context.window_manager.invoke_confirm(self, event)

    def execute(self, context):
        scene = context.scene
        success, msg = server_manager.uninstall_localserv(port=scene.chord_server_port)
        scene.chord_server_status = "Offline"
        if success:
            self.report({'INFO'}, msg)
            return {'FINISHED'}
        else:
            self.report({'ERROR'}, msg)
            return {'CANCELLED'}


class CHORD_OT_OpenLocalServerFolder(bpy.types.Operator):
    bl_idname = "chord.open_server_folder"
    bl_label = "Open Server Folder"
    bl_description = "Open local server directory in Windows Explorer"
    bl_options = {'INTERNAL'}

    def execute(self, context):
        path = server_manager.get_default_localserv_path()
        path.mkdir(parents=True, exist_ok=True)
        try:
            os.startfile(str(path))
            return {'FINISHED'}
        except Exception as e:
            self.report({'ERROR'}, f"Cannot open folder: {e}")
            return {'CANCELLED'}


class CHORD_OT_ToggleBlenderConsole(bpy.types.Operator):
    bl_idname = "chord.toggle_console"
    bl_label = "Toggle System Console"
    bl_description = "Show or hide Blender Windows System Console"
    bl_options = {'INTERNAL'}

    def execute(self, context):
        try:
            bpy.ops.wm.console_toggle()
            return {'FINISHED'}
        except Exception:
            return {'CANCELLED'}
