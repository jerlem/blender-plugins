# -*- coding: utf-8 -*-
"""
Texture Generation & Material Assignment operators for Chord for Blender.
"""

import os
import shutil
import json
import time
import random
import threading
import urllib.request
import urllib.error
from pathlib import Path
import bpy
from . import material_manager
from . import server_manager


class CHORD_OT_PickTargetMesh(bpy.types.Operator):
    bl_idname = "chord.pick_target_mesh"
    bl_label = "Use Selected Mesh"
    bl_description = "Set the active 3D viewport mesh as the target for texture generation"
    bl_options = {'INTERNAL'}

    def execute(self, context):
        obj = context.active_object
        if obj and obj.type == 'MESH':
            context.scene.chord_target_mesh = obj
            self.report({'INFO'}, f"Target mesh set to '{obj.name}'")
        else:
            self.report({'WARNING'}, "Please select a Mesh object in the 3D Viewport")
        return {'FINISHED'}


class CHORD_OT_RandomizeSeed(bpy.types.Operator):
    bl_idname = "chord.randomize_seed"
    bl_label = "Randomize Seed"
    bl_description = "Set a random seed for the next generation"
    bl_options = {'INTERNAL'}

    def execute(self, context):
        context.scene.chord_seed = random.randint(0, 2147483647)
        return {'FINISHED'}


class CHORD_OT_CancelGeneration(bpy.types.Operator):
    bl_idname = "chord.cancel_generation"
    bl_label = "Cancel"
    bl_description = "Abort current texture generation"
    bl_options = {'INTERNAL'}

    def execute(self, context):
        scene = context.scene
        scene.chord_cancel_requested = True
        scene.chord_status_message = "Cancelling..."
        url = scene.chord_server_url.strip() or f"http://127.0.0.1:{scene.chord_server_port}"
        req = urllib.request.Request(f"{url.rstrip('/')}/cancel", data=b"", headers={'User-Agent': 'Blender-Chord'})
        try:
            urllib.request.urlopen(req, timeout=1.0)
        except Exception:
            pass
        self.report({'INFO'}, "Cancel signal sent to server")
        return {'FINISHED'}


class CHORD_OT_ForceResetGeneration(bpy.types.Operator):
    bl_idname = "chord.force_reset_generation"
    bl_label = "Unlock"
    bl_description = "Force unlock the interface if generation was interrupted"
    bl_options = {'INTERNAL'}

    def execute(self, context):
        scene = context.scene
        scene.chord_is_generating = False
        scene.chord_cancel_requested = False
        scene.chord_generation_progress = 0.0
        scene.chord_status_message = "Ready"
        self.report({'INFO'}, "Interface unlocked")
        return {'FINISHED'}


class CHORD_OT_OpenOutputFolder(bpy.types.Operator):
    bl_idname = "chord.open_output_folder"
    bl_label = "Open Folder"
    bl_description = "Open the folder containing the generated PBR texture maps"
    bl_options = {'INTERNAL'}

    def execute(self, context):
        out_dir = context.scene.chord_last_output_dir
        if out_dir and os.path.exists(out_dir):
            try:
                os.startfile(out_dir)
                return {'FINISHED'}
            except Exception as e:
                self.report({'ERROR'}, f"Failed to open folder: {e}")
                return {'CANCELLED'}
        else:
            self.report({'WARNING'}, "No output directory recorded yet")
            return {'CANCELLED'}


class CHORD_OT_ApplyMaterial(bpy.types.Operator):
    bl_idname = "chord.apply_material"
    bl_label = "Re-Apply Material"
    bl_description = "Apply the last generated PBR maps to the selected mesh with current settings"
    bl_options = {'REGISTER', 'UNDO'}

    def execute(self, context):
        scene = context.scene
        target_obj = scene.chord_target_mesh or context.active_object
        if not target_obj or target_obj.type != 'MESH':
            self.report({'ERROR'}, "Please select a target Mesh object")
            return {'CANCELLED'}

        if not scene.chord_last_basecolor or not os.path.exists(scene.chord_last_basecolor):
            self.report({'WARNING'}, "No generated PBR maps found. Please generate a texture first.")
            return {'CANCELLED'}

        try:
            material_manager.apply_pbr_material(
                obj=target_obj,
                basecolor_path=scene.chord_last_basecolor,
                normal_path=scene.chord_last_normal,
                roughness_path=scene.chord_last_roughness,
                metalness_path=scene.chord_last_metalness,
                material_name=scene.chord_material_name,
                uv_tiling=scene.chord_uv_tiling,
                normal_strength=scene.chord_normal_strength,
                roughness_scale=scene.chord_roughness_scale,
                metallic_scale=scene.chord_metallic_scale,
                auto_unwrap=scene.chord_auto_unwrap
            )
            self.report({'INFO'}, f"Applied PBR Material to '{target_obj.name}'")
            return {'FINISHED'}
        except Exception as e:
            self.report({'ERROR'}, f"Failed to apply material: {e}")
            return {'CANCELLED'}


class CHORD_OT_GenerateTexture(bpy.types.Operator):
    bl_idname = "chord.generate_texture"
    bl_label = "Generate PBR Material"
    bl_description = "Generate AI texture from prompt/image and decompose into PBR channels with Chord"
    bl_options = {'INTERNAL'}

    _timer = None
    _thread = None
    _result = None
    _error = None
    _finished = False

    def invoke(self, context, event):
        scene = context.scene
        url = scene.chord_server_url.strip() or f"http://127.0.0.1:{scene.chord_server_port}"

        # 1. Quick check server health
        health = server_manager.check_server_health(url, timeout=1.0)
        if not health["online"]:
            self.report({'ERROR'}, "Chord Server is offline. Please start the server first in the Settings tab.")
            return {'CANCELLED'}

        # 2. Check target mesh
        target_obj = scene.chord_target_mesh or context.active_object
        if target_obj and target_obj.type == 'MESH':
            scene.chord_target_mesh = target_obj

        # 3. Check parameters
        if scene.chord_generation_mode == 'PROMPT' and not scene.chord_prompt.strip():
            self.report({'ERROR'}, "Please enter a descriptive prompt.")
            return {'CANCELLED'}
        if scene.chord_generation_mode == 'IMAGE' and not scene.chord_input_image_path.strip():
            self.report({'ERROR'}, "Please select a source image file.")
            return {'CANCELLED'}

        # 4. Prepare payload
        payload = {
            "mode": scene.chord_generation_mode,
            "prompt": scene.chord_prompt.strip(),
            "negative_prompt": scene.chord_negative_prompt.strip(),
            "image_path": scene.chord_input_image_path.strip(),
            "seamless": scene.chord_seamless,
            "seed": scene.chord_seed,
            "steps": scene.chord_steps,
            "guidance_scale": scene.chord_guidance_scale,
            "resolution": int(scene.chord_resolution),
        }

        # 5. Initialize generation state
        scene.chord_is_generating = True
        scene.chord_cancel_requested = False
        scene.chord_generation_progress = 0.0
        scene.chord_status_message = "Contacting Chord AI Server..."

        self._result = None
        self._error = None
        self._finished = False

        # 6. Launch worker thread
        def _worker():
            try:
                gen_url = f"{url.rstrip('/')}/generate"
                req_data = json.dumps(payload).encode('utf-8')
                req = urllib.request.Request(
                    gen_url,
                    data=req_data,
                    headers={'Content-Type': 'application/json', 'User-Agent': 'Blender-Chord'}
                )
                with urllib.request.urlopen(req, timeout=300.0) as resp:
                    resp_body = resp.read().decode('utf-8')
                    data = json.loads(resp_body)
                    self._result = data
            except Exception as e:
                self._error = str(e)
            finally:
                self._finished = True

        self._thread = threading.Thread(target=_worker, daemon=True)
        self._thread.start()

        # 7. Start modal timer (polls every 0.25s)
        wm = context.window_manager
        self._timer = wm.event_timer_add(0.25, window=context.window)
        wm.modal_handler_add(self)
        return {'RUNNING_MODAL'}

    def modal(self, context, event):
        scene = context.scene

        if event.type == 'TIMER':
            # Poll progress from server
            url = scene.chord_server_url.strip() or f"http://127.0.0.1:{scene.chord_server_port}"
            try:
                prog_req = urllib.request.Request(f"{url.rstrip('/')}/progress", headers={'User-Agent': 'Blender-Chord'})
                with urllib.request.urlopen(prog_req, timeout=0.5) as r:
                    p_data = json.loads(r.read().decode('utf-8'))
                    scene.chord_generation_progress = float(p_data.get("percent", 0.0))
                    msg = p_data.get("message", "")
                    if msg:
                        scene.chord_status_message = msg
            except Exception:
                pass

            # Force redraw of sidebar panel
            for area in context.screen.areas:
                if area.type == 'VIEW_3D':
                    area.tag_redraw()

            # Check if thread finished
            if self._finished:
                self._cleanup(context)
                if self._error:
                    scene.chord_status_message = f"Error: {self._error}"
                    self.report({'ERROR'}, f"Generation failed: {self._error}")
                    return {'CANCELLED'}

                if self._result and self._result.get("success"):
                    res = self._result
                    scene.chord_last_output_dir = res.get("output_dir", "")
                    scene.chord_last_basecolor = res.get("basecolor", "")
                    scene.chord_last_normal = res.get("normal", "")
                    scene.chord_last_roughness = res.get("roughness", "")
                    scene.chord_last_metalness = res.get("metalness", "")
                    scene.chord_last_preview = res.get("preview", "")

                    elapsed = res.get("elapsed", 0.0)
                    scene.chord_status_message = f"Done in {elapsed}s"

                    # Automatically apply material to target mesh
                    target_obj = scene.chord_target_mesh
                    if not target_obj or target_obj.type != 'MESH':
                        target_obj = context.active_object
                    if not target_obj or target_obj.type != 'MESH':
                        for o in context.selected_objects:
                            if o.type == 'MESH':
                                target_obj = o
                                break
                    if not target_obj or target_obj.type != 'MESH':
                        for o in context.scene.objects:
                            if o.type == 'MESH':
                                target_obj = o
                                break

                    if target_obj and target_obj.type == 'MESH':
                        scene.chord_target_mesh = target_obj
                        try:
                            material_manager.apply_pbr_material(
                                obj=target_obj,
                                basecolor_path=scene.chord_last_basecolor,
                                normal_path=scene.chord_last_normal,
                                roughness_path=scene.chord_last_roughness,
                                metalness_path=scene.chord_last_metalness,
                                material_name=scene.chord_material_name,
                                uv_tiling=scene.chord_uv_tiling,
                                normal_strength=scene.chord_normal_strength,
                                roughness_scale=scene.chord_roughness_scale,
                                metallic_scale=scene.chord_metallic_scale,
                                auto_unwrap=scene.chord_auto_unwrap
                            )
                            self.report({'INFO'}, f"PBR Material generated and applied to '{target_obj.name}' in {elapsed}s!")
                        except Exception as me:
                            print(f"[CHORD] Material assignment error: {me}")
                            self.report({'WARNING'}, f"Texture generated, but material assignment failed: {me}")
                    else:
                        self.report({'INFO'}, f"PBR Texture maps generated in {elapsed}s (No mesh selected to apply).")

                    # Refresh history list
                    try:
                        refresh_history_collection(scene)
                    except Exception:
                        pass

                    return {'FINISHED'}
                else:
                    err_msg = self._result.get("error", "Unknown server error") if self._result else "No result returned"
                    scene.chord_status_message = f"Failed: {err_msg}"
                    self.report({'ERROR'}, err_msg)
                    return {'CANCELLED'}

        return {'PASS_THROUGH'}

    def _cleanup(self, context):
        scene = context.scene
        scene.chord_is_generating = False
        scene.chord_cancel_requested = False
        if self._timer:
            context.window_manager.event_timer_remove(self._timer)
            self._timer = None


def refresh_history_collection(scene):
    """Scans for generated texture directories and populates the scene history list."""
    if not hasattr(scene, "chord_history_list"):
        return

    addon_dir = Path(__file__).parent.resolve()
    candidate_roots = [
        addon_dir.parent / "chord_localserv",
        addon_dir.parent / "chord_localserv" / "outputs",
        addon_dir / "server" / "outputs",
    ]
    if hasattr(scene, "chord_last_output_dir") and scene.chord_last_output_dir:
        candidate_roots.append(Path(scene.chord_last_output_dir).parent)

    found_dirs = {}
    for root in candidate_roots:
        if root.exists() and root.is_dir():
            for entry in root.iterdir():
                if entry.is_dir() and (entry.name.startswith("chord_") or (entry / "basecolor.png").exists()):
                    bc = entry / "basecolor.png"
                    if bc.exists():
                        try:
                            mtime = entry.stat().st_mtime
                        except Exception:
                            mtime = 0.0
                        found_dirs[str(entry.resolve())] = (mtime, entry)

    sorted_dirs = sorted(found_dirs.values(), key=lambda x: x[0], reverse=True)

    scene.chord_history_list.clear()

    # Get preview collection for icons
    pcoll = None
    try:
        from . import ui_panels
        pcoll = ui_panels.get_history_preview_collection()
    except Exception:
        pass

    for mtime, dir_path in sorted_dirs:
        item = scene.chord_history_list.add()
        item.name = dir_path.name
        item.dir_path = str(dir_path.resolve())
        date_str = time.strftime("%Y-%m-%d %H:%M", time.localtime(mtime)) if mtime > 0 else "Unknown"
        item.date = date_str

        bc = dir_path / "basecolor.png"
        nm = dir_path / "normal.png"
        ro = dir_path / "roughness.png"
        mt = dir_path / "metalness.png"
        pv = dir_path / "preview.png"

        item.basecolor_path = str(bc.resolve()) if bc.exists() else ""
        item.normal_path = str(nm.resolve()) if nm.exists() else ""
        item.roughness_path = str(ro.resolve()) if ro.exists() else ""
        item.metalness_path = str(mt.resolve()) if mt.exists() else ""
        item.preview_path = str(pv.resolve()) if pv.exists() else item.basecolor_path
        item.has_preview = bool(item.preview_path and os.path.exists(item.preview_path))

        # Register thumbnail icon in preview collection
        if pcoll and item.has_preview and item.name not in pcoll:
            try:
                pcoll.load(item.name, item.preview_path, 'IMAGE')
            except Exception:
                pass

    if len(scene.chord_history_list) > 0:
        if scene.chord_history_index >= len(scene.chord_history_list):
            scene.chord_history_index = 0


class CHORD_OT_RefreshHistory(bpy.types.Operator):
    bl_idname = "chord.refresh_history"
    bl_label = "Refresh History"
    bl_description = "Scan disk for generated PBR texture sets"
    bl_options = {'INTERNAL'}

    def execute(self, context):
        refresh_history_collection(context.scene)
        self.report({'INFO'}, f"Found {len(context.scene.chord_history_list)} generated textures in history.")
        return {'FINISHED'}


class CHORD_OT_ApplyHistoryItem(bpy.types.Operator):
    bl_idname = "chord.apply_history_item"
    bl_label = "Apply to Mesh"
    bl_description = "Apply the selected historical PBR texture to the target mesh"
    bl_options = {'REGISTER', 'UNDO'}

    target_index: bpy.props.IntProperty(default=-1)

    def execute(self, context):
        scene = context.scene
        idx = self.target_index if self.target_index >= 0 else scene.chord_history_index
        if not scene.chord_history_list or idx < 0 or idx >= len(scene.chord_history_list):
            self.report({'WARNING'}, "No history item selected")
            return {'CANCELLED'}

        item = scene.chord_history_list[idx]
        target_obj = scene.chord_target_mesh
        if not target_obj or target_obj.type != 'MESH':
            target_obj = context.active_object
        if not target_obj or target_obj.type != 'MESH':
            for o in context.selected_objects:
                if o.type == 'MESH':
                    target_obj = o
                    break
        if not target_obj or target_obj.type != 'MESH':
            for o in context.scene.objects:
                if o.type == 'MESH':
                    target_obj = o
                    break

        if not target_obj or target_obj.type != 'MESH':
            self.report({'ERROR'}, "Please select a target Mesh object in the 3D Viewport")
            return {'CANCELLED'}

        scene.chord_target_mesh = target_obj

        try:
            material_manager.apply_pbr_material(
                obj=target_obj,
                basecolor_path=item.basecolor_path,
                normal_path=item.normal_path,
                roughness_path=item.roughness_path,
                metalness_path=item.metalness_path,
                material_name=scene.chord_material_name,
                uv_tiling=scene.chord_uv_tiling,
                normal_strength=scene.chord_normal_strength,
                roughness_scale=scene.chord_roughness_scale,
                metallic_scale=scene.chord_metallic_scale,
                auto_unwrap=scene.chord_auto_unwrap
            )
            # Sync last output properties
            scene.chord_last_output_dir = item.dir_path
            scene.chord_last_basecolor = item.basecolor_path
            scene.chord_last_normal = item.normal_path
            scene.chord_last_roughness = item.roughness_path
            scene.chord_last_metalness = item.metalness_path
            scene.chord_last_preview = item.preview_path

            self.report({'INFO'}, f"Applied texture '{item.name}' to '{target_obj.name}'")
            return {'FINISHED'}
        except Exception as e:
            self.report({'ERROR'}, f"Failed to apply material: {e}")
            return {'CANCELLED'}


class CHORD_OT_DeleteHistoryItem(bpy.types.Operator):
    bl_idname = "chord.delete_history_item"
    bl_label = "Delete Texture"
    bl_description = "Delete this generated texture folder from disk"
    bl_options = {'INTERNAL'}

    def invoke(self, context, event):
        return context.window_manager.invoke_confirm(self, event)

    def execute(self, context):
        scene = context.scene
        idx = scene.chord_history_index
        if not scene.chord_history_list or idx < 0 or idx >= len(scene.chord_history_list):
            return {'CANCELLED'}

        item = scene.chord_history_list[idx]
        dir_to_remove = item.dir_path
        if dir_to_remove and os.path.exists(dir_to_remove):
            try:
                shutil.rmtree(dir_to_remove)
            except Exception as e:
                self.report({'ERROR'}, f"Could not remove folder: {e}")
                return {'CANCELLED'}

        refresh_history_collection(scene)
        self.report({'INFO'}, f"Deleted '{item.name}' from history")
        return {'FINISHED'}
