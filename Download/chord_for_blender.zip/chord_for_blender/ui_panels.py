# -*- coding: utf-8 -*-
"""
UI Panels for Chord for Blender in 3D Viewport N-Panel.
Designed following the Quasi-Modo UI paradigm:
- Top icon navigation bar with direct tab switching
- Persistent resident server control & live health feedback
- Dynamic progress banner with cancel/unlock capabilities
- Rich PBR material parameter controls & map previews
"""

import os
from pathlib import Path
import bpy
import bpy.utils.previews
from . import server_manager

PREVIEW_COLLECTIONS = {}


def get_preview_collection():
    if "main" not in PREVIEW_COLLECTIONS:
        try:
            pcoll = bpy.utils.previews.new()
            assets_dir = os.path.join(os.path.dirname(__file__), "assets")
            for b_name in ("banner.png", "banner.jpg"):
                banner_path = os.path.join(assets_dir, b_name)
                if os.path.exists(banner_path):
                    pcoll.load("banner", banner_path, 'IMAGE')
                    break
            PREVIEW_COLLECTIONS["main"] = pcoll
        except Exception:
            return None
    return PREVIEW_COLLECTIONS.get("main")


def get_history_preview_collection():
    if "history" not in PREVIEW_COLLECTIONS:
        try:
            PREVIEW_COLLECTIONS["history"] = bpy.utils.previews.new()
        except Exception:
            return None
    return PREVIEW_COLLECTIONS.get("history")


def clear_preview_collections():
    for pcoll in list(PREVIEW_COLLECTIONS.values()):
        try:
            bpy.utils.previews.remove(pcoll)
        except Exception:
            pass
    PREVIEW_COLLECTIONS.clear()


class CHORD_OT_SwitchTab(bpy.types.Operator):
    bl_idname = "chord.switch_tab"
    bl_label = "Switch Tab"
    bl_description = "Switch to selected tab"
    bl_options = {'INTERNAL'}

    target_tab: bpy.props.StringProperty()

    def execute(self, context):
        context.scene.chord_active_tab = self.target_tab
        if self.target_tab == 'HISTORY':
            try:
                from . import operators_texture
                operators_texture.refresh_history_collection(context.scene)
            except Exception:
                pass
        return {'FINISHED'}


class CHORD_UL_HistoryList(bpy.types.UIList):
    """Custom UIList for generated PBR textures in history."""

    def draw_item(self, context, layout, data, item, icon, active_data, active_propname, index):
        pcoll = get_history_preview_collection()
        icon_val = pcoll[item.name].icon_id if (pcoll and item.name in pcoll) else 0

        if self.layout_type in {'DEFAULT', 'COMPACT'}:
            row = layout.row(align=True)
            if icon_val:
                row.label(text="", icon_value=icon_val)
            else:
                row.label(text="", icon='IMAGE_DATA')
            row.label(text=item.name)
            sub = row.row(align=True)
            sub.alignment = 'RIGHT'
            sub.label(text=item.date)
        elif self.layout_type == 'GRID':
            layout.alignment = 'CENTER'
            if icon_val:
                layout.label(text="", icon_value=icon_val)
            else:
                layout.label(text=item.name)


class CHORD_OT_About(bpy.types.Operator):
    """About Chord for Blender, Developer Info & Academic Citations"""
    bl_idname = "chord.about"
    bl_label = "About Chord for Blender"
    bl_description = "Show developer info & academic citation"
    bl_options = {'INTERNAL'}

    def invoke(self, context, event):
        return context.window_manager.invoke_props_dialog(self, width=420)

    def draw(self, context):
        layout = self.layout

        box_about = layout.box()
        col_m = box_about.column(align=True)
        col_m.label(text="Chord for Blender - PBR Material Studio", icon='MATERIAL')
        col_m.label(text="Blender Integration: Jérôme Lemarchand")
        col_m.label(text="Contact: goblingames.fr@gmail.com")
        col_m.label(text="2026 all rights reserved.")
        col_m.separator()

        col_terms = box_about.column(align=True)
        col_terms.scale_y = 0.9
        col_terms.label(text="Features & Workflow:", icon='SCRIPT')
        col_terms.label(text="• Generates beauty diffuse texture from prompt")
        col_terms.label(text="• Decomposes SVBRDF into BaseColor, Normal, Roughness, Metalness")
        col_terms.label(text="• Direct automatic Principled BSDF setup on meshes")
        col_terms.label(text="• Seamless / tileable texture synthesis support")

        box_lic = layout.box()
        col_lic = box_lic.column(align=True)
        col_lic.scale_y = 0.85
        col_lic.label(text="Chord Research Paper (Ubisoft LaForge):", icon='COMMUNITY')
        col_lic.label(text="Chord: Chain of Rendering Decomposition for PBR Material Estimation")
        col_lic.label(text="Authors: Zhi Ying, Boxiang Rong, Jingyu Wang, Maoyuan Xu")
        col_lic.label(text="SIGGRAPH Asia 2025")
        col_lic.label(text="Ubisoft Machine Learning Research License")


class CHORD_PT_MainPanel(bpy.types.Panel):
    bl_label = "Chord for Blender"
    bl_idname = "CHORD_PT_MainPanel"
    bl_space_type = 'VIEW_3D'
    bl_region_type = 'UI'
    bl_category = "Chord"

    def draw_header(self, context):
        scene = context.scene
        srv_status = getattr(scene, "chord_server_status", "Offline")
        if "Online" in srv_status:
            self.layout.label(text="", icon='LAYER_ACTIVE')
        elif "Starting" in srv_status:
            self.layout.label(text="", icon='TIME')
        else:
            self.layout.label(text="", icon='RADIOBUT_OFF')

    def draw(self, context):
        layout = self.layout
        scene = context.scene
        active_tab = getattr(scene, "chord_active_tab", 'HOME')

        # ----------------------------------------------------
        # 1. TOP NAVIGATION ROW
        # ----------------------------------------------------
        nav_box = layout.box()
        nav_row = nav_box.row(align=True)
        nav_row.scale_y = 1.3

        # Tab 1: Home
        op_h = nav_row.operator("chord.switch_tab", text="", icon='HOME', depress=(active_tab == 'HOME'))
        op_h.target_tab = 'HOME'

        # Tab 2: Generate
        op_g = nav_row.operator("chord.switch_tab", text="", icon='TEXTURE', depress=(active_tab == 'GENERATE'))
        op_g.target_tab = 'GENERATE'

        # Tab 3: Material & Mesh
        op_m = nav_row.operator("chord.switch_tab", text="", icon='MATERIAL', depress=(active_tab == 'MATERIAL'))
        op_m.target_tab = 'MATERIAL'

        # Tab 4: History & Library
        op_hist = nav_row.operator("chord.switch_tab", text="", icon='TIME', depress=(active_tab == 'HISTORY'))
        op_hist.target_tab = 'HISTORY'

        # Tab 5: Settings & Server
        op_s = nav_row.operator("chord.switch_tab", text="", icon='PREFERENCES', depress=(active_tab == 'SETTINGS'))
        op_s.target_tab = 'SETTINGS'

        # Spacing
        nav_row.separator(factor=3.0)

        # Quick Start / Stop Server Toggle Button
        srv_status = getattr(scene, "chord_server_status", "")
        is_online = "Online" in srv_status
        sub_srv = nav_row.row(align=True)
        if is_online:
            sub_srv.operator("chord.stop_server", text="", icon='PAUSE')
        else:
            sub_srv.operator("chord.start_server", text="", icon='PLAY')

        # Tab 6: About
        op_a = nav_row.operator("chord.switch_tab", text="", icon='INFO', depress=(active_tab == 'ABOUT'))
        op_a.target_tab = 'ABOUT'

        layout.separator()

        # ----------------------------------------------------
        # PROGRESS & CANCEL BANNER
        # ----------------------------------------------------
        if scene.chord_is_generating:
            gen_box = layout.box()
            col_gen = gen_box.column(align=True)

            row_st = col_gen.row(align=True)
            row_st.scale_y = 1.1
            row_st.label(text=scene.chord_status_message, icon='TIME')

            row_bar = col_gen.row(align=True)
            row_bar.scale_y = 1.3
            sub_bar = row_bar.row(align=True)
            sub_bar.enabled = False
            sub_bar.prop(scene, "chord_generation_progress", slider=True, text="Progress")

            col_gen.separator()
            row_cancel = col_gen.row(align=True)
            row_cancel.scale_y = 1.3
            if scene.chord_cancel_requested:
                row_cancel.label(text="Cancelling...", icon='CANCEL')
                row_cancel.operator("chord.force_reset_generation", text="Force Unlock", icon='X')
            else:
                row_cancel.operator("chord.cancel_generation", text="Cancel Generation", icon='CANCEL')
                row_cancel.operator("chord.force_reset_generation", text="Unlock", icon='X')
            return

        # ----------------------------------------------------
        # TABS DISPATCHER
        # ----------------------------------------------------
        if active_tab == 'HOME':
            self.draw_home_tab(context, layout)
        elif active_tab == 'GENERATE':
            self.draw_generate_tab(context, layout)
        elif active_tab == 'MATERIAL':
            self.draw_material_tab(context, layout)
        elif active_tab == 'HISTORY':
            self.draw_history_tab(context, layout)
        elif active_tab == 'SETTINGS':
            self.draw_settings_tab(context, layout)
        elif active_tab == 'ABOUT':
            self.draw_about_tab(context, layout)

    # --------------------------------------------------------
    # TAB: HOME
    # --------------------------------------------------------
    def draw_home_tab(self, context, layout):
        scene = context.scene

        # Banner Header Image
        pcoll = get_preview_collection()
        if pcoll and "banner" in pcoll:
            banner_row = layout.row(align=True)
            banner_row.scale_y = 1.0
            banner_row.alignment = 'CENTER'
            banner_row.template_icon(icon_value=pcoll["banner"].icon_id, scale=12.0)
        else:
            banner = layout.box()
            col = banner.column(align=True)
            col.label(text="Chord PBR Material Studio", icon='MATERIAL')
            col.label(text="Ubisoft LaForge AI Decomposition", icon='BLENDER')

        layout.separator()

        # Large Visual Navigation Tiles
        grid = layout.column(align=True)

        row_gen = grid.row(align=True)
        row_gen.scale_y = 1.6
        op_gen = row_gen.operator("chord.switch_tab", text="Generate PBR Textures", icon='TEXTURE')
        op_gen.target_tab = 'GENERATE'

        row_mat = grid.row(align=True)
        row_mat.scale_y = 1.5
        op_mat = row_mat.operator("chord.switch_tab", text="Material & Mesh Controls", icon='MATERIAL')
        op_mat.target_tab = 'MATERIAL'

        row_hist = grid.row(align=True)
        row_hist.scale_y = 1.5
        op_hist = row_hist.operator("chord.switch_tab", text="Texture History & Library", icon='TIME')
        op_hist.target_tab = 'HISTORY'

        row_srv = grid.row(align=True)
        row_srv.scale_y = 1.4
        op_srv = row_srv.operator("chord.switch_tab", text="Server & Settings", icon='PREFERENCES')
        op_srv.target_tab = 'SETTINGS'

        row_abt = grid.row(align=True)
        row_abt.scale_y = 1.3
        op_abt = row_abt.operator("chord.switch_tab", text="About & Citations", icon='INFO')
        op_abt.target_tab = 'ABOUT'

        layout.separator()

        # Server Quick Status Card
        box_status = layout.box()
        col_s = box_status.column(align=True)
        row_st = col_s.row(align=True)
        srv_status = getattr(scene, "chord_server_status", "Offline")
        is_online = "Online" in srv_status
        row_st.label(text=f"Server: {srv_status}", icon='CHECKMARK' if is_online else 'CANCEL')
        row_st.operator("chord.check_server_status", text="", icon='FILE_REFRESH')

        if not is_online:
            row_act = col_s.row(align=True)
            row_act.scale_y = 1.2
            row_act.operator("chord.start_server", text="Start Server", icon='PLAY')

    # --------------------------------------------------------
    # TAB: GENERATE
    # --------------------------------------------------------
    def draw_generate_tab(self, context, layout):
        scene = context.scene

        # 1. Target Mesh Selection
        box_mesh = layout.box()
        box_mesh.label(text="Target Mesh Object:", icon='MESH_DATA')
        row_m = box_mesh.row(align=True)
        row_m.prop(scene, "chord_target_mesh", text="")
        row_m.operator("chord.pick_target_mesh", text="", icon='EYEDROPPER')

        # 2. Generation Mode Selector
        box_mode = layout.box()
        box_mode.row(align=True).prop(scene, "chord_generation_mode", expand=True)

        if scene.chord_generation_mode == 'PROMPT':
            # Text Prompt Inputs
            box_prompt = layout.box()
            box_prompt.label(text="Texture Prompt:", icon='EDITMODE_HLT')
            box_prompt.prop(scene, "chord_prompt", text="")

            box_neg = layout.box()
            box_neg.label(text="Negative Prompt:", icon='CANCEL')
            box_neg.prop(scene, "chord_negative_prompt", text="")

            # Diffusion & Texture Parameters
            box_params = layout.box()
            box_params.label(text="Parameters:", icon='TOOL_SETTINGS')
            box_params.prop(scene, "chord_seamless", icon='MOD_PARTICLES')

            row_res = box_params.row(align=True)
            row_res.prop(scene, "chord_resolution", expand=True)

            row_steps = box_params.row(align=True)
            row_steps.prop(scene, "chord_steps")
            row_steps.prop(scene, "chord_guidance_scale")

            row_seed = box_params.row(align=True)
            row_seed.prop(scene, "chord_seed")
            row_seed.operator("chord.randomize_seed", text="", icon='FILE_REFRESH')

        else:
            # Source Image Input
            box_img = layout.box()
            box_img.label(text="Input Texture Image:", icon='IMAGE_DATA')
            box_img.prop(scene, "chord_input_image_path", text="")

        layout.separator()

        # 3. Main Action Button
        row_gen = layout.row(align=True)
        row_gen.scale_y = 1.8
        srv_online = "Online" in getattr(scene, "chord_server_status", "")
        if srv_online:
            row_gen.operator("chord.generate_texture", text="Generate PBR & Apply to Mesh", icon='MATERIAL')
        else:
            sub = row_gen.row(align=True)
            sub.enabled = False
            sub.operator("chord.generate_texture", text="Server Offline (Start in Settings)", icon='ERROR')

        # 4. Last Generated Result Gallery
        if scene.chord_last_output_dir:
            box_out = layout.box()
            box_out.label(text="Last Generated SVBRDF Maps:", icon='RENDER_RESULT')
            col_maps = box_out.column(align=True)
            col_maps.scale_y = 0.9

            if scene.chord_last_basecolor:
                col_maps.label(text=f"BaseColor: {Path(scene.chord_last_basecolor).name}", icon='IMAGE_RGB')
            if scene.chord_last_normal:
                col_maps.label(text=f"Normal: {Path(scene.chord_last_normal).name}", icon='IMAGE_RGB')
            if scene.chord_last_roughness:
                col_maps.label(text=f"Roughness: {Path(scene.chord_last_roughness).name}", icon='IMAGE_ALPHA')
            if scene.chord_last_metalness:
                col_maps.label(text=f"Metallic: {Path(scene.chord_last_metalness).name}", icon='IMAGE_ALPHA')

            row_btns = box_out.row(align=True)
            row_btns.operator("chord.open_output_folder", text="Open Folder", icon='FILE_FOLDER')
            row_btns.operator("chord.apply_material", text="Re-Apply to Mesh", icon='FILE_REFRESH')

    # --------------------------------------------------------
    # TAB: MATERIAL
    # --------------------------------------------------------
    def draw_material_tab(self, context, layout):
        scene = context.scene

        box_target = layout.box()
        box_target.label(text="Target Mesh & Material Name:", icon='MATERIAL')
        row_m = box_target.row(align=True)
        row_m.prop(scene, "chord_target_mesh", text="")
        row_m.operator("chord.pick_target_mesh", text="", icon='EYEDROPPER')
        box_target.prop(scene, "chord_material_name", text="Material")
        box_target.prop(scene, "chord_auto_unwrap", icon='UV')

        box_shading = layout.box()
        box_shading.label(text="Material PBR Adjustments:", icon='NODE')
        box_shading.prop(scene, "chord_uv_tiling", slider=True)
        box_shading.prop(scene, "chord_normal_strength", slider=True)
        box_shading.prop(scene, "chord_roughness_scale", slider=True)
        box_shading.prop(scene, "chord_metallic_scale", slider=True)

        layout.separator()

        row_apply = layout.row(align=True)
        row_apply.scale_y = 1.5
        row_apply.operator("chord.apply_material", text="Apply PBR Material to Mesh", icon='MATERIAL')

    # --------------------------------------------------------
    # TAB: HISTORY
    # --------------------------------------------------------
    def draw_history_tab(self, context, layout):
        scene = context.scene

        # Top Bar: Header & Refresh
        box_hdr = layout.box()
        row_h = box_hdr.row(align=True)
        count = len(scene.chord_history_list) if hasattr(scene, "chord_history_list") else 0
        row_h.label(text=f"Generated Textures History ({count})", icon='TIME')
        row_h.operator("chord.refresh_history", text="Refresh", icon='FILE_REFRESH')

        # Target Mesh Selection
        box_mesh = layout.box()
        box_mesh.label(text="Apply Target Mesh:", icon='MESH_DATA')
        row_m = box_mesh.row(align=True)
        row_m.prop(scene, "chord_target_mesh", text="")
        row_m.operator("chord.pick_target_mesh", text="", icon='EYEDROPPER')

        if count == 0:
            box_empty = layout.box()
            col_e = box_empty.column(align=True)
            col_e.label(text="No generated textures found in history.", icon='INFO')
            col_e.label(text="Click 'Refresh' or generate a texture in Generate tab.")
            row_go = box_empty.row(align=True)
            row_go.scale_y = 1.3
            op_go = row_go.operator("chord.switch_tab", text="Go to Generate Tab", icon='TEXTURE')
            op_go.target_tab = 'GENERATE'
            return

        # UIList of history items
        row_list = layout.row()
        row_list.template_list(
            "CHORD_UL_HistoryList", "chord_history_ui",
            scene, "chord_history_list",
            scene, "chord_history_index",
            rows=5
        )

        idx = scene.chord_history_index
        if 0 <= idx < count:
            item = scene.chord_history_list[idx]
            box_sel = layout.box()
            col_s = box_sel.column(align=True)

            # Title & Date
            row_t = col_s.row(align=True)
            row_t.label(text=item.name, icon='RENDER_RESULT')
            sub_d = row_t.row(align=True)
            sub_d.alignment = 'RIGHT'
            sub_d.label(text=item.date)

            # Preview Image Display
            pcoll = get_history_preview_collection()
            if pcoll and item.name in pcoll:
                p_row = col_s.row(align=True)
                p_row.alignment = 'CENTER'
                p_row.scale_y = 1.0
                p_row.template_icon(icon_value=pcoll[item.name].icon_id, scale=8.5)
            elif item.preview_path:
                col_s.label(text="Preview file available on disk", icon='IMAGE_DATA')

            col_s.separator()

            # Badges for available maps
            row_badges = col_s.row(align=True)
            row_badges.scale_y = 0.85
            row_badges.label(text="Maps:")
            if item.basecolor_path:
                row_badges.label(text="BaseColor", icon='CHECKMARK')
            if item.normal_path:
                row_badges.label(text="Normal", icon='CHECKMARK')
            if item.roughness_path:
                row_badges.label(text="Roughness", icon='CHECKMARK')
            if item.metalness_path:
                row_badges.label(text="Metallic", icon='CHECKMARK')

            layout.separator()

            # Main Action Button: Apply to Active Mesh
            row_apply = layout.row(align=True)
            row_apply.scale_y = 1.6
            row_apply.operator("chord.apply_history_item", text="Apply This PBR Material to Mesh", icon='MATERIAL')

            # Secondary Action Buttons: Open Folder, Delete
            row_acts = layout.row(align=True)
            row_acts.scale_y = 1.1
            op_f = row_acts.operator("chord.open_output_folder", text="Open Folder", icon='FILE_FOLDER')
            op_del = row_acts.operator("chord.delete_history_item", text="Delete", icon='TRASH')

    # --------------------------------------------------------
    # TAB: SETTINGS & SERVER
    # --------------------------------------------------------
    def draw_settings_tab(self, context, layout):
        scene = context.scene

        box_srv = layout.box()
        box_srv.label(text="Server Connection:", icon='URL')
        box_srv.prop(scene, "chord_server_mode", expand=True)

        if scene.chord_server_mode == 'LOCAL':
            box_srv.prop(scene, "chord_server_port", text="Port")
        else:
            box_srv.prop(scene, "chord_server_url", text="URL")

        # Health & State
        box_health = layout.box()
        box_health.label(text="Server Health & Device:", icon='INFO')
        srv_status = getattr(scene, "chord_server_status", "Offline")
        is_online = "Online" in srv_status

        col_h = box_health.column(align=True)
        row_h = col_h.row(align=True)
        row_h.label(text=f"Status: {srv_status}", icon='CHECKMARK' if is_online else 'CANCEL')
        row_h.operator("chord.check_server_status", text="Ping", icon='FILE_REFRESH')

        if scene.chord_server_device:
            col_h.label(text=f"Device: {scene.chord_server_device}", icon='DESKTOP')

        # Local Server Controls
        if scene.chord_server_mode == 'LOCAL':
            box_ctl = layout.box()
            box_ctl.label(text="Local Server Controls:", icon='PREFERENCES')

            row_run = box_ctl.row(align=True)
            row_run.scale_y = 1.3
            if is_online:
                row_run.operator("chord.stop_server", text="Stop Server", icon='PAUSE')
            else:
                row_run.operator("chord.start_server", text="Start Server", icon='PLAY')

            row_inst = box_ctl.row(align=True)
            row_inst.operator("chord.install_server", text="Install / Update Server", icon='CONSOLE')
            row_inst.operator("chord.open_server_folder", text="Server Folder", icon='FILE_FOLDER')

            box_ctl.separator()
            row_diag = box_ctl.row(align=True)
            row_diag.operator("chord.toggle_console", text="Toggle System Console", icon='CONSOLE')
            row_diag.operator("chord.uninstall_server", text="Uninstall Server", icon='TRASH')

        # Paths
        box_paths = layout.box()
        box_paths.label(text="File & Model Locations:", icon='FILE_FOLDER')
        box_paths.prop(scene, "chord_repo_path")
        box_paths.prop(scene, "chord_model_path")

    # --------------------------------------------------------
    # TAB: ABOUT
    # --------------------------------------------------------
    def draw_about_tab(self, context, layout):
        scene = context.scene

        box = layout.box()
        col = box.column(align=True)
        col.label(text="Chord for Blender", icon='MATERIAL')
        col.label(text="AI SVBRDF & PBR Texture Studio")
        col.separator()
        col.label(text="Author: Jérôme Lemarchand")
        col.label(text="Email: goblingames.fr@gmail.com")
        col.label(text="Year: 2026")

        box_cit = layout.box()
        col_c = box_cit.column(align=True)
        col_c.scale_y = 0.9
        col_c.label(text="Research & AI Backbone:", icon='COMMUNITY')
        col_c.label(text="Ubisoft LaForge - Chord Project")
        col_c.label(text="Chain of Rendering Decomposition")
        col_c.label(text="SIGGRAPH Asia 2025")

        row_abt = layout.row(align=True)
        row_abt.scale_y = 1.3
        row_abt.operator("chord.about", text="Detailed License & Usage Terms", icon='SCRIPT')
